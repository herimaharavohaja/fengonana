<?php 
    // session_start();
    include 'connect.php'; 
    include "nav.php";
    include "secur.php";
?> 
<style>
    .sidebar-divider {
        margin: 0; /* Ajustez cette valeur selon vos besoins */
    }

    .nav-item {
        margin-bottom: 0; /* Ajustez cette valeur selon vos besoins */
    }
</style>

<body style="overflow-y: hidden; padding-bottom: 0" >

    <!-- Page Wrapper -->
    <div id="wrapper" style="margin-top: 10px;"> 
            <div style="max-height: 900px; overflow-y: auto;width: auto;overflow-x: hidden;">
            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" style="z-index: 999;">
                <?php 
                // include "logo.php";
                 ?>

                <hr class="sidebar-divider m-0">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'welcome.php') ? 'active' : ''; ?> " >
                    <a class="nav-link " href="welcome.php" style="padding: 8px;">
                        <i class="bi bi-house"id="ic"></i>
                        <span>Acceuil</span>
                    </a>
                </li>
                <!-- Divider -->
                <hr class="sidebar-divider m-0">

                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'tetiAndro.php') ? 'active' : ''; ?> ">
                    <a class="nav-link " href="tetiAndro.php" style="padding: 8px;">
                        <i class="bi bi-calendar-check"id="ic"></i>
                        <span>Calendrier</span></a>
                </li>
                <!-- Divider -->
                <hr class="sidebar-divider m-0">

                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'stat.php') ? 'active' : ''; ?> ">
                    <a class="nav-link " href="stat.php" style="padding: 8px;">
                        <i class="bi bi-bar-chart"id="ic"></i>
                        <span>Statistiques</span></a>
                </li>
                <!-- <hr class="sidebar-divider m-0"> -->

                
                <?php 
                    if ($_SESSION['libCategorie'] == "superAdmin" || $_SESSION['libCategorie'] == "admin") {
                ?>      
                
                        <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'crea.php') ? 'active' : ''; ?> ">
                            <a class="nav-link " href="crea.php" style="padding: 8px;">
                                <i class="bi bi-bricks"id="ic"></i>
                                <span>Créations</span>
                            </a>
                        </li>
                        <hr class="sidebar-divider m-0">
                        <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'creaAdmin.php') ? 'active' : ''; ?> ">
                            <a class="nav-link " href="creaAdmin.php" style="padding: 8px;">
                                <i class="bi bi-person-plus"id="ic"></i>
                                <span>Herivelona</span>
                            </a>
                        </li>
                        <hr class="sidebar-divider m-0">
                        <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'caisse.php') ? 'active' : ''; ?> ">
                            <a class="nav-link " href="caisse.php" style="padding: 8px;">
                                <i class="bi bi-cash-coin"id="ic"></i>
                                <span>Caisse</span></a>
                        </li>
                        
                        <hr class="sidebar-divider m-0">
                        <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'presence.php') ? 'active' : ''; ?> ">
                            <a class="nav-link " href="presence.php" style="padding: 8px;">
                                <i class="bi bi-clipboard-check"id="ic"></i>
                                <span>Presence</span></a>
                        </li>

                        <hr class="sidebar-divider m-0">
                        <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'vola.php') ? 'active' : ''; ?> ">
                            <a class="nav-link " href="vola.php" style="padding: 8px;">
                                <i class="bi bi-cash"id="ic"></i>
                                <span>Fitadiavam-bola</span></a>
                        </li>

                <?php 
                    }
                 ?>
                
                <?php if ($_SESSION['libCategorie'] != "membre"): ?>

                    <hr class="sidebar-divider m-0">

                    <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'creaActivite.php') ? 'active' : ''; ?> ">
                        <a class="nav-link " href="creaActivite.php" style="padding: 8px;">
                            <i class="bi bi-yelp"id="ic"></i>
                            <span>Activité</span></a>
                    </li>

                    
                <?php endif ?> 

                
                <!-- <hr class="sidebar-divider m-0"> -->
                <?php if ($_SESSION['libCategorie'] == "User") {

                    include "pannelUsers.php";
                } ?>
                <hr class="sidebar-divider m-0">
                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'faritra.php') ? 'active' : ''; ?> ">
                    <a class="nav-link " href="faritra.php" style="padding: 8px;">
                        <i class="bi bi-receipt" id="ic"id="ic"></i>
                        <span>Historiques</span></a>
                </li>

                <hr class="sidebar-divider m-0">
                
                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'recherche1.php') ? 'active' : ''; ?> ">
                    <a class="nav-link " href="recherche1.php" style="padding: 8px;">
                        <i class="bi bi-search" id="ic"id="ic"></i>
                        <span>Rechercher</span>
                    </a>
                </li>
                <!-- Heading -->
                <hr class="sidebar-divider m-0">

                <li class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'propos.php') ? 'active' : ''; ?> ">
                    <a class="nav-link " href="propos.php" style="padding: 8px;">
                        <i class="bi bi-buildings"id="ic"></i>
                        <span>A propos</span></a>
                </li>
            </ul>
            </div>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column" >
                <!-- Topbar -->
                <?php 
                    include "navBar.php";
                ?>
            <style type="text/css">
                #ic{
                    font-size: 20px;
                }

            </style>