-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 06 déc. 2023 à 18:02
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `jead0`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE `activite` (
  `idActivite` int(11) NOT NULL,
  `libActivite` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `andraikitra`
--

CREATE TABLE `andraikitra` (
  `idAndraikitra` int(11) NOT NULL,
  `libAndraikitra` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `andraikitra`
--

INSERT INTO `andraikitra` (`idAndraikitra`, `libAndraikitra`) VALUES
(1, 'yes'),
(4, 'gestionnaire');

-- --------------------------------------------------------

--
-- Structure de la table `caisse`
--

CREATE TABLE `caisse` (
  `idCaisse` int(11) NOT NULL,
  `motif` varchar(250) NOT NULL,
  `type` varchar(255) NOT NULL,
  `montant` int(11) NOT NULL,
  `daty` date NOT NULL DEFAULT current_timestamp(),
  `solde` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ev`
--

CREATE TABLE `ev` (
  `idEv` int(11) NOT NULL,
  `libEv` varchar(255) NOT NULL,
  `debutEv` date NOT NULL,
  `finEv` date NOT NULL,
  `placeEv` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `ev`
--

INSERT INTO `ev` (`idEv`, `libEv`, `debutEv`, `finEv`, `placeEv`) VALUES
(1, 'test1', '2023-12-30', '2023-12-31', '2');

-- --------------------------------------------------------

--
-- Structure de la table `faritra`
--

CREATE TABLE `faritra` (
  `idFaritra` int(11) NOT NULL,
  `codeFaritra` varchar(250) NOT NULL,
  `libFaritra` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `faritra`
--

INSERT INTO `faritra` (`idFaritra`, `codeFaritra`, `libFaritra`) VALUES
(7, 'f1341542', 'f160'),
(8, 'dfl2', 'ds231');

-- --------------------------------------------------------

--
-- Structure de la table `konty`
--

CREATE TABLE `konty` (
  `idKonty` int(11) NOT NULL,
  `libPseudo` varchar(250) NOT NULL,
  `libPass` varchar(255) NOT NULL,
  `libCategorie` varchar(200) NOT NULL,
  `idFaritra` int(11) DEFAULT NULL,
  `codeKonty` varchar(200) NOT NULL,
  `hashKonty` text NOT NULL,
  `idSakramenta` int(11) DEFAULT NULL,
  `idMasina` int(11) DEFAULT NULL,
  `idVaomiera` int(11) DEFAULT NULL,
  `saryKonty` varchar(200) DEFAULT NULL,
  `dteCrea` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `konty`
--

INSERT INTO `konty` (`idKonty`, `libPseudo`, `libPass`, `libCategorie`, `idFaritra`, `codeKonty`, `hashKonty`, `idSakramenta`, `idMasina`, `idVaomiera`, `saryKonty`, `dteCrea`) VALUES
(1, 'jead', 'jeannot', 'superAdmin', 0, '', '', 0, 0, 0, 'img1.jpg', '0000-00-00'),
(15, 'bd22', '2', 'User', 2, 'fvbj', 'ZnZiag==', 0, 0, 0, 'img3.jpg', '0000-00-00'),
(20, 'f22', 'f223', 'User', 7, 'f20', 'ZjI=', 0, 0, 0, '', '2023-12-06'),
(21, 'dc', 'dc1', 'User', 0, 'lo', 'bG8=', 0, 4, 0, '', '0000-00-00'),
(22, 'fssf1', 'sf1', 'User', 0, 'ls1', 'bHM=', 0, 4, 0, '', '0000-00-00'),
(32, 'testA', 'testA', 'Admin', NULL, 'testA', 'dGVzdEE=', NULL, NULL, NULL, NULL, '2023-12-05');

-- --------------------------------------------------------

--
-- Structure de la table `masina`
--

CREATE TABLE `masina` (
  `idMasina` int(11) NOT NULL,
  `codeMasina` varchar(250) NOT NULL,
  `libMasina` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `masina`
--

INSERT INTO `masina` (`idMasina`, `codeMasina`, `libMasina`) VALUES
(4, 'tes3', 'tes3'),
(5, 'f', 'f2');

-- --------------------------------------------------------

--
-- Structure de la table `proactivite`
--

CREATE TABLE `proactivite` (
  `idPro` int(11) NOT NULL,
  `libActivite` varchar(200) NOT NULL,
  `debutActivite` date NOT NULL,
  `finActivite` date NOT NULL,
  `descActivite` text NOT NULL,
  `etatActivite` int(11) NOT NULL,
  `placeActivite` varchar(200) NOT NULL,
  `idKonty` int(11) NOT NULL,
  `dtePresence` date DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `actif` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `proactivite`
--

INSERT INTO `proactivite` (`idPro`, `libActivite`, `debutActivite`, `finActivite`, `descActivite`, `etatActivite`, `placeActivite`, `idKonty`, `dtePresence`, `role`, `actif`) VALUES
(6, 'Test 2', '2023-11-19', '2023-11-29', 'fsbfb ', 0, 'fdght', 1, '2023-10-10', '15,19', 'ZnZiag==,MjU=,ajIgdg='),
(7, 'jopp', '2023-11-02', '2023-11-30', 'dsfcdsvsd', 0, 'dsc', 15, '2023-11-13', NULL, NULL),
(8, 'zer', '2023-11-03', '2023-11-16', 'cv <dfcv sf', 0, 'dfcds', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sakramenta`
--

CREATE TABLE `sakramenta` (
  `idSakramenta` int(11) NOT NULL,
  `libSakramenta` varchar(250) NOT NULL,
  `dteSakramenta` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `sakramenta`
--

INSERT INTO `sakramenta` (`idSakramenta`, `libSakramenta`, `dteSakramenta`) VALUES
(6, 'Batemy', '2023-11-12');

-- --------------------------------------------------------

--
-- Structure de la table `stocksakramenta`
--

CREATE TABLE `stocksakramenta` (
  `idStockSakramenta` int(11) NOT NULL,
  `idKonty` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idSakramenta` int(11) NOT NULL,
  `dteStockSakramenta` varchar(200) NOT NULL,
  `lieuStockSakramenta` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `idFaritra` int(11) NOT NULL,
  `idMasina` int(11) NOT NULL,
  `idVaomiera` int(11) NOT NULL,
  `idAndraikitra` int(11) NOT NULL,
  `idSakramenta` int(11) NOT NULL,
  `nomUser` varchar(200) NOT NULL,
  `codeUser` varchar(250) NOT NULL,
  `prenomUser` varchar(255) NOT NULL,
  `lieuSakramenta` varchar(250) NOT NULL,
  `dteUser` date NOT NULL DEFAULT current_timestamp(),
  `sexeUser` varchar(110) NOT NULL,
  `qrUser` varchar(200) NOT NULL,
  `saryUser` varchar(250) NOT NULL,
  `dteNaissUser` date NOT NULL DEFAULT current_timestamp(),
  `apvUser` varchar(250) NOT NULL,
  `adresyUser` varchar(255) NOT NULL,
  `dteSakramentaUser` date NOT NULL DEFAULT current_timestamp(),
  `hashKonty` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idUser`, `idFaritra`, `idMasina`, `idVaomiera`, `idAndraikitra`, `idSakramenta`, `nomUser`, `codeUser`, `prenomUser`, `lieuSakramenta`, `dteUser`, `sexeUser`, `qrUser`, `saryUser`, `dteNaissUser`, `apvUser`, `adresyUser`, `dteSakramentaUser`, `hashKonty`) VALUES
(28, 2, 0, 0, 1, 0, 'hy', '25', 'gy', 'gfngf', '2023-10-10', 'Masculin', '', '5.jpg', '2023-10-18', '4', 'fdvb r gerzgvr', '2023-10-10', 'MjU='),
(29, 3, 0, 0, 1, 0, 'jior', 'j2', 'lokd', '', '2023-10-31', 'Féminin', '', '4.jpg', '2023-10-07', '32', 'dk lodjea sqvdqvdqvq', '2023-10-31', 'ajI='),
(30, 2, 4, 0, 1, 0, 'jfdvfdb', 'j2', 'lgfdbdgokd', '', '2022-10-31', 'Masculin', '', '4.jpg', '2023-10-07', '32', 'dk lodjea sqvdqvdqvq', '2023-10-31', 'ajIgdg=');

-- --------------------------------------------------------

--
-- Structure de la table `vaomiera`
--

CREATE TABLE `vaomiera` (
  `idVaomiera` int(11) NOT NULL,
  `codeVaomiera` varchar(250) NOT NULL,
  `libVaomiera` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `vaomiera`
--

INSERT INTO `vaomiera` (`idVaomiera`, `codeVaomiera`, `libVaomiera`) VALUES
(3, 'j', 'j1');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `activite`
--
ALTER TABLE `activite`
  ADD PRIMARY KEY (`idActivite`);

--
-- Index pour la table `andraikitra`
--
ALTER TABLE `andraikitra`
  ADD PRIMARY KEY (`idAndraikitra`);

--
-- Index pour la table `caisse`
--
ALTER TABLE `caisse`
  ADD PRIMARY KEY (`idCaisse`);

--
-- Index pour la table `ev`
--
ALTER TABLE `ev`
  ADD PRIMARY KEY (`idEv`);

--
-- Index pour la table `faritra`
--
ALTER TABLE `faritra`
  ADD PRIMARY KEY (`idFaritra`);

--
-- Index pour la table `konty`
--
ALTER TABLE `konty`
  ADD PRIMARY KEY (`idKonty`);

--
-- Index pour la table `masina`
--
ALTER TABLE `masina`
  ADD PRIMARY KEY (`idMasina`);

--
-- Index pour la table `proactivite`
--
ALTER TABLE `proactivite`
  ADD PRIMARY KEY (`idPro`);

--
-- Index pour la table `sakramenta`
--
ALTER TABLE `sakramenta`
  ADD PRIMARY KEY (`idSakramenta`);

--
-- Index pour la table `stocksakramenta`
--
ALTER TABLE `stocksakramenta`
  ADD PRIMARY KEY (`idStockSakramenta`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- Index pour la table `vaomiera`
--
ALTER TABLE `vaomiera`
  ADD PRIMARY KEY (`idVaomiera`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `activite`
--
ALTER TABLE `activite`
  MODIFY `idActivite` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `andraikitra`
--
ALTER TABLE `andraikitra`
  MODIFY `idAndraikitra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `caisse`
--
ALTER TABLE `caisse`
  MODIFY `idCaisse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `ev`
--
ALTER TABLE `ev`
  MODIFY `idEv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `faritra`
--
ALTER TABLE `faritra`
  MODIFY `idFaritra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `konty`
--
ALTER TABLE `konty`
  MODIFY `idKonty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT pour la table `masina`
--
ALTER TABLE `masina`
  MODIFY `idMasina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `proactivite`
--
ALTER TABLE `proactivite`
  MODIFY `idPro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `sakramenta`
--
ALTER TABLE `sakramenta`
  MODIFY `idSakramenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `stocksakramenta`
--
ALTER TABLE `stocksakramenta`
  MODIFY `idStockSakramenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `vaomiera`
--
ALTER TABLE `vaomiera`
  MODIFY `idVaomiera` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
