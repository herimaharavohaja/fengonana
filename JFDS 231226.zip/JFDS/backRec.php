<?php
// Inclure le fichier de connexion à la base de données
include 'connect.php';

// Vérifier si le terme de recherche est défini dans la requête GET
if (isset($_GET['term'])) {
    $term = $_GET['term'];

    // Utiliser une requête préparée pour éviter les injections SQL
    $sql = "SELECT user.*, andraikitra.*, masina.*, sakramenta.*, vaomiera.*, faritra.*, proactivite.* FROM user
		LEFT JOIN faritra ON faritra.idFaritra = user.idFaritra
		LEFT JOIN andraikitra ON andraikitra.idAndraikitra = user.idFaritra
		LEFT JOIN masina ON masina.idMasina = user.idMasina
		LEFT JOIN sakramenta ON sakramenta.idSakramenta = user.idSakramenta
		LEFT JOIN vaomiera ON vaomiera.idVaomiera = user.idVaomiera
		LEFT JOIN proactivite ON FIND_IN_SET(user.hashKonty, proactivite.actif) > 0
		WHERE libFaritra LIKE ? OR codeFaritra LIKE ?
		OR libSakramenta LIKE ? 
		OR libVaomiera LIKE ? OR codeVaomiera LIKE ? 
		OR libMasina LIKE ? OR codeMasina LIKE ? 
		OR nomUser LIKE ? OR prenomUser LIKE ? OR codeUser LIKE ? OR sexeUser LIKE ? OR dteNaissUser LIKE ? OR apvUser LIKE ? OR adresyUser LIKE ? 
		OR libActivite LIKE ? OR descActivite LIKE ? OR debutActivite LIKE ? OR finActivite LIKE ?   
		";

    // Préparer la requête
    $stmt = $conn->prepare($sql);

    // Ajouter le joker % au terme de recherche
    $termW = '%' . $term . '%';

    // Liaison du paramètre
    $stmt->bind_param('ssssssssssssssssss', 
    	$termW, $termW, $termW, $termW, $termW, $termW, $termW, $termW, $termW, $termW,
    	$termW, $termW, $termW, $termW, $termW, $termW, $termW, $termW
	);

    // Exécution de la requête
    $stmt->execute();

    // Récupération des résultats
    $result = $stmt->get_result();

    // Initialiser une variable pour suivre si des résultats sont trouvés
    $resultsFound = false;

    // Afficher l'entête de la table s'il y a des résultats
    while ($row = $result->fetch_assoc()) {
        $resultsFound = true;
        break; // Sortir de la boucle dès que des résultats sont trouvés
    }

    if ($resultsFound) {
        // Afficher l'entête de la table
        echo '<div class="table-responsive" >
            <table class="table" style="font-size: 14px;">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Nom & prénom</th>
                        <th>Sexe</th>
                        <th>Date naissance</th>
                        <th>Apv</th>
                        <th>Adresse</th>
                        <th>Quartier</th>
                        <th>Sakramenta</th>
                        <th>Fik. masina</th>
                        <th>Vaomiera asa</th>
                        <th>Activité</th>
                    </tr>
                </thead>
                <tbody>';

        // Afficher les résultats
        $result->data_seek(0); // Réinitialiser le pointeur de résultat
        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td><img style="border-radius: 40px;" src="uploads/membres' . $row['saryUser'] . '" class="img-fluid" width="50px" height="50px" ></td>
                    <td>' . $row['nomUser'] . ' ' . $row['prenomUser'] . '</td>
                    <td>' . $row['sexeUser'] . '</td>
                    <td>' . $row['dteNaissUser'] . '</td>
                    <td>' . $row['apvUser'] . '</td>
                    <td>' . $row['adresyUser'] . '</td>
                    <td>' . $row['libFaritra'] . '</td>
                    <td>' . $row['libSakramenta'] . '</td>
                    <td>' . $row['libMasina'] . '</td>
                    <td>' . $row['libVaomiera'] . '</td>
                    <td>' . $row['libActivite'] . '</td>
                  </tr>';
        }

        echo '</tbody></table></div>';
    } else {
        // Aucun résultat trouvé
        echo '<h1 style="font-size:25px;">Aucun résultat</h1>';
    }
} else {
    // Gérer le cas où le terme de recherche n'est pas défini
    // echo "Aucun terme de recherche défini.";
}


// ---------- pour admin recherche --------

if (isset($_GET['term1'])) {
    $term1 = $_GET['term1'];

    // Utiliser une requête préparée pour éviter les injections SQL
    $sql1 = "SELECT konty.*, masina.*, sakramenta.*, vaomiera.*, faritra.*, proactivite.* FROM konty
		LEFT JOIN faritra ON faritra.idFaritra = konty.idFaritra
		LEFT JOIN masina ON masina.idMasina = konty.idMasina
		LEFT JOIN sakramenta ON sakramenta.idSakramenta = konty.idSakramenta
		LEFT JOIN vaomiera ON vaomiera.idVaomiera = konty.idVaomiera
		LEFT JOIN proactivite ON FIND_IN_SET(konty.hashKonty, proactivite.role) > 0
		WHERE libFaritra LIKE ? OR codeFaritra LIKE ?
		OR libSakramenta LIKE ? 
		OR libVaomiera LIKE ? OR codeVaomiera LIKE ? 
		OR libMasina LIKE ? OR codeMasina LIKE ? 
		OR libPseudo LIKE ? OR libCategorie LIKE ? OR codeKonty LIKE ? 
		OR libActivite LIKE ? OR descActivite LIKE ? OR debutActivite LIKE ? OR finActivite LIKE ?   
		";

    // Préparer la requête
    $stmt1 = $conn->prepare($sql1);

    // Ajouter le joker % au terme de recherche
    $termW1 = '%' . $term1 . '%';

    // Liaison du paramètre
    $stmt1->bind_param('ssssssssssssss', 
    	$termW1, $termW1, $termW1, $termW1, $termW1, $termW1, $termW1, $termW1, $termW1, $termW1,
    	$termW1, $termW1, $termW1, $termW1
	);

    // Exécution de la requête
    $stmt1->execute();

    // Récupération des résultats
    $result1 = $stmt1->get_result();

    // Initialiser une variable pour suivre si des résultats sont trouvés
    $resultsFound1 = false;

    // Afficher l'entête de la table s'il y a des résultats
    while ($row1 = $result1->fetch_assoc()) {
        $resultsFound1 = true;
        break; // Sortir de la boucle dès que des résultats sont trouvés
    }

    if ($resultsFound1) {
        // Afficher l'entête de la table
        echo '<div class="table-responsive" >
            <table class="table" style="font-size: 14px;">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Pseudo</th>
                        <th>Rôle</th>
                        <th>Quartier</th>
                        <th>Sakramenta</th>
                        <th>Fik. masina</th>
                        <th>Vaomiera asa</th>
                        <th>Activité</th>
                    </tr>
                </thead>
                <tbody>';

        // Afficher les résultats
        $result1->data_seek(0); // Réinitialiser le pointeur de résultat
        while ($row1 = $result1->fetch_assoc()) {
            echo '<tr>
                    <td><img style="border-radius: 40px;" src="img/' . $row1['saryKonty'] . '" class="img-fluid" width="50px" height="50px" ></td>
                    <td>' . $row1['libPseudo'] . '</td>
                    <td>' . $row1['libCategorie'] . '</td>
                    <td>' . $row1['libFaritra'] . '</td>
                    <td>' . $row1['libSakramenta'] . '</td>
                    <td>' . $row1['libMasina'] . '</td>
                    <td>' . $row1['libVaomiera'] . '</td>
                    <td>' . $row1['libActivite'] . '</td>
                  </tr>';
        }

        echo '</tbody></table></div>';
    } else {
        // Aucun résultat trouvé
        echo '<p>Aucun résultat</p>';
    }
} else {
    // Gérer le cas où le terme de recherche n'est pas défini
    // echo "Aucun terme de recherche défini.";
}


// Fermeture de la connexion à la base de données
$conn->close();
?>
