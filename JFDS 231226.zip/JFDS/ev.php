<?php

 include 'connect.php';  
 include('db_function.php'); 
 session_start();
 $cat = $_SESSION['libCategorie'];
 $idKonty = $_SESSION['idKonty'];

if (isset($_POST['enregistrer'])) {
    $libEv = $_POST['libEv'];
    $libEv = escape_data($conn, $libEv);
    $debutEv = $_POST['debutEv'];
    $finEv= $_POST['finEv'];
    // $descActivite = $_POST['descActivite'];
    $placeEv = $_POST['placeEv'];
    $placeEv = escape_data($conn, $placeEv);

              // Si la valeur n'existe pas, faire quelque chose d'autre ici
              $query  = "INSERT INTO ev (libEv, debutEv, finEv, placeEv) VALUES ('$libEv', '$debutEv','$finEv', '$placeEv')";
              $result = $conn->query($query);
              header("Location: ev.php");
      }
 ?>
<?php include 'pannelAmbony.php'; ?>  
<?php include 'navCompte1.php'; ?>   
 
    <div class="container">

    <div class="row">
    <div class="col-md-4">
        <br>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Evènement</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                	<div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Nom d'évènement</label>

                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libEv" class="form-control" required />
                        </div>
                    </div>

                    <div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Lieu</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="placeEv" class="form-control" />
                        </div>
                    </div>
                    
                        <div style="margin-top: -10px;">
                            <label class="form-label" for="form1Example1">Du</label>
                            <div class="form-outline mb-4">
                                <input type="date" id="form1Example1" name="debutEv" class="form-control" required />
                            </div>

                        </div>

                    <div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Au (Facultatif)</label>
                        <div class="form-outline mb-4">
                            <input type="date" id="form1Example1" name="finEv" class="form-control"  />
                        </div>
                    </div>

                    <div style="margin-top: -10px;">

                        <input type="submit" class="btn btn-success" name="enregistrer" value="Créer"  />
                    </div>
                </form>

            </div>

        </div>
        <br><br>
    </div>
    <div class="col-md-8">
      <br>
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Evènement à venir</h6>
                
            </div>
            <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                <form>
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>Début</th>
                              <th>Fin</th>
                              <th>Titre</th>
                              <th>Toerana</th>
                              <th colspan="1" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                $query = "SELECT * FROM ev ORDER BY idEv DESC ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  

                        <tr>
                              <td><?php echo $row['debutEv']?></td>
                              <td>
                                <?php
                                  if ($row['finEv'] != '0000-00-00') {
                                      echo $row['finEv'];
                                  } else {
                                      echo $row['debutEv'];
                                  }
                                ?>
                              </td>
                              <td><?php echo $row['libEv']?></td>
                              <td><?php echo $row['placeEv']?></td>
                              <td style="text-align: right;">
                                <a href="deleteKonty.php?supprEv=<?php echo $row['idEv']; ?>">
                                  <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i></button>
                                </a>
                              </td>
                          
                        </tr>
                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>

                    </table>       
                </form>
                
            </div>
        </div>
    </div>
</div>


<br><br>
<?php include 'pannelAmbany.php'; ?> 