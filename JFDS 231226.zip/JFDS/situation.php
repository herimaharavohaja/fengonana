<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte2.php'; ?>   
<br>

    <div class="container" style="border-radius: ">
    <div class="row">

    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Situation</h6>

            </div>
            <div class="card-body" style="max-height: 450px;overflow-y: auto;">
            <?php 
                $sqlOperation = "SELECT * FROM operation";
                $resultOperation = $conn->query($sqlOperation);
                $optionOperation = [];
                if ($resultOperation->num_rows > 0) {
                    while ($rowOperation = $resultOperation->fetch_assoc()) {
                        $optionOperation[] = $rowOperation;
                    }
                }
            ?>
            <div class="form-outline mb-4">
                <select name="idOperation" id="idOperation" required class="form-control" style="width: 140px;">
                    <option value="" disabled selected hidden>Opération</option>
                    <?php foreach ($optionOperation as $optionOperationItem) : ?>
                        <option value="<?php echo $optionOperationItem['idOperation']; ?>">
                            <?php echo $optionOperationItem['libOperation']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>

            </div>
            <script>
    document.getElementById('idOperation').addEventListener('change', function() {
        var idOperation = this.value;

        // Effectuer une requête AJAX pour mettre à jour le tableau en fonction de l'opération sélectionnée
        fetch('update_table.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'idOperation=' + idOperation,
        })
        .then(response => response.text())
        .then(data => {
            // Mettre à jour le contenu de la table avec la réponse du serveur
            document.getElementById('Table_util').innerHTML = data;
        })
        .catch(error => console.error('Erreur lors de la mise à jour de la table:', error));
    });
</script>

        <table id="Table_util" class="table table-bordered table-striped"></table>
            </div>
        </div>
    </div>
    </div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 