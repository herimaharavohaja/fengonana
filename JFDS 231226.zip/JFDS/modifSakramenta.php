<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $sql = "SELECT *
      FROM sakramenta
      WHERE idSakramenta = $ida";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  // $id = $row['id'];
  $libSakramenta = $row['libSakramenta'];
  }


  if (isset($_POST['modif'])) {
  $libSakramenta = $conn->real_escape_string(($_POST['libSakramenta']));

    $query = "UPDATE sakramenta SET libSakramenta='$libSakramenta' WHERE idSakramenta = $ida";
    $result1 = $conn->query($query);
     header("Location:creaSakramenta.php");
  }else{
  }


 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Modification de sakramenta</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">



                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Libellé</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libSakramenta" class="form-control" value="<?php echo $libSakramenta; ?>"/>
                        </div>
                    </div>
                    <div class="mb-3">

                        <input type="submit" class="btn btn-info" name="modif" value="Modifier"  />
                    </div>
                </form>
                                </div>
                            </div>
    </div>
    <div class="col-md-4"></div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 