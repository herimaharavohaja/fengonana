$(document).ready(function(){
	$("#signup").submit(function(){
		var nom = $("#nom").val();
			nom = $.trim(nom);
		var prenom = $("#prenom").val();
			prenom = $.trim(prenom);
		var email = $("#email").val();
		var motdepasse = $("#motdepasse").val();
		var cmotdepasse = $("#cmotdepasse").val();

		var url = $(this).attr("action");

		$("#error2").slideUp("888", function(){

			$.post(url,{
				"nom" : nom,
				"prenom" : prenom,
				"email" : email,
				"motdepasse" : motdepasse,
				"cmotdepasse" : cmotdepasse
			 },function(data){
				// if(data.match("succes")==null){
				// 	$("#error2").html(data).slideDown();
				// }else{
				// 	window.location.href="../Inter_ile/login.php?succes=1";
				// }
				alert(data);
			});
		});
		return false;
	});
});
