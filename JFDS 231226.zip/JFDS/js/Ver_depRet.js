// function depart() {
// 	var dep = $('#depart option:selected').text();
// 	alert(dep);
// }
$('#id_depart').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = optionSelected.val();
    for (var i = 1; i<=8; i++) {
      if (i == valueSelected) {
      document.getElementById('id_arriver').options[valueSelected].disabled = true;
      }
      else{
        document.getElementById('id_arriver').options[i].disabled = false;
      }
    }

});

$('#id_arriver').on('change', function (e) {
    var optionSelected = $("option:selected", this);
    var valueSelected = optionSelected.val();

    for (var i = 1; i<=8; i++) {
      if (i == valueSelected) {
      document.getElementById('id_depart').options[valueSelected].disabled = true;

      }
      else{
        document.getElementById('id_depart').options[i].disabled = false;
      }
    }
});
