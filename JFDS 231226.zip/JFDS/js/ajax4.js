

$("#add").submit(function(){
	
	var id_mess = $("#id_mess").val();
	var contenu = $("#contenu").val();
	var id_reservation = $("#id_reservation").val();

	var url = $(this).attr("action");

	$("#error").slideUp("888", function(){

		$.post(url,{
			id_mess:id_mess,
			contenu:contenu,
			id_reservation:id_reservation,
		 },function(data){
			if(data.match("succes")==null){
				$("#error").html(data).slideDown();
			}else{
				window.location.href="../Inter_ile/listRes.php?sucess=mod";
			}
		});
	});


	return false;
});
