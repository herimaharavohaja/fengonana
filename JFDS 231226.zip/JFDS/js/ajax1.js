$(document).ready(function(){
	$("#aller_retour").submit(function(){
		var depart = $("#id_depart").val();
		var arriver = $("#id_arriver").val();
		var date1 = $("#date_depart").val();
		var date2 = $("#date_retour").val();
		var prix = $("#prix").val();
		var avion = $("#id_avion").val();

		var url = $(this).attr("action");

		$("#error").slideUp("888", function(){

			$.post(url,{
				id_depart:depart,
				id_arriver:arriver,
				date_depart:date1,
				date_retour:date2,
				prix:prix,
				id_avion:avion
			 },function(data){
				if(data.match("succes")==null){
					$("#error").html(data).slideDown();
				}else{
					window.location.href="../Inter_ile/vol1.php?sucess=insert";
				}
			});
		});
		return false;
	});

	$("#login").submit(function(){
		var email = $("#email").val();
		var motdepasse = $("#motdepasse").val();

		var url = $(this).attr("action");

		$("#error").slideUp("888", function(){

			$.post(url,{
				email:email,
				motdepasse:motdepasse
			 },function(data){
				if(data.match("succes")==null){
					$("#error").html(data).slideDown();
				}else{
					window.location.href="../Inter_ile/index.php";
				}
			});
		});
		return false;
	});
});
