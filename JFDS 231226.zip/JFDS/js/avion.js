$(document).ready(function(){

	$("#add").submit(function(){
		var nb_place = $("#nb_place").val();

		var url = $(this).attr("action");

		$("#error").slideUp("888", function(){

			$.post(url,{
				nb_place:nb_place,
			 },function(data){
				if(data.match("succes")==null){
					$("#error").html(data).slideDown();
				}else{
					window.location.href="../Inter_ile/avion.php?success=tikaf";
				}
			});
		});


		return false;
	});

});
