$(document).ready(function(){

	$("#add").submit(function(){
		var contenu = $("#contenu").val();
		var id_reservation = $("#id_reservation").val();
		var id_client = $("#id_client").val();

		var url = $(this).attr("action");

		$("#error").slideUp("888", function(){

			$.post(url,{
				contenu:contenu,
				id_reservation:id_reservation,
				id_client:id_client,

			 },function(data){
				if(data.match("succes")==null){
					$("#error").html(data).slideDown();
				}else{
					window.location.href="../Inter_ile/listRes.php?success=tikaf";
				}
			});
		});


		return false;
	});

});
