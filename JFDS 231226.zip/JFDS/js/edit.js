$(document).ready(function(){

		$("#edit").submit(function(){
			var nb_place = $("#nb_place").val();
			var id_avion = $("#id_avion").val();

			var url = $(this).attr("action");

			$("#error1").slideUp("888", function(){

				$.post(url,{
					nb_place:nb_place,
					id_avion:id_avion,
				 },function(data){
					if(data.match("succes")==null){
						$("#error1").html(data).slideDown();
					}else{
						window.location.href="../Inter_ile/avion.php?success=gamaliel";
					}
				});
			});


			return false;
		});
});
