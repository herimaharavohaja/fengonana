<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
 $etatActivite = "AND etatActivite = '1'";
// $sqlA = "SELECT * FROM proactivite INNER JOIN konty ON konty.idKonty = proactivite.idKonty";

$sqlA = "SELECT libActivite, debutActivite, finActivite, placeActivite, libCategorie, libPseudo as pseudo FROM proactivite 
LEFT JOIN konty ON konty.idKonty = proactivite.idKonty
UNION
SELECT libEv as libActivite, debutEv as debutActivite, finEv as finActivite, placeEv as placeActivite, '' as libCategorie, '' as pseudo FROM ev";

$resultA = $conn->query($sqlA);

$events = array();

while ($rowA = $resultA->fetch_assoc()) {
    $abbreviation = ''; // Initialisez la variable d'abréviation
    switch ($rowA['libCategorie']) {
        case 'superAdmin':
            $pointVert = '<span class="point" style="background-color: #0ced5b;"></span>';
            break;
        case 'admin':
            $pointVert = '<span class="point" style="background-color: #0ced5b;"></span>';
            break;
        case 'user':
            $pointVert = '<span class="point" style="background-color: #eded0c;"></span>';
            break;
        default:
            $pointVert = '<span class="point" style="background-color: white;"></span>'; // Ajoutez des cas pour d'autres catégories si nécessaire
    }

    $events[] = array(
        'title' => $rowA['libActivite'],
        'start' => $rowA['debutActivite'],
        'place' => $rowA['placeActivite'],
        'pseudo' => $rowA['pseudo'],
        'cat' => $rowA['libCategorie'],
        'abbreviation' => $abbreviation, 
        'pointVert' => $pointVert,
        'end' => $rowA['finActivite']
    );
}

?>

    <link href="fullcalendar-5.7.2/lib/main.min.css" rel="stylesheet" />
    <script src="fullcalendar-6.1.8/dist/index.global.min.js"></script>

<?php include 'pannelAmbony.php'; ?>   
  
    <div class="container" >
	    <div class="row">
	    	<center>
		    	<h3 class="ml-2 font-weight-bold text-primary">Teti-andro</h3>
		    	<br>
		    </center>
		    <div class="col-md-12">
		       
		        <div id="calendar" style="max-height: 450px;"></div>

				<script>
					document.addEventListener('DOMContentLoaded', function() {
					    var calendarEl = document.getElementById('calendar');
					    var calendar = new FullCalendar.Calendar(calendarEl, {
					        initialView: 'dayGridMonth',
					        events: <?php echo json_encode($events); ?>,
					        eventContent: function(arg) {
                                var pseudo = arg.event.extendedProps.pseudo;
					            var place = arg.event.extendedProps.place;
					            var title = arg.event.title;
					            var abbreviation = arg.event.extendedProps.abbreviation;
					            var pointVert = arg.event.extendedProps.pointVert;
					            var html = '<div style="background-color: #4e73df;text-align: center;">' +
					                '<div>' + pointVert + title + '<br>' + 
                                        '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + place + '</div>' +
					                '</div>';
					            return { html: html };
					        }
					    });
					    calendar.setOption('locale', 'fr');
					    calendar.render();
					});
</script>


		    </div>
	    </div>
    <br>
    
</div>
<br><br><br><br>
<?php include 'pannelAmbany.php';  ?> 

<style type="text/css">
   
   .point {

    height: 7px; 
    width: 8px; 
    border-radius: 50%; 
    display: inline-block; 
    margin: 10px 5px 0 0; 
}

</style>

