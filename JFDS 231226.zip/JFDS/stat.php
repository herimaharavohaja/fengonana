<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 ?>
<?php include 'pannelAmbony.php'; ?> 
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    .collapsible-container {
      display: flex;
      justify-content: space-between;
      margin-top: -24px;
    }

    .collapsible {
      background-color: #777;
      color: white;
      cursor: pointer;
      padding: 18px;
      flex-grow: 1;
      border: none;
      text-align: center;
      outline: none;
      font-size: 15px;
      transition: background-color 0.3s;
    }
    .collapsible:hover {
      background-color: skyblue; /* Changement de couleur au survol de la souris */
    }

    .collapsible.active {
      background-color: #555; /* Couleur différente pour le bouton actif */
    }

    .content {
      padding: 0 18px;
      display: none;
      overflow: hidden;
      background-color: #f1f1f1;
      width: 100%;
    }
  </style>
</head>
<body>

<div class="collapsible-container">
  <button class="collapsible" onclick="toggleCollapse('section1')">Membres par année</button>
  <?php
  	if ($cat == 'superAdmin' OR $cat == 'Admin') {
  	 	?>
  	 	<button class="collapsible" onclick="toggleCollapse('section2')">Budget mensuel</button>
  <?php
  	} 
  ?>
  <button class="collapsible" onclick="toggleCollapse('section3')">Sexe par année</button>
  <button class="collapsible" onclick="toggleCollapse('section4')">Activités par mois</button>
</div>

<div class="content" id="section1">
  <!-- <p>Contenu de la section 1...</p> -->
  <br>
  <h4 class="text-center">
                        	<b><?php echo ("Membres par année"); ?></b>
                        	<a href="fpdf/membre.php" style="text-decoration: none;">
								<button class="btn btn-secondary">PDF</button>
							</a>
						</h4>
				        <?php
// Connexion à la base de données
include 'connect.php';

// Requête SQL pour sélectionner le nombre de membres par année
$sql = "SELECT YEAR(dteUser) AS annee, COUNT(*) AS total FROM user GROUP BY YEAR(dteUser)";
$result = $conn->query($sql);

// Vérifier s'il y a des données
if ($result->num_rows > 0) {
    // Initialiser un tableau pour stocker les données
    $stat = array();

    // Récupérer les données de la requête SQL
    while ($row = $result->fetch_assoc()) {
        $stat[] = $row;
    }
} else {
    echo "Aucune donnée trouvée.";
}
?>
    <canvas id="myChart" width="400" height="150"></canvas>

    <script>
        // Récupérez les données PHP dans JavaScript
        var statistiques = <?php echo json_encode($stat); ?>;

        // Préparez les données pour le graphique
        var labels = [];
        var data = [];

        statistiques.forEach(function (stat) {
            labels.push(stat.annee);
            data.push(stat.total);
        });

        // Créez le graphique
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Nombre de membres par an',
                    data: data,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</div>

<div class="content" id="section2">
  <br>
  <h4 class="text-center">
		      				<b><?php echo ("Budget mensuel"); ?></b>
		      				<a href="fpdf/vola.php" style="text-decoration: none;">
								<button class="btn btn-secondary">PDF</button>
							</a>
		      			</h4>
				        <?php 

                    $sqlkontyC = "SELECT 
                    YEAR(daty) AS annee,
                    MONTHNAME(daty) AS mois,
                    SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END) AS entree,
                    SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END) AS sortie
                    FROM caisse
                    GROUP BY mois, annee
                    ORDER BY annee, MONTH(daty)";


						$resultkontyC = $conn->query($sqlkontyC);
						$statC = array();
						if ($resultkontyC->num_rows > 0 ) {
						    // Affichage des données de chaque utilisateur
						    while($rowC = $resultkontyC->fetch_assoc()) {
						    	// $i = $i+1;
						    	$statC[] = $rowC;

						    	$totalMembre = 0;
								foreach ($statC as $statsC) {
									// $totalMembre += $stats['total'];
									$pourc = (($statsC['entree'] - $statsC['sortie']));

								}
						    }
						} 
					
						else {
						    echo "Néant";
						}
		          		?>
    					<canvas id="myChartC" width="400" height="150"></canvas>

						<script>
						    // Récupérez les données PHP dans JavaScript
var statistiquesC = <?php echo json_encode($statC); ?>;

// Préparez les données pour le graphique
var labelsC = [];
var entreeData = [];
var sortieData = [];

statistiquesC.forEach(function (statC) {
    labelsC.push(statC.mois);  // Utilisez le mois comme étiquette
    entreeData.push(statC.entree);
    sortieData.push(statC.sortie);
});

// Créez le graphique en ligne
var ctxC = document.getElementById('myChartC').getContext('2d');
var myChartC = new Chart(ctxC, {
    type: 'line',
    data: {
        labels: labelsC,
        datasets: [{
            label: 'Entrée',
            data: entreeData,
            borderColor: 'rgba(75, 192, 192, 1)',  // Couleur verte
            backgroundColor: 'rgba(75, 192, 192, 0.2)',  // Remplissage vert
            fill: true,
        }, {
            label: 'Sortie',
            data: sortieData,
            borderColor: 'rgba(255, 99, 132, 1)',  // Couleur rouge
            backgroundColor: 'rgba(255, 99, 132, 0.2)',  // Remplissage rouge
            fill: true,
        }]
    },
    options: {
        scales: {
            x: {  // Axe des abscisses (X) pour les mois
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Mois'
                }
            },
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Montant'
                }
            }
        },
        plugins: {
            legend: {
                display: true,
                position: 'right'
            },
            datalabels: {
                align: 'end',
                anchor: 'end',
                formatter: function(value, context) {
                    return value.toFixed(2) + ' %';
                }
            }
        }
    }
});



						</script>
</div>

<div class="content" id="section3">
  <!-- <p>Contenu de la section 3...</p> -->
  <br>
  <?php include 'statSexe.php'; ?>
</div>

<div class="content" id="section4">
  <!-- <p>Contenu de la section 4...</p> -->
  <br>
  <?php include 'divStatActivite.php'; ?>
</div>

<script>
  function toggleCollapse(sectionId) {
    var contents = document.getElementsByClassName('content');
    for (var i = 0; i < contents.length; i++) {
      contents[i].style.display = 'none';
    }

    var buttons = document.getElementsByClassName('collapsible');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].classList.remove('active');
    }

    var content = document.getElementById(sectionId);
    content.style.display = 'block';

    var button = document.querySelector('[onclick="toggleCollapse(\'' + sectionId + '\')"]');
    button.classList.add('active');
  }
</script>

		                

<br><br>
<?php include 'pannelAmbany.php'; ?> 