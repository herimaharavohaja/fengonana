<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->
			<div class="col-md-12">
                <div class="">
                	<div >
                        <h4 class="text-center">
                        	<b><?php echo ("Sexe par année"); ?></b>
                        	<a href="fpdf/sexe.php" style="text-decoration: none;">
								<button class="btn btn-secondary">PDF</button>
							</a>
                        </h4>
                        
                    </div>
                    <div class="text-center">
				          <?php 

						// Requête SQL pour sélectionner tous les utilisateurs
						$sqlkonty1 = "SELECT YEAR(dteUser) AS annee, MONTHNAME(dteUser) AS mois, sexeUser, COUNT(*) AS total 
						FROM user 
						GROUP BY YEAR(dteUser), MONTH(dteUser), sexeUser;
						";
						$resultkonty1 = $conn->query($sqlkonty1);
						$stat = array();
						    // Affichage des données de chaque utilisateur
						    while($row1 = $resultkonty1->fetch_assoc()) {
						    	// $i = $i+1;
						    	$annee = $row1["annee"];
						    	$sexeUser = $row1["sexeUser"];
						    	$total = $row1["total"];

						    	if (!isset($stat[$annee])) {
						    		$stat[$annee] = array(
						    			'hommes' => 0,
						    			'femmes' => 0,
						    			'total1' => 0
						    		);
						    	}
						    	if ($sexeUser == 'Masculin') {
						    		$stat[$annee]['hommes'] = $total;
						    	} elseif ($sexeUser == 'Féminin') {
						    		$stat[$annee]['femmes'] = $total;
						    	}
						    	$stat[$annee]['total1'] += $total;
						    	}
						    	foreach ($stat as $annee => $data) {
						    		$total1 = $data['total1'];
									$pourcentageH = ($data['hommes'] / $total1) * 100;
									$pourcentageF = ($data['femmes'] / $total1) * 100;

									$stat[$annee]['pourcentage_hommes'] = $pourcentageH;
									$stat[$annee]['pourcentage_femmes'] = $pourcentageF;

									 
								?>
		          				<!-- <tr>
		          					<td><?php echo $annee; ?></td>
				                    <td><?php echo $data['hommes']; ?></td>
				                    <td><?php echo $data['femmes']; ?></td>
				                    <td><?php echo round($pourcentageH, 2); ?> %</td>
				                    <td><?php echo round($pourcentageF, 2); ?> %</td>
	                    		</tr> -->
		          <?php }
		          ?>

						  <div>
    <canvas id="myLineChart" width="400" height="150"></canvas>
</div>

<script>
var statistiques = <?php echo json_encode($stat); ?>;

// Préparer les données pour le graphique
var labels = [];
var hommesData = [];
var femmesData = [];

Object.keys(statistiques).forEach(function (annee) {
    labels.push(annee);
    hommesData.push(statistiques[annee].hommes);
    femmesData.push(statistiques[annee].femmes);
});

var ctx = document.getElementById('myLineChart').getContext('2d');
if (myLineChart) {
    myLineChart.destroy();  // Détruire le graphique existant s'il y en a un
}

var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            data: hommesData,
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            label: 'Hommes'
        }, {
            data: femmesData,
            borderColor: 'rgba(255, 99, 132, 1)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            label: 'Femmes'
        }]
    },
    options: {
        scales: {
            x: {
                type: 'category', // Utiliser des catégories pour les mois
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Mois'
                }
            },
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Nombre'
                }
            }
        },
        plugins: {
            legend: {
                position: 'right'
            }
        }
    }
});

</script>

		      			<!-- <form method="GET" action="export.php">
		                    <a class="pull-right" href="export.php?sce=<?php echo $data['total1']; ?>">

		                    	<button type='submit' name='submit' class='btn btn-success'>
									<span  class='bi bi-printer-fill'> IMPRIMER</span>
								</button>
							</a>
		                </form> -->
		                    </div>
		                    <br><br>
		                </div>
		            </div>