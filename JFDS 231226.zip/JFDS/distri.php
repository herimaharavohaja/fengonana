<?php
include 'connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$cat = $_SESSION['libCategorie'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numBillet = $_POST["numBillet"];
    $idOperation = $_POST["idOperation"];
    // Requête pour vérifier si le billet est payé
    $query = "SELECT * FROM billet WHERE idOperation = '$idOperation' AND FIND_IN_SET('$numBillet', paye) > 0";

    $result = $conn->query($query);

    // Requête pour vérifier si le billet est distribué
    $queryDistri = "SELECT * FROM billet WHERE idOperation = '$idOperation' AND FIND_IN_SET('$numBillet', distri) > 0";

    $resultDistri = $conn->query($queryDistri);

    if ($result->num_rows > 0) {
        // Le billet est payé
        $row = $result->fetch_assoc();
        $idBillet = $row['idBillet'];
        $idOperation = $row['idOperation'];

        if ($resultDistri->num_rows > 0) {
            // Le billet est également distribué
            $message = "Le billet est payé et distribué!";
        } else {
            // Le billet n'est pas distribué
            $message = "Le billet est payé! ";
        }
    } else {
        $message = "Le billet n'est pas payé!";
        $idBillet = null;
        $idOperation = null;
    }

    // Envoyer une réponse JSON pour AJAX
    header('Content-Type: application/json');
    echo json_encode(['message' => $message, 'idBillet' => $idBillet, 'idOperation' => $idOperation, 'numBillet' => $numBillet]);
    exit;
}
?>
<?php include 'pannelAmbony.php'; ?>
<?php include 'navCompte2.php'; ?>
<br>

<div class="container" style="border-radius: ">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow ">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Vérifier</h6>
                </div>
                <div class="card-body" style='max-height: 400px; overflow-y: auto;'>
                    <form id="verificationForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                       <div >
                        <!-- <label class="form-label" >Opérations</label> -->
                        <?php 
                                    $sqlOperation = "SELECT * FROM operation";
                                    $resultOperation = $conn->query($sqlOperation);

                                    $optionOperation = [];
                                    if ($resultOperation->num_rows > 0) {
                                        while ($rowOperation = $resultOperation->fetch_assoc()) {
                                            $optionOperation[] = $rowOperation;
                                        }
                                    }
                        ?>
                        <div class="form-outline mb-4">
                            <select name="idOperation" required class="form-control" style="width: 140px;">
                                        <option value="" disabled selected hidden>Opération</option>
                                        <?php foreach ($optionOperation as $optionOperation ) : ?>
                                            <option value="<?php echo $optionOperation['idOperation']; ?>">
                                                
                                                <?php echo $optionOperation['libOperation']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                        </div>
                    </div>
                    <label for="numBillet">Numéro de Billet :</label>
                        <input type="text" id="numBillet" name="numBillet" required />
                        <br/></br>
                        <button type="button" onclick="verifierBillet()" class="btn btn-info">Vérifier</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Résultat</h6>
                </div>
                <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                    <!-- <p id="resultatMessage"><?php echo $message; ?></p> -->
                    <div id="resultatMessage"></div>

                </div>
            </div>
        </div>
    </div>
</div>
<br/><br/>
<?php include 'pannelAmbany.php'; ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    // Fonction pour effectuer l'insertion dans la colonne distri
    function insererDansDistri(idBillet, idOperation, numBillet) {
    fetch('update_distri.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ idBillet: idBillet, idOperation: idOperation, numBillet: numBillet }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur réseau ou serveur');
        }
        return response.json();
    })
    .then(data => {
        alert(data.message);
    })
    .catch(error => {
        console.error('Erreur:', error.message);
    });
}

// Fonction pour afficher le message dans un bouton
function afficherMessage(response) {
    var resultatMessage = document.getElementById('resultatMessage');
    resultatMessage.innerHTML = response.message;

    // Si le message est "Le billet est payé", afficher le bouton "Distribué"
    if (response.message === "Le billet est payé! ") {
        var boutonInserer = document.createElement('button');
        boutonInserer.innerText = 'Distribuer';
        boutonInserer.classList.add('btn', 'btn-success');
        boutonInserer.addEventListener('click', function () {
            insererDansDistri(response.idBillet, response.idOperation, response.numBillet);
        });

        resultatMessage.appendChild(boutonInserer);
    }
}



// Fonction pour vérifier le billet
function verifierBillet() {
    var form = document.getElementById('verificationForm');
    var formData = new FormData(form);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', form.action, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            console.log(response); // Ajoutez cette ligne pour débuguer
            afficherMessage(response);
        }
    };
    xhr.send(formData);
}

// Ajoutez un écouteur d'événements pour la touche "Entrée" sur le champ de texte
document.getElementById('numBillet').addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
        verifierBillet();
    }
});



</script>