<?php
// saveEdit.php
include 'connect.php';  

header('Content-Type: application/json');

// Récupérer les données du corps de la requête
$data = json_decode(file_get_contents('php://input'), true);

// Ajoutez des logs pour afficher les données reçues
file_put_contents('log.txt', print_r($data, true), FILE_APPEND);

if ($data && isset($data['id']) && isset($data['editedCode']) && isset($data['editedValue'])) {
    // Utilisez les données pour mettre à jour la base de données
    $id = $data['id'];
    $editedCode = $data['editedCode'];
    $editedValue = $data['editedValue'];

    // Échapper les valeurs pour éviter les injections SQL
    $editedCode = $conn->real_escape_string($editedCode);
    $editedValue = $conn->real_escape_string($editedValue);
    $id = (int)$id;

    // Exécuter la requête SQL de mise à jour
    $query = "UPDATE faritra SET codeFaritra = '$editedCode', libFaritra = '$editedValue' WHERE idFaritra = $id";

    // Ajoutez des logs pour afficher la requête SQL
    file_put_contents('log.txt', "\n$query\n", FILE_APPEND);

    if ($conn->query($query) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }

    // Fermer la connexion à la base de données
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Données non valides']);
}
?>
