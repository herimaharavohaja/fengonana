	<div class="container">
			<div class="col-md-12">
                <div class="">
                	<div >
                        <h4 class="text-center"><b><?php echo ("Statistique sur le type de Sakramenta par année"); ?></b></h4>
                        
                    </div>
                    <div class="text-center">
                        <table class="table table-bordered">
				        <thead class="alert-success ">

						  <tr class="text-center">
				            <!-- <th>N°</th> -->
				            <th class="text-center">Année</th>
				            <th class="text-center">Sakramenta</th>
				            <th class="text-center">Nombre</th>
				          </tr>
				        </thead>
				        <tbody>
				          <?php 

						// Requête SQL pour sélectionner tous les utilisateurs
						$sqlkonty2 = "SELECT YEAR(dteSakramenta) AS annee, libSakramenta, count(*) AS nb FROM sakramenta GROUP BY annee, libSakramenta ORDER BY annee, libSakramenta";
						$resultkonty2 = $conn->query($sqlkonty2);
						$stat2 = array();
						    // Affichage des données de chaque utilisateur
						    while($row2 = $resultkonty2->fetch_assoc()) {
								?>
		          				<tr>
		          					<td><?php echo $row2['annee']; ?></td>
				                    <td><?php echo $row2['libSakramenta']; ?></td>
				                    <td><?php echo $row2['nb']; ?></td>
	                    		</tr>
		          <?php 
		      }

					// Fermeture de la connexion
		          ?>
		          
		          </tbody>
		      			</table>
		      			<form method="GET" action="export.php">
		                    <a class="pull-right" href="export.php?sce=<?php echo $row2['nb']; ?>">
		                    	<button type='submit' name='submit' class='btn btn-success'>
									<span  class='bi bi-printer-fill'> IMPRIMER</span>
								</button>
							</a>
		                </form>
		                    </div>
		                    <br><br>
		                </div>
		            </div>
		        </div>