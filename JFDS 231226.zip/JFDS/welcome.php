
            <?php 
            session_start();
            include 'connect.php';
            $idKonty = $_SESSION['idKonty'];
            $lib = $_SESSION['libCategorie'];
            // echo $idKonty;
            include 'pannelAmbony.php';    
            
            ?>

    <div class="container">
        <div class="row" style="margin: 5px;border-radius: 10px;">
            <div class="col-md-<?php echo $lib == 'membre' ? 12 : 6 ; ?>" style="background-color: white;">
            
                <?php
                    echo "<h6 style='margin: 10px;'>Activités d'aujourd'hui</h6>";
                    
                    // Requête SQL pour récupérer les activités d'aujourd'hui
                    $sql = "SELECT * FROM proactivite 
                    INNER JOIN konty ON konty.idKonty = proactivite.idKonty
                    WHERE CURDATE() BETWEEN debutActivite AND finActivite
                    ";

                    $resultat = mysqli_query($conn, $sql);

                    // Vérification s'il y a des activités aujourd'hui
                    if (mysqli_num_rows($resultat) > 0) {
                        
                        echo "<div style='max-height: 200px; overflow-y: auto;'>"; 
                        while ($ligne = mysqli_fetch_assoc($resultat)) {

                        // La requête a une réponse, affichez la date d'aujourd'hui et le mois
                        $dateAujourdhui = date('d');
                        $mois = date('M');

                        echo '<div style="display: grid; grid-template-columns: 0.2fr 4fr;">';
                        // Left part with month and date
                        echo '<div class="label">';
                            echo '<div style="background: red; color: white;border-top-left-radius: 10px; border-top-right-radius: 10px;">' . $mois . '.</div>';
                            echo '<div>' . $dateAujourdhui . '</div>';
                        echo '</div>';

                        // Right part with activity label
                        echo '<div style="margin: 10px;text-align: left;">' . $ligne['libActivite'] . '</div>';
                        echo '</div><br>';

                    }
                    echo '</div>';
                    } else {
                        echo "<br><br><p style='text-align: center;'>Aucune activité aujourd'hui.</p>";
                    }
                ?>
                <style>
                    /* Ajoutez du style CSS ici selon vos besoins */
                    body {
                        font-family: Arial, sans-serif;
                        text-align: center;
                        /* margin: 20px; */
                    }
                    .label {
                        border: 1px solid #ccc;
                        width: 50px;
                        margin: 0 auto;
                        border-radius: 10px;    
                        max-height: 55px;

                    }
                </style>

            </div>
            <?php
            if ($lib == "membre") :
                // Code for the 'membre' case
            else :
            ?>
                <div class="col-md-6" style="background-color: white;">
                    <?php include('divEquipe.php'); ?>
                </div>
            <?php
            endif;
            ?>

            
        </div>
        <br>
        <div class="row" style="margin: 5px;">
            <div class="col-md-<?php echo $lib == 'membre' ? 12 : 6 ; ?>" style="background-color: white;border-radius: 10px;">

                <?php
                    echo "<h6 style='margin: 10px;'>Evènement à venir</h6>";
                    // Requête SQL pour récupérer les activités d'aujourd'hui
                    $sqlEv = "SELECT *, 
                            ABS(DATEDIFF(CURDATE(), debutEv)) AS nombreJours, 
                            DAY(debutEv) AS dateDebutEv, 
                            DATE_FORMAT(debutEv, '%b') AS moisAbbr
                    FROM `ev` 
                    WHERE debutEv >= CURDATE();
                    ";

                    $resultatEv = mysqli_query($conn, $sqlEv);

                    // Vérification s'il y a des activités aujourd'hui
                    if (mysqli_num_rows($resultatEv) > 0) {
                        
                        echo "<div style='max-height: 200px; overflow-y: auto;'>"; 
                        
                        while ($ligneEv = mysqli_fetch_assoc($resultatEv)) {

                            // La requête a une réponse, affichez la date d'aujourd'hui et le mois
    
                            echo '<div style="display: grid; grid-template-columns: 0.2fr 4fr;">';
                            // Left part with month and date
                            echo '<div class="label">';
                                echo '<div style="background: red; color: white;border-top-left-radius: 10px; 
                                    border-top-right-radius: 10px;">' . $ligneEv['moisAbbr'] . '.</div>';
                                echo '<div>' . $ligneEv['dateDebutEv'] . '</div>';
                            echo '</div>';
    
                            // Right part with activity label
                            echo '<div style="margin-left: 10px;text-align: left;">' . $ligneEv['libEv'] . '<br> 
                                Dans ' . $ligneEv['nombreJours'] . ' jour' . ($ligneEv['nombreJours'] > 1 ? 's' : '') . '</div>';

                            echo '</div><br>';
    
                        }
                        echo '</div>';

                    } else {
                        echo "<br><br><p style='text-align: center;'>Aucune évènement à venir.</p>";
                    }
                ?>

            </div>

            <?php
            if ($lib == "membre") :
                // Code for the 'membre' case
            else :
            ?>
            <div class="col-md-6" style="background-color: white;border-radius: 10px;">
                <h6 style='margin: 10px;'>Historique de la présence </h6>
                <div style='max-height: 200px; overflow-y: auto;'>
                    
                
                <select id="selectEvent" class="form-control">
                    <?php
                    
                    $reqUser = $lib == "User" ? 'AND idKonty = ' . $idKonty : '';
                    // Requête SQL pour récupérer les options
                    $sql8 = "SELECT * FROM proactivite WHERE dtePresence != '' $reqUser ORDER BY dtePresence DESC";
                    $result8 = $conn->query($sql8);

                    if ($result8->num_rows > 0) {
                        while ($row8 = $result8->fetch_assoc()) {
                            echo '<option value="' . $row8['libActivite'] . '">' . $row8['libActivite'] . '</option>';
                        }
                    } else {
                        echo "<br><br><p style='text-align: center;'>Aucune fiche de présence.</p>";
                    }
                    ?>
                </select>
                <div id="nomUtilisateur"></div>
                </div>
                    <style type="text/css">
                       
                       .point-vert {

                        height: 7px; /* Hauteur du point */
                        width: 8px; /* Largeur du point */
                        border-radius: 50%; /* Pour rendre le point circulaire */
                        background-color: green; /* Couleur verte du point */
                        display: inline-block; /* Pour afficher le point en ligne avec le texte */
                        margin: 10px 5px 0 0; 
                    }
                    .point-rouge {

                        height: 7px; /* Hauteur du point */
                        width: 8px; /* Largeur du point */
                        border-radius: 50%; /* Pour rendre le point circulaire */
                        background-color: red; /* Couleur verte du point */
                        display: inline-block; /* Pour afficher le point en ligne avec le texte */
                        margin: 10px 5px 0 0; 
                    }

                    </style>
                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                    <script>

                        // Fonction pour récupérer et afficher le nomUser en fonction de libActivite
                    function afficherNomUtilisateur(libActivite) {
                        $.ajax({
                            type: "GET",
                            url: "backWecome.php",
                            data: {
                                libActivite: libActivite
                            },
                            dataType: "json",
                            success: function(response) {
                                if (response && response.nomUser) {
                                    var nomUser = response.nomUser;
                                    var present = response.present;
                                    var eff = response.eff;
                                    var tableHtml = '<div class="">';
                                    // tableHtml += '<table class="table">';
                                    tableHtml += '<br><p>Effectif: (' + present + ' / ' + eff + ')</p>';
                                    tableHtml += '<p>' + nomUser + '</p>';
                                    // tableHtml += '</table>';
                                    tableHtml += '</div>';


                                // Affichez le tableau dans la balise <div>
                                $("#nomUtilisateur").html(tableHtml);
                                } else {
                                    $("#nomUtilisateur").text("Aucun utilisateur trouvé.");
                                }
                            },
                            error: function() {
                                $("#nomUtilisateur").text("");
                            }
                        });
                    }

                    // Appel de la fonction lors du chargement initial de la page avec la valeur par défaut de la balise select
                    $(document).ready(function() {
                        var libActivite = $("#selectEvent").val(); // Obtenez la valeur par défaut de la balise select
                        afficherNomUtilisateur(libActivite); // Appelez la fonction pour afficher le nomUser
                    });

                    // Écouteur d'événement pour le changement de la balise select
                    document.getElementById("selectEvent").addEventListener("change", function() {
                        var libActivite = this.value;
                        afficherNomUtilisateur(libActivite); // Appelez la fonction pour afficher le nomUser
                    });


                    </script>
            </div>
        </div>
        <?php
        endif;
        ?>   
    </div>
    <br><br>
            <?php 
            include 'pannelAmbany.php';
             ?> 


            <style>
                /* Styles pour le badge */
                .modal-content {
                    border: 2px solid #007BFF;
                    border-radius: 10px;
                }
                
                .modal-title {
                    font-size: 1.2rem;
                    text-align: center;
                }

                #user-photo {
                    border: 2px solid #007BFF;
                    border-radius: 50%;
                    display: block;
                    margin: 0 auto;
                }

                #user-details {
                    text-align: center;
                    padding: 20px;
                }

                #user-details strong {
                    color: #007BFF;
                    font-weight: bold;
                }
            </style>

