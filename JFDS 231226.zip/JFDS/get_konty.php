<?php
// Inclure votre fichier de connexion à la base de données
include 'connect.php';

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer l'ID de l'opération sélectionnée
    if (isset($_POST['idOperation'])) {
        $idOperation = $_POST['idOperation'];

        // Requête pour récupérer les membres liés à l'opération sélectionnée dans le billet
        $sqlKonty = "SELECT DISTINCT konty.idKonty, konty.nomKonty, konty.prenomKonty
                    FROM `billet` 
                    LEFT JOIN konty ON konty.idKonty = billet.idKonty
                    WHERE billet.idOperation = '$idOperation'";
        $resultKonty = $conn->query($sqlKonty);

        $optionKonty = [];
        if ($resultKonty->num_rows > 0) {
            while ($rowKonty = $resultKonty->fetch_assoc()) {
                $optionKonty[] = $rowKonty;
            }
        }

        // Retourner les données au format JSON
        header('Content-Type: application/json');
        echo json_encode($optionKonty);
    } else {
        // Afficher un message d'erreur si l'ID de l'opération n'est pas présent
        echo 'Veuillez sélectionner une opération.';
    }
}

// Fermer la connexion à la base de données
$conn->close();
?>
