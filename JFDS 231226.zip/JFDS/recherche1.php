<?php

include 'connect.php';
// Vérification de la soumission du formulaire
session_start();
$cat = $_SESSION['libCategorie'];
$fari = $_SESSION['idFaritra'];

?>

<?php include 'pannelAmbony.php'; ?>

<div class="container">
    <h4>Rechercher :</h4>
    <div class="row">
        <div class="col-md-3">
            
            <select id="faritraSelect" onchange="loadMembers()" class="form-control">
                <!-- Options seront chargées dynamiquement depuis la base de données -->
            </select>
            <br>
            <select id="masinaSelect" onchange="loadMembers()" class="form-control">
                <!-- Options Masina seront chargées dynamiquement depuis la base de données -->
            </select>
            <br>
            <select id="vaomieraSelect" onchange="loadMembers()" class="form-control">
                <!-- Options Masina seront chargées dynamiquement depuis la base de données -->
            </select>
            <br>
            <button type="button" class="btn btn-secondary" onclick="resetFilters()">Réinitialiser </button>
        </div>
        <div class="col-md-9" id="resultContainer"></div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    // Charger les faritra au chargement de la page
    $(document).ready(function() {
        loadFaritraOptions();
        loadMasinaOptions();
        loadVaomieraOptions();
    });

    // Fonction pour charger les options Faritra depuis la base de données
    function loadFaritraOptions() {
        $.ajax({
            url: 'get_faritra.php', // Fichier PHP pour récupérer les faritra depuis la base de données
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                // Ajouter les options au sélecteur
                var select = $('#faritraSelect');
                select.empty(); // Nettoyer le sélecteur
                // Ajouter une option par défaut
                select.append('<option value="">Faritra</option>');


                $.each(response, function(index, faritra) {
                    select.append('<option value="' + faritra.idFaritra + '">' + faritra.libFaritra + '</option>');
                });
            },
            error: function(error) {
                console.error('Erreur lors du chargement des faritra:', error);
            }
        });
    }

    // Fonction pour charger les options Masina depuis la base de données
    function loadMasinaOptions() {
        $.ajax({
            url: 'get_masina.php', // Fichier PHP pour récupérer les masina depuis la base de données
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                var select = $('#masinaSelect');
                select.empty(); // Nettoyer le sélecteur
                select.append('<option value="">Fikambanana Masina</option>');
                $.each(response, function(index, masina) {
                    select.append('<option value="' + masina.idMasina + '">' + masina.libMasina + '</option>');
                });
            },
            error: function(error) {
                console.error('Erreur lors du chargement des masina:', error);
            }
        });
    }

    // Fonction pour charger les options Vaomiera depuis la base de données
    function loadVaomieraOptions() {
        $.ajax({
            url: 'get_vaomiera.php', // Fichier PHP pour récupérer les masina depuis la base de données
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                var select = $('#vaomieraSelect');
                select.empty(); // Nettoyer le sélecteur
                select.append("<option>Vaomieran'asa</option>");
                $.each(response, function(index, vaomiera) {
                    select.append('<option value="' + vaomiera.idVaomiera + '">' + vaomiera.libVaomiera + '</option>');
                });
            },
            error: function(error) {
                console.error('Erreur lors du chargement :', error);
            }
        });
    }


    // Fonction pour charger les membres en fonction du faritra sélectionné
    function loadMembers() {
        var selectedFaritra = $('#faritraSelect').val();
        var selectedMasina = $('#masinaSelect').val();
        var selectedVaomiera = $('#vaomieraSelect').val();

        $.ajax({
            url: 'get_membres.php', // Fichier PHP pour récupérer les membres depuis la base de données
            type: 'GET',
            data: { faritra: selectedFaritra, masina: selectedMasina, vaomiera: selectedVaomiera },
            dataType: 'html',
            cache: false,
            success: function(response) {
                $('#resultContainer').html(response);
            },
            error: function(error) {
                console.error('Erreur lors du chargement des membres:', error);
            }
        });
    }


    // Fonction pour réinitialiser les filtres
    function resetFilters() {
        location.reload();
    }
</script>

<?php include 'pannelAmbany.php'; ?>


