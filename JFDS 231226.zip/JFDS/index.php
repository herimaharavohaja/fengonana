
<?php include "nav.php"; ?> 
<body class="bg-gradient-primary">
     <!-- style="background: url('./img/logoM.jpeg');background-size: cover;
    background-position: center;
    background-repeat: no-repeat;" -->
    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">
                <br><br><br>
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block" style="">
                                <div class="text-center" style="margin-top: 60px;">      
                                    <label style="font-weight: bold;">EKAR MD PIERA SY MD PAOLY SOAVIMASOANDRO</label>
                                    <img src="./img/logoM1.jpeg" class="img-fluid" style="border-radius: 20px;">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="" style="padding: 50px 5px">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Bienvenu</h1>
                                    </div>
                                    <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <h6 class="text-center" >Vovonan'ny Tanora Soavimasoandro </h6>
                                            </div>
                                    </div>
                                    <form class="user" method="post" action="auth.php">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user"
                                                name="libPseudo"
                                                placeholder="Pseudo"
                                                required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                name="libPass" placeholder="Mot de passe" required>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary btn-block btn-user">Se connecter
                                        </button>
                                        <br>
                                        <div class="form-group text-center">
                                            <div>
                                                <a href="mailto:vdktsoavimasoandro@gmail.com">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                                                      <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z"/>
                                                    </svg>
                                                    vdktsoavimasoandro@gmail.com

                                                </a>
                                            </div>
                                            <div>
                                                <a href="#">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                                                      <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                                                    </svg>
                                                    Vovonan'ny Tanora Katolika Soavimasoandro

                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
</body>
<style type="text/css">
    .box{

        background-image: url('./img/logo.png');   
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
    }
</style>