<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $sql = "SELECT *
      FROM activite
      WHERE idActivite = $ida";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  // $id = $row['id'];
  $libActivite = $row['libActivite'];
  }


  if (isset($_POST['modif'])) {
  $libActivite = $conn->real_escape_string(($_POST['libActivite']));

    $query = "UPDATE activite SET libActivite='$libActivite' WHERE idActivite = $ida";
    $result1 = $conn->query($query);
     header("Location:creaActivite.php");
  }else{
  }


 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Modification d'activité</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">



                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Libellé</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libActivite" class="form-control" value="<?php echo $libActivite; ?>"/>
                        </div>
                    </div>
                    <div class="mb-3">

                        <input type="submit" class="btn btn-info" name="modif" value="Modifier"  />
                    </div>
                </form>
                                </div>
                            </div>
    </div>
    <div class="col-md-4"></div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 