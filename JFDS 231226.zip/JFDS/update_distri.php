<?php
include 'connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$cat = $_SESSION['libCategorie'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $postData    = json_decode(file_get_contents("php://input"), true);
    $idBillet = $postData["idBillet"];
    $idOperation = $postData["idOperation"];
    $numBillet = $postData["numBillet"];

    // Requête pour insérer le numéro de billet dans la colonne disti
    $insertQuery = "UPDATE billet SET distri = TRIM(BOTH ',' FROM CONCAT_WS(',', IFNULL(distri, ''), '$numBillet')) WHERE idBillet = '$idBillet'";


    if ($conn->query($insertQuery)) {
        $message = "Le billet a été distribué avec succès!";
    } else {
        $message = "Erreur lors de la distribution du billet: " . $conn->error;
    }

    // Envoyer une réponse JSON pour AJAX
    header('Content-Type: application/json');
    echo json_encode(['message' => $message]);
    exit;
}
?>
