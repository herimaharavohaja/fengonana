<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
// Vérification de la soumission du formulaire
if (isset($_POST['submitStockSakramenta'])) {

    // Récupération des données du formulaire
    
    $idUser = $_POST['idUser'];
    $idSakramenta = $_POST['idSakramenta'];
    $dteStockSakramenta = $_POST['dteStockSakramenta'];
    $lieuSakramenta = $_POST['lieuSakramenta'];


    // Insertion des données dans la base de données si aucune erreur n'a été détectée
    if (empty($erreurs)) {
        $sql = "INSERT INTO stockSakramenta (idUser, idSakramenta, dteStockSakramenta, lieuStockSakramenta) VALUES ('$idUser', '$idSakramenta', '$dteStockSakramenta',  '$lieuSakramenta')";   

        if ($conn->query($sql) === TRUE) {
            
            ?>
                <script>
                window.location.href='stockSakramenta.php';
                </script>
            <?php

        } else {
            header('Location: stockSakramenta.php');
        }
    } 

} 

?>          
<?php include 'pannelAmbony.php'; ?>  
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h4 class='text-center'><b>Sakramenta<br></b></h4>
                    
                    <form method='post'>
                                
                                <div class='form-group' style="max-height: 400px;overflow-y: auto;">
                                    <?php 
                                    
                                    $sqlUser = "SELECT * FROM user";
                                    $resultUser = $conn->query($sqlUser);

                                    $optionUser = [];
                                    if ($resultUser->num_rows > 0) {
                                     while ($rowUser = $resultUser->fetch_assoc()) {
                                         $optionUser[] = $rowUser;
                                     }
                                    }

                                    $sqlSakramenta = "SELECT * FROM sakramenta";
                                    $resultSakramenta = $conn->query($sqlSakramenta);

                                    $optionSakramenta = [];
                                    if ($resultSakramenta->num_rows > 0) {
                                     while ($rowSakramenta = $resultSakramenta->fetch_assoc()) {
                                         $optionSakramenta[] = $rowSakramenta;
                                     }
                                    }
                                 ?>
                                    <label>Membres:</label> 
                                    <br>
                                    <select name="idUser" class="form-control">
                                        <option value="" disabled selected hidden>Membres</option>
                                        <?php foreach ($optionUser as $optionsUser ) : ?>
                                            <option value="<?php echo $optionsUser['idUser']; ?>">
                                                
                                                <?php echo $optionsUser['nomUser']; echo $optionsUser['prenomUser']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <p></p>
                                    <label>Sakramenta:</label> 
                                    <select name="idSakramenta" class="form-control">
                                        <option value="" disabled selected hidden>Sakramenta</option>
                                        <?php foreach ($optionSakramenta as $optionsSakramenta ) : ?>
                                            <option value="<?php echo $optionsSakramenta['idSakramenta']; ?>">
                                                
                                                <?php echo $optionsSakramenta['libSakramenta']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    
                                    <label>Daty sakramenta:</label>
                                    <br> 
                                    <input type="date" name="dteStockSakramenta" class="form-control" >
                                
                                    <label>Lieu du sakramenta:</label>
                                    <br> 
                                    <input type="text" name="lieuSakramenta" class="form-control" >
                                
                                <br>
                                <button type="submit" name= "submitStockSakramenta" class="btn btn-success" >
                                    <span class="bi bi-trash"></span> Créer 
                                </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-9">
                    <h4 class="text-center"><b><?php echo ("Listry ny Sakramenta isaky ny mpikambana"); ?></b></h4>
                        
                    <div class="text-center" style="max-height: 200px;overflow-y: auto;">
                        <table class="table table-bordered">
                        <thead class="alert-success " style="background: navy;color: white;">

                          <tr class="text-center">
                            <th>N°</th>
                            <th class="text-center">Nom</th>
                            <th class="text-center">Prénom(s)</th>
                            <th class="text-center">Sakramenta</th>
                            <th class="text-center">Lieu</th>
                            <th class="text-center">Date</th>
                            <th class="text-center" colspan="2">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 

                        // Requête SQL pour sélectionner tous les utilisateurs
                        $sqlkonty = "SELECT stockSakramenta.*, user.*, sakramenta.* FROM stockSakramenta 
                            INNER JOIN user ON user.idUser = stockSakramenta.idUser
                            INNER JOIN sakramenta ON sakramenta.idSakramenta = stockSakramenta.idSakramenta
                            ORDER BY stockSakramenta.idStockSakramenta DESC LIMIT 4";
                        $resultkonty = mysqli_query($conn, $sqlkonty);

                        if (mysqli_num_rows($resultkonty) > 0 ) {
                            $i = 0;
                            // Affichage des données de chaque utilisateur
                            while($row = mysqli_fetch_assoc($resultkonty)) {
                                // $i = $i+1;
                                $idStockSakramenta = $row["idStockSakramenta"];
                                $libSakramenta = $row["libSakramenta"];
                                $nomUser = $row["nomUser"];
                                $prenomUser = $row["prenomUser"];
                                $lieuSakramenta = $row["lieuStockSakramenta"];
                                $dteStockSakramenta = $row["dteStockSakramenta"];
                                ?>
                                <tr>
                                    <td><?php echo $idStockSakramenta; ?></td>
                                    <td><?php echo $nomUser; ?></td>
                                    <td><?php echo $prenomUser; ?></td>
                                    <td><?php echo $libSakramenta; ?></td>
                                    <td>
                                        <?php 
                                        // echo $lieuSakramenta;
                                         ?>
                                        <span id="code_<?php echo $row['idStockSakramenta']; ?>">
                                            <?php echo $lieuSakramenta ?>
                                        </span>
                                        <form id="code_form_<?php echo $row['idStockSakramenta']; ?>" style="display:none;">
                                            <input type="text" name="editedCode" class="form-control" value="<?php echo $lieuSakramenta; ?>">
                                        </form>
                                    </td>
                                    <td>
                                        <span id="lib_<?php echo $row['idStockSakramenta']; ?>">
                                            <?php echo $dteStockSakramenta; ?>
                                        </span>
                                        <form id="lib_form_<?php echo $row['idStockSakramenta']; ?>" style="display:none;">
                                            <input type="text" name="editedValue" class="form-control" value="<?php echo $dteStockSakramenta; ?>">
                                        </form>
                                    </td>
                                    <td>
                                        <button type="button" id="mod_<?php echo $row['idStockSakramenta']; ?>" class="btn btn-primary" onclick="editRow(<?php echo $row['idStockSakramenta']; ?>)">Modifier</button>
                                        <button type="button" id="enre_<?php echo $row['idStockSakramenta']; ?>" class="btn btn-success" onclick="saveEdit(<?php echo $row['idStockSakramenta']; ?>)"style="display:none;" >Enregistrer</button>
                                        <a href="deleteKonty.php?supprStockSakramenta=<?php echo $row['idStockSakramenta']; ?>">
                                            <button type="button" class="btn btn-danger">Supprimer</button>
                                        </a>
                                    </td>
                    
                    </tr>
 
                <?php 
                }
            } else {
                echo "Néant";
            }
          ?>
          </tbody>
                </table>
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function editRow(id) {
        // Masquer le texte et afficher le formulaire
        $("#code_" + id).hide();
        $("#lib_" + id).hide();
        $("#mod_" + id).hide();
        $("#code_form_" + id).show();
        $("#lib_form_" + id).show();
        $("#enre_" + id).show();
    }

    function saveEdit(id) {
        // Récupérer les valeurs éditées
        var editedCode = $("form#code_form_" + id + " input[name='editedCode']").val();
        var editedValue = $("form#lib_form_" + id + " input[name='editedValue']").val();

        console.log('ID:', id);
        console.log('Edited Code:', editedCode);
        console.log('Edited Value:', editedValue);

        // Envoyer les données au serveur avec AJAX
        fetch('saveEditSakr.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id, editedCode: editedCode, editedValue: editedValue }),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response from server:', data);

            // Mettre à jour l'affichage après avoir reçu la réponse du serveur
            if (data.success) {
                console.log('Mise à jour réussie dans la base de données.');
                $("#code_" + id).html(editedCode);
                $("#lib_" + id).html(editedValue);

                // Afficher à nouveau le texte
                $("#code_" + id).show();
                $("#lib_" + id).show();
                $("#mod_" + id).show();
                // Masquer les formulaires
                $("#code_form_" + id).hide();
                $("#lib_form_" + id).hide();
                $("#enre_" + id).hide();
            } else {
                console.error('Erreur lors de la mise à jour dans la base de données.');
                alert('Erreur lors de la sauvegarde.');
            }
        })
        .catch((error) => {
            console.error('Erreur de fetch :', error);
        });
    }
</script>

                    </div>
                </div>

                </div>
            </div>

<?php include 'pannelAmbany.php'; ?> 