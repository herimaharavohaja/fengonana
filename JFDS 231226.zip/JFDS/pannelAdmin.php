
<?php 
include 'connect.php'; 
// session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

$libPseudo = $_SESSION['libPseudo'];
                          $libSuper = "superAdmin";
                          $libAdmin = "admin";
                          $libUser = "user";

  if ($cat == "Admin" or $cat == "superAdmin") {
 ?>                    
 <hr class="sidebar-divider">       
<div class="sidebar-heading">
                Admin
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="bi bi-plus-square"></i>
                    <span>Créations</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header"> Nouvelles créations:</h6>
                        
                          <?php 
                            echo "<a class='collapse-item' href='creaAdmin.php'>Comptes</a>
                                  <a class='collapse-item' href='creaFaritra.php'>Faritra</a>
                                  <a class='collapse-item' href='creaMasina.php'>Fikambanana masina</a>
                                  <a class='collapse-item' href='creaVaomiera.php'>Vaomieran'asa</a>
                                  <a class='collapse-item' href='creaSakramenta.php'>Sakramenta</a>
                                  <a class='collapse-item' href='creaActivite.php'>Hetsika</a>
                                  <a class='collapse-item' href='andraikitra.php'>Andraikitra</a>
                                  <a class='collapse-item' href='presence.php'>Presence</a>
                                  <a class='collapse-item' href='ev.php'>Evènement</a>
                                  ";
                          ?>
                        
                    </div>
                </div>
            </li>

            <li class="nav-item">
                    <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) == 'caisse.php') ? 'active' : ''; ?>" href="caisse.php">
                    <i class="bi bi-cash"></i>
                    <span>Teti-bola</span></a>
            </li>
            
            <?php 
        }
        elseif ($cat == "User") {
          # code...
        }
        elseif ($cat == "membre") {
          // echo "string";
        }
        else {
          // echo "";
          header('Location: index.php');
        }
      ?>

