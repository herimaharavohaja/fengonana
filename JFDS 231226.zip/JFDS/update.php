	
<?php
include 'connect.php';
include('db_function.php');
session_start();
if ($_POST['modif']) {
	// Récupération des données du formulaire

if ($cat == 'superAdmin' || $cat == 'Admin') {
    $libPseudo = $_POST['libPseudo'];
    $libPseudo = escape_data($conn, $libPseudo);
    $libPass = $_POST['libPass'];
}




$photoUser = $_POST['photoUser'];
$libPass = escape_data($conn, $libPass);
$idKonty = $_POST['idKonty'];

$query = "SELECT * FROM konty WHERE libPseudo = '$libPseudo'";
    $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
        // Le login existe déjà, effectuez une action appropriée
             ?>
                    <script>
        alert('Ce pseudo a déjà un compte!');
        window.location.href='editUser.php';
        </script>
                    <?php
        } else {
if ($cat == 'superAdmin' || $cat == 'Admin') {
    $tohi = "libPseudo = '$libPseudo', libPass = '$libPass',";
} else {
    $tohi = '';
}
// Mise à jour des données de l'utilisateur dans la base de données
$sql = "UPDATE konty SET $tohi saryKonty = '$saryKonty' WHERE idKonty = '$idKonty'";
mysqli_query($conn, $sql);

// Redirection vers la page d'accueil
header("Location: index.php");
exit();
}
}
else {
	header("Location: editUser.php");
}

?>