<?php
// Inclure la configuration de votre base de données
include 'connect.php';  

// Assurez-vous que la requête est une requête POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $libActivite = $_POST['libActivite'];
    // Récupérer la valeur de l'input du formulaire
    $qrCodeValue = isset($_POST['qrCodeValue']) ? $_POST['qrCodeValue'] : '';

    if (!empty($qrCodeValue)) {
        // Échapper la valeur pour éviter les injections SQL
        $qrCodeValue = mysqli_real_escape_string($conn, $qrCodeValue);
        // Exécuter la requête SQL pour vérifier la valeur dans la BDD
        $query = "
            SELECT 'user' AS source, idUser AS id, hashKonty AS hashKonty, CONCAT(nomUser, ' ', prenomUser) AS nom, saryUser AS sary   
            FROM user
            WHERE hashKonty = '$qrCodeValue'
            UNION
            SELECT 'konty' AS source, idKonty AS id, hashKonty AS hashKonty, libPseudo AS nom, saryKonty AS sary 
            FROM konty
            WHERE hashKonty = '$qrCodeValue'";
        $result = mysqli_query($conn, $query);

        // Vérifier si une correspondance a été trouvée dans la BDD
        if ($result && mysqli_num_rows($result) > 0) {
            // Vous pouvez maintenant récupérer les données de l'utilisateur ici
            $rowUs = mysqli_fetch_assoc($result);
            $source = $rowUs['source'];
            $hashKonty = $rowUs['hashKonty'];
            $nom = $rowUs['nom'];
            $sary = $rowUs['sary'];

            // Vérifier si l'ID n'existe pas encore dans la colonne actif
            $queryCheck = "SELECT COUNT(*) AS id_exists FROM proactivite WHERE FIND_IN_SET('$hashKonty', actif) AND libActivite = '$libActivite'";
            $resultCheck = $conn->query($queryCheck);
            $rowCheck = $resultCheck->fetch_assoc();

            if ($rowCheck['id_exists'] == 0) {
                // L'ID n'existe pas encore, nous pouvons effectuer la mise à jour
                $queryM = "UPDATE proactivite SET actif = CONCAT_WS(',', actif, '$hashKonty') WHERE libActivite = '$libActivite'";
                $conn->query($queryM);
                $response = array(
                    'success' => true,
                    'nomUser' => $nom,
                    'saryUser' => $sary
                );
            } else {
                // L'ID existe déjà, vous pouvez gérer cette situation selon vos besoins
                $response = array(
                    'success' => false,
                    'message' => 'Ce compte est déjà présent!'
                );
            }
        } 
        else {
            $response = array(
                'success' => false,
                'message' => 'Aucun utilisateur trouvé'
            );
        }

        // Fermer le résultat de la requête
        mysqli_free_result($result);
    } else {
        $response = array(
            'success' => false,
            'message' => 'Valeur du code QR manquante'
        );
    }
} else {
    // Si ce n'est pas une requête POST, renvoyer une réponse d'erreur
    $response = array(
        'success' => false,
        'message' => 'Mauvaise méthode de requête'
    );
}

// Fermer la connexion à la base de données
mysqli_close($conn);

// Renvoyer la réponse au client au format JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
