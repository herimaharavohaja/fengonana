
<footer class="sticky-footer bg-white text-center" style="width: 100%;  padding: 20px;text-align: center; bottom: 0;position: fixed;">
                <div class=" my-auto " >
                    <div class="copyright my-auto" style="margin-right: 100px;">
                        <span> &copy; jead 2023 ( adlinjeannot@gmail.com / 0326891205 ) </span> 
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        
                        | <span>
                        	facebook : <strong><a style="text-decoration: none;" href="">vdkt soavimasoandro</a></strong>
                        </span> |
						<span>mail : <strong>vdktsoavimasoandro@gmail.com</strong></span> |
						<span>tél. :<strong> 0341256232 </strong></span>
                    </div>

                </div>
            </footer>