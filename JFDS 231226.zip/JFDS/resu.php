<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte2.php'; ?>   
<br>

    <div class="container" style="border-radius: ">
    <div class="row">

    <div class="col-md-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Résultat</h6>

            </div>
            <div class="card-body" style="max-height: 450px;overflow-y: auto;">
            

                <table id="Table_util" class="table table-bordered table-striped">
                    <?php

$i = 0;

$query = "SELECT 
            o.libOperation AS operation,
            o.prixBillet AS prix,
            SUM(COALESCE(LENGTH(b.distri) - LENGTH(REPLACE(b.distri, ',', '')) + 1, 0)) AS total_distri_numbers,
            SUM(o.prixBillet * COALESCE(LENGTH(b.distri) - LENGTH(REPLACE(b.distri, ',', '')) + 1, 0)) AS prix_total
        FROM operation o
        LEFT JOIN billet b ON o.idOperation = b.idOperation
        GROUP BY o.libOperation, o.prixBillet;

        ";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<thead>
            <tr>
                <th>N°</th>
                <th>Opération</th>
                <th>Prix unitaire (Ar)</th>
                <th>Total distribué</th>
                <th>Sommes (Ar)</th>
            </tr>
          </thead>
          <tbody>";
    while ($rowK = $result->fetch_array()) {
        $i = $i + 1;
?>
        <tr>
            <td><?php echo $i ?></td>
            <td><?php echo $rowK['operation'] ?></td>
            <td><?php echo $rowK['prix'] ?></td>
            <td><?php echo $rowK['total_distri_numbers'] ?></td>
            <td><?php echo $rowK['prix_total'] ?></td>
        </tr>
<?php }
} else {
    echo "<p>Il n'y a pas d'enregistrement!</p>";
}
?>

                </table>
            </div>
        </div>
    </div>
    </div>
    </div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 