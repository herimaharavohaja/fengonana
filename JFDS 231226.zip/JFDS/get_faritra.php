<?php
// get_faritra.php
include 'connect.php'; // Assurez-vous d'inclure votre script de connexion à la base de données

$query = "SELECT * FROM faritra";
$result = $conn->query($query);

$faritraList = array();
while ($row = $result->fetch_assoc()) {
    $faritraList[] = $row;
}

echo json_encode($faritraList);
?>
