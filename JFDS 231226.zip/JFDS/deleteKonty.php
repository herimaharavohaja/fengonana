<?php 
include 'connect.php'; 
if (isset($_GET['suppr'])) {
	$ida= $_GET['suppr'];

	$query = "DELETE FROM konty WHERE idKonty=$ida";
    $result = $conn->query($query);
    header("Location:compteAdmin.php");
}

if (isset($_GET['gerMasina'])) {
	$ida= $_GET['gerMasina'];

	$query = "DELETE FROM konty WHERE idKonty=$ida";
    $result = $conn->query($query);
    header("Location:compteMasina.php");
}

if (isset($_GET['gerFaritra'])) {
	$ida= $_GET['gerFaritra'];

	$query = "DELETE FROM konty WHERE idKonty=$ida";
    $result = $conn->query($query);
    header("Location:compteFaritra.php");
}

if (isset($_GET['gerVaomierao'])) {
	$ida= $_GET['gerVaomierao'];

	$query = "DELETE FROM konty WHERE idKonty=$ida";
    $result = $conn->query($query);
    header("Location:compteVaomiera.php");
}

if (isset($_GET['supprFaritra'])) {
	$idaFaritra= $_GET['supprFaritra'];

	$query = "DELETE FROM faritra WHERE idFaritra=$idaFaritra";
    $result = $conn->query($query);
    header("Location:creaFaritra.php");
}

if (isset($_GET['supprVaomiera'])) {
	$idaVoamiera= $_GET['supprVaomiera'];

	$query = "DELETE FROM vaomiera WHERE idVaomiera=$idaVoamiera";
    $result = $conn->query($query);
    header("Location:creaVaomiera.php");
}

if (isset($_GET['supprMasina'])) {
	$idaVoamiera= $_GET['supprMasina'];

	$query = "DELETE FROM masina WHERE idMasina=$idaMasina";
    $result = $conn->query($query);
    header("Location:creaMasina.php");
}

if (isset($_GET['supprPro'])) {
	$idaPro= $_GET['supprPro'];

	$query = "DELETE FROM proactivite WHERE idPro=$idaPro";
    $result = $conn->query($query);
    header("Location:creaActivite.php");
}

if (isset($_GET['supprActivite'])) {
	$idaActivite= $_GET['supprActivite'];

	$query = "DELETE FROM activite WHERE idActivite=$idaActivite";
    $result = $conn->query($query);
    header("Location:creaActivite.php");
}

if (isset($_GET['supprSakramenta'])) {
	$idaSakramenta= $_GET['supprSakramenta'];

	$query = "DELETE FROM sakramenta WHERE idSakramenta=$idaSakramenta";
    $result = $conn->query($query);
    header("Location:creaSakramenta.php");
}

if (isset($_GET['supprMembre'])) {
	$idaMembre= $_GET['supprMembre'];

	$query = "DELETE FROM user WHERE idUser=$idaMembre";
    $result = $conn->query($query);
    header("Location:faritraUser.php");
}

if (isset($_GET['supprStockSakramenta'])) {
	$idaStockSakramenta= $_GET['supprStockSakramenta'];

	$query = "DELETE FROM stockSakramenta WHERE idStockSakramenta = $idaStockSakramenta";
    $result = $conn->query($query);
    header("Location:stockSakramenta.php");
}

if (isset($_GET['supprAndraikitra'])) {
	$idaSupprAndraikitra= $_GET['supprAndraikitra'];

	$query = "DELETE FROM andraikitra WHERE idAndraikitra = $idaSupprAndraikitra";
    $result = $conn->query($query);
    header("Location:andraikitra.php");
}

if (isset($_GET['supprMembreMasina'])) {
	$idaSupprMembreMasina= $_GET['supprMembreMasina'];

	$query = "UPDATE user SET idMasina = NULL WHERE idUser = '$idaSupprMembreMasina'";
    $result = $conn->query($query);
    header("Location:masinaUser.php");
}

if (isset($_GET['supprMembreVaomiera'])) {
	$idaSupprMembreVaomiera= $_GET['supprMembreVaomiera'];

	$query = "UPDATE user SET idVaomiera = NULL WHERE idUser = '$idaSupprMembreVaomiera'";
    $result = $conn->query($query);
    header("Location:vaomieraUser.php");
}

if (isset($_GET['billet'])) {
	$idaSupprBillet= $_GET['billet'];

	$query = "DELETE FROM billet WHERE idBillet = $idaSupprBillet";
    $result = $conn->query($query);
    header("Location:billet.php");
}

if (isset($_GET['supprEv'])) {
	$idaSupprEv= $_GET['supprEv'];

	$query = "DELETE FROM ev WHERE idEv = $idaSupprEv";
    $result = $conn->query($query);
    header("Location:ev.php");
}
 ?>