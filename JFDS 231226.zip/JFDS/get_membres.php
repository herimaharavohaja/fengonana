<?php
// get_members.php
include 'connect.php'; // Assurez-vous d'inclure votre script de connexion à la base de données

if (isset($_GET['faritra'])) {
    $selectedFaritra = $_GET['faritra'];

    $query = "SELECT  
                'user' AS source, 
                nomUser AS nom, 
                prenomUser AS prenom, 
                f.libFaritra AS faritra
                FROM user u
                LEFT JOIN faritra f ON f.idFaritra = u.idFaritra  
                WHERE u.idFaritra = '$selectedFaritra'
            UNION
              SELECT 
                'konty' AS source, 
                nomKonty AS nom, 
                prenomKonty AS prenom,
                f.libFaritra AS faritra
                FROM konty k
                LEFT JOIN faritra f ON f.idFaritra = k.idFaritra  
                WHERE k.idFaritra = '$selectedFaritra'
    ";

    $result = $conn->query($query);

    // Affichez les membres
    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Faritra</th>
                    </tr>
                </thead>
                <tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td>' . $row['nom'] . '</td>
                    <td>' . $row['prenom'] . '</td>
                    <td>' . $row['faritra'] . '</td>
                  </tr>';
        }

        echo '</tbody></table>';
    } else {
        echo '<p>Aucun membre trouvé pour ce faritra.</p>';
    }
}
elseif (isset($_GET['masina'])) {
    $selectedMasina = $_GET['masina'];
    $query = "SELECT  
                'user' AS source, 
                nomUser AS nom, 
                prenomUser AS prenom, 
                m.libMasina AS masina
                FROM user u
                LEFT JOIN masina m ON m.idMasina = u.idMasina 
                WHERE u.idMasina = '$selectedMasina'
            UNION
              SELECT 
                'konty' AS source, 
                nomKonty AS nom, 
                prenomKonty AS prenom,
                m.libMasina AS masina
                FROM konty k 
                LEFT JOIN masina m ON m.idMasina = k.idMasina 
                WHERE k.idMasina = '$selectedMasina'
    ";

    $result = $conn->query($query);

    // Affichez les membres
    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Masina</th>
                    </tr>
                </thead>
                <tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td>' . $row['nom'] . '</td>
                    <td>' . $row['prenom'] . '</td>
                    <td>' . $row['masina'] . '</td>
                  </tr>';
        }

        echo '</tbody></table>';
    } else {
        echo '<p>Aucun membre trouvé pour ce Fikambanana Masina.</p>';
    }
}
elseif (isset($_GET['vaomiera'])) {
    $selectedVaomiera = $_GET['vaomiera'];
    $query = "SELECT  
                'user' AS source, 
                nomUser AS nom, 
                prenomUser AS prenom, 
                v.libVaomiera AS vaomiera
                FROM user u
                LEFT JOIN vaomiera v ON v.idVaomiera = u.idVaomiera 
                WHERE v.idVaomiera = '$selectedVaomiera'
            UNION
              SELECT 
                'konty' AS source, 
                nomKonty AS nom, 
                prenomKonty AS prenom,
                v.libVaomiera AS vaomiera
                FROM konty k 
                LEFT JOIN vaomiera v ON v.idVaomiera = k.idVaomiera 
                WHERE v.idVaomiera = '$selectedVaomiera'
    ";

    $result = $conn->query($query);

    // Affichez les membres
    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Vaomiera</th>
                    </tr>
                </thead>
                <tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td>' . $row['nom'] . '</td>
                    <td>' . $row['prenom'] . '</td>
                    <td>' . $row['vaomiera'] . '</td>
                  </tr>';
        }

        echo '</tbody></table>';
    } else {
        echo "<p>Aucun membre trouvé pour ce vaomieran'asa.</p>";
    }

} else {
    echo "<p>Sélectionnez un faritra ou Fikambanana Masina ou Vaomieran'asa pour afficher les membres.</p>";
}
?>
