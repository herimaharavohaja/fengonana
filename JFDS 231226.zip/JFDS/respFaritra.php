<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

?>          
<?php include 'pannelAmbony.php'; ?>  
        <div class="container">
            
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="">
                    <div >
                        <?php 
                          $sqlF = "SELECT konty.*, faritra.* FROM konty 
                            left JOIN faritra ON faritra.idFaritra = konty.idFaritra
                            WHERE konty.libPseudo = '$libPseudo'";

                          $resultF = mysqli_query($conn, $sqlF);

                          if (mysqli_num_rows($resultF) > 0) {
                              $rowF = mysqli_fetch_assoc($resultF);
                              $idFaritraF = $rowF["idFaritra"];
                              $libFaritraF = $rowF["libFaritra"];
                         ?>
                        <h4 class="text-center"><b><?php echo ("Mpandrindra ny faritra "); ?><?php echo $rowF["libFaritra"]; }?></b></h4>
                        
                    </div>
                    <div class="text-center" style="max-height: 400px;overflow-y: auto;"> 
                        <table class="table table-bordered">
                        <thead class="alert-success " style="background: navy; color: white;">

                          <tr class="text-center">
                            <th>N°</th>
                            <th class="text-center">Pseudo</th>

                          </tr>
                        </thead>
                        <tbody>
                          <?php 

                        // Requête SQL pour sélectionner tous les utilisateurs
                        $sqlL = "SELECT konty.*, faritra.* FROM konty 
                            INNER JOIN faritra ON faritra.idFaritra = konty.idFaritra
                            WHERE faritra.libFaritra = '$libFaritraF'";
                        $resultL = mysqli_query($conn, $sqlL);

                        if (mysqli_num_rows($resultL) > 0 ) {
                            $i = 0;
                            // Affichage des données de chaque utilisateur
                            while($rowL = mysqli_fetch_assoc($resultL)) {
                                $i = $i+1;
                                $libPseudo = $rowL["libPseudo"];

                                ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $libPseudo; ?></td>
                                </tr>
 
                <?php 
                }
            } else {
                echo "Néant";
            }

            // Fermeture de la connexion
            mysqli_close($conn);
          ?>
          </tbody>
                </table>
                    </div>
                    <br><br>
                </div>
            </div>

            <div class="col-md-1"></div>
        </div>
    </div>
    <br><br>
<?php include 'pannelAmbany.php'; ?> 