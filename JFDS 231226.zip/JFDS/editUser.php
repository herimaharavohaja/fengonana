<?php 
session_start();
include 'pannelAmbony.php';
include 'connect.php';

$libPseudo1 = $_GET['id'];

// Récupération des données de l'utilisateur à partir de la base de données
$sql = "SELECT * FROM konty WHERE libPseudo = '$libPseudo1'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$libPseudo = $row['libPseudo'];
$libPass = $row['libPass'];
$idKonty = $row['idKonty'];
$libCategorie = $row['libCategorie'];
$photoUser = $row['saryKonty']; 


echo "
<body>
	<div class='container-fluid'>
		<div class='row'>
			<div class='col-md-3'></div>
			<div class='col-md-6'>
				<center><h3>Modifier </h3></center><br>	
				<form action='update.php' method='post' enctype='multipart/form-data'> <!-- Ajout de l'attribut enctype pour le téléchargement de fichiers -->
					<input type='hidden' name='idKonty' value='$idKonty'>";
					
					
					$cat = $_SESSION['libCategorie'];
					if ($cat == 'superAdmin' || $cat == 'Admin') {
						echo "
							<label>Pseudo: </label>
							<input class='form-control' type='text' name='libPseudo' value='$libPseudo'><br>
							<label>Mot de passe: </label>
							<input class='form-control' type='text' name='libPass' value='$libPass'><br>
							";
					}
					echo "

					<div style='display: flex;justify-content:center;'>
						
						 

						<input type='file' name='photoUser' style='margin: 30px 0 0 15px;'><br>
					</div><br>
					<center><input type='submit' class='btn btn-success' name='modif' value='Enregistrer'></center>
				</form>
			</div>
			<div class='col-md-3'></div>
		</div>
	</div>
</body>";

?>

	
<!-- <img src='./img/$photoUser'   style='max-width: 100px; border-radius: 50%;height:100px;'> -->
<br><br>
<?php include 'pannelAmbany.php'; ?>
