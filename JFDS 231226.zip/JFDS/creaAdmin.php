<?php

include 'connect.php';
include('db_function.php');  
 session_start();
 error_reporting(E_ALL);
 ini_set('display_errors', 1);
 
  if (!isset($_SESSION['libPseudo'])) {
    header("Location:index.php");
   
    }
$cat = $_SESSION['libCategorie'];

 include 'pannelAmbony.php'; 
 include 'navCompte.php'; 
 ?>  

<br><br>
<?php include 'pannelAmbany.php'; ?> 