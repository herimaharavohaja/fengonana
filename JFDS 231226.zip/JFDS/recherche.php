<?php

include 'connect.php';
// Vérification de la soumission du formulaire
session_start();
$cat = $_SESSION['libCategorie'];
$fari = $_SESSION['idFaritra'];

?>

<!-- <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> -->
<style>
    .container {
    max-width: 600px;
    margin: 0 auto;

}

.search-box,
.search-box1 {
    position: relative;
}

.form-control,
.form-control1 {
    height: 38px;
    font-size: 16px;
}

.result,
.result1 {
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    box-sizing: border-box;
    display: none;
    border: 1px solid #CCCCCC;
    border-top: none;
    overflow-y: auto;
    z-index: 10;
    max-height: 250px;
}

.result p,
.result1 p {
    font-size: 6px;
    background-color: white;
    margin: 0;
    padding: 7px 10px;
    border-bottom: 1px solid #CCCCCC;
    cursor: pointer;
}

.result p:hover,
.result1 p:hover {
    background: #f2f2f2;
}

.no-result,
.no-result1 {
    background-color: white;
    margin: 0;
    padding: 10px;
    border: 1px solid #CCCCCC;
}

</style>

<?php include 'pannelAmbony.php'; ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h4>Recherche sur les membres</h4>
            <div class="search-box">
                <input class="form-control" type="text" autocomplete="off" placeholder="Saisissez un mot"/>
                <br>
                <div class="result">
                    <p class="no-result">Aucun résultat</p>
                </div>
            </div>
        </div>
    </div>
    <?php if ($cat == 'superAdmin' || $cat == 'admin')  : ?>
    	
    
    <br><br><br><br><br><br><br><br><br><br>
    <div class="row">
        <div class="col-md-12">
            <h4>Recherche sur les membres de bureaux</h4>
            <div class="search-box1">
                <input class="form-control" type="text" autocomplete="off" placeholder="Saisissez un mot"/>
                <br>
                <div class="result1">
                    <p class="no-result1">Aucun résultat</p>
                </div>
            </div>
        </div>
    </div>

    <?php endif ?>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script>
    $(document).ready(function () {
        var resultContainer = $(".search-box .result");
        var noResultContainer = $(".search-box .no-result");

        $('.search-box input[type="text"]').on("keyup input", function () {
            var inputVal = $(this).val();

            if (inputVal.length) {
                $.get("backRec.php", {term: inputVal}, function (data) {
                    // Assurez-vous que le contenu retourné est en format HTML
                    resultContainer.html(data);

                    // Vous devez afficher les résultats uniquement s'il y en a
                    if (data.trim() !== "") {
                        resultContainer.show(); // Afficher les résultats
                        noResultContainer.hide(); // Masquer le message "Aucun résultat"
                    } else {
                        resultContainer.hide(); // Masquer les résultats s'il n'y a pas de terme de recherche
                        noResultContainer.show(); // Afficher le message "Aucun résultat"
                    }
                });
            } else {
                resultContainer.empty();
                resultContainer.hide(); // Masquer les résultats s'il n'y a pas de terme de recherche
                noResultContainer.show(); // Afficher le message "Aucun résultat" lorsque la recherche est vide
            }
        });
    });

    $(document).ready(function () {
        var resultContainer1 = $(".search-box1 .result1");
        var noResultContainer1 = $(".search-box1 .no-result1");

        $('.search-box1 input[type="text"]').on("keyup input", function () {
            var inputVal1 = $(this).val();

            if (inputVal1.length) {
                $.get("backRec.php", {term1: inputVal1}, function (data1) {
                    // Assurez-vous que le contenu retourné est en format HTML
                    resultContainer1.html(data1);

                    // Vous devez afficher les résultats uniquement s'il y en a
                    if (data1.trim() !== "") {
                        resultContainer1.show(); // Afficher les résultats
                        noResultContainer1.hide(); // Masquer le message "Aucun résultat"
                    } else {
                        resultContainer1.hide(); // Masquer les résultats s'il n'y a pas de terme de recherche
                        noResultContainer1.show(); // Afficher le message "Aucun résultat"
                    }
                });
            } else {
                resultContainer1.empty();
                resultContainer1.hide(); // Masquer les résultats s'il n'y a pas de terme de recherche
                noResultContainer1.show(); // Afficher le message "Aucun résultat" lorsque la recherche est vide
            }
        });
    });



</script>

<br><br><br><br>
<?php include 'pannelAmbany.php'; ?>
