<?php
include 'connect.php'; 
if(isset($_GET['qrcode'])) {
    // Récupérer la valeur du QR code
    $qrcode = $_GET['qrcode'];

    // Vérifier le code QR (vous pouvez mettre ici votre logique de vérification)
    if($qrcode === 'votre_code_qr_attendu') {
        $response = array('message' => 'Code QR valide');
    } else {
        $response = array('message' => 'Code QR invalide');
    }

    // Renvoyer la réponse en format JSON
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Si le paramètre qrcode n'est pas défini, renvoyer une erreur
    header('HTTP/1.1 400 Bad Request');
    echo 'Paramètre manquant : qrcode';
}
?>
