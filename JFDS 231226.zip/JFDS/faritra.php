<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];


 ?>
<?php include 'pannelAmbony.php'; ?>   
  
    <div class="container">
    <div class="row">
    <div class="col-md-6">
       
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Filohan’ny Faritra</h6>
            </div>
            <div class="card-body" style="max-height: 200px;overflow-y: auto;">
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>N°</th> 
                              <th>Dirigent</th>
                              <th>Faritra</th>
                              <!-- <th>Année</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                        $query = "SELECT konty.libPseudo, YEAR(konty.dteCrea) AS anneeCrea, faritra.libFaritra, konty.* 
                                                  FROM konty 
                                                  LEFT JOIN faritra ON faritra.idFaritra = konty.idFaritra
                                                  WHERE konty.idFaritra != '0';
                                                  ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;

                        echo "<tr class='user-row' data-toggle='modal' data-target='#exampleModal'
                          data-pseudo='" . $row['libPseudo'] . "'
                          data-code='" . $row['codeKonty'] . "'
                          data-sexe='" . $row['sexeKonty'] . "'
                          data-nom='" . $row['nomKonty'] . "'
                          data-prenom='" . $row['prenomKonty'] . "'
                          data-apv='" . $row['apvKonty'] . "'
                          data-adresy='" . $row['adresyKonty'] . "'
                          data-faritra='" . $row['libFaritra'] . "'
                          data-sary='" . $row['saryKonty'] . "'>
                              <td>" . $i . "</td> 
                              <td>" . $row['nomKonty'] . "  " . $row['nomKonty'] . "</td>
                              <td>" . $row['libFaritra'] . "</td>
                          
                        </tr>"; 
                      }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>
                    </table>  

                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
                /* Styles pour le badge */
                .modal-content {
                    border: 2px solid #007BFF;
                    border-radius: 10px;
                }
                
                .modal-title {
                    font-size: 1.2rem;
                    text-align: center;
                }

                #user-photo {
                    border: 2px solid #007BFF;
                    border-radius: 50%;
                    display: block;
                    margin: 0 auto;
                }

                #user-details {
                    text-align: center;
                    padding: 20px;
                }

                #user-details strong {
                    color: #007BFF;
                    font-weight: bold;
                }
            </style>

<!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  

                    <p id="user-details">
                        <img style='border-radius: 50%;' class='img-responsive'
                          width='100' height='100' id="user-photo">
                        <ul>
                            <li><strong>Pseudo : </strong><span id="user-pseudo"></span></li>
                            <li><strong>Code : </strong><span id="user-code"></span></li>
                            <li><strong>Sexe : </strong><span id="user-sexe"></span></li>
                            <li><strong>Nom : </strong><span id="user-nom"></span></li>
                            <li><strong>Prénom(s) : </strong><span id="user-prenom"></span></li>
                            <li><strong>APV : </strong><span id="user-apv"></span></li>
                            <li><strong>Adresse : </strong><span id="user-adresse"></span></li>
                            <li><strong>Faritra : </strong><span id="user-libFaritra"></span></li>
                            <!-- <li><strong>Fikambanana Masina : </strong><span id="user-libMasina"></span></li>
                            <li><strong>Vaomiera ny asa: </strong><span id="user-libVaomiera"></span></li> -->
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>



<script>
    $(document).ready(function() {
        $('.user-row').click(function() {
            $('#user-nom').text($(this).data('nom'));

            var pseudoValue = $(this).data('pseudo');
            if (pseudoValue !== null && pseudoValue !== undefined) {
                $('#user-pseudo').text(pseudoValue);
            } else {
                $('#user-pseudo').text("N/A");
            }

            var codeValue = $(this).data('code');
            if (codeValue !== null && codeValue !== undefined) {
                $('#user-code').text(codeValue);
            } else {
                $('#user-code').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== null && sexeValue !== undefined) {
                $('#user-sexe').text(codeValue);
            } else {
                $('#user-sexe').text("N/A");
            }
            
            var prenomValue = $(this).data('prenom');
            if (prenomValue !== null && prenomValue !== undefined) {
                $('#user-prenom').text(prenomValue);
            } else {
                $('#user-prenom').text("N/A");
            }

            var apvValue = $(this).data('apv');
            if (apvValue !== null && apvValue !== undefined) {
                $('#user-apv').text(sexeValue);
            } else {
                $('#user-apv').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== null && adresseValue !== undefined) {
                $('#user-adresse').text(adresseValue);
            } else {
                $('#user-adresse').text("N/A");
            }

            var faritraValue = $(this).data('faritra');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user-libFaritra').text(faritraValue);
            } else {
                $('#user-libFaritra').text("N/A");
            }

            var lieuValue = $(this).data('lieu');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user-lieuSakramenta').text(lieuValue);
            } else {
                $('#user-lieuSakramenta').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== null && masinaValue !== undefined) {
                $('#user-libMasina').text(masinaValue);
            } else {
                $('#user-libMasina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== null && vaomieraValue !== undefined) {
                $('#user-libVaomiera').text(vaomieraValue);
            } else {
                $('#user-libVaomiera').text("N/A");
            }


            var photoNom = $(this).data('sary');
            $('#user-photo').attr('src', './uploads/gerant/' + photoNom);

            $('#exampleModal').modal('show');
        });
    });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
                /* Styles pour le badge */
                .modal-content {
                    border: 2px solid #007BFF;
                    border-radius: 10px;
                }
                
                .modal-title {
                    font-size: 1.2rem;
                    text-align: center;
                }

                #user-photo {
                    border: 1px solid #007BFF;
                    border-radius: 50%;
                    display: block;
                    margin: 0 auto;
                }

                #user-details {
                    text-align: center;
                    padding: 20px;
                }

                #user-details strong {
                    color: #007BFF;
                    font-weight: bold;
                }
            </style>


            </div>
        </div>
        </div>
        <div class="col-md-6">
          <!-- fikambanana -->

          <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Filohan’ny Fikambanana Masina</h6>
            </div>
            <div class="card-body" style="max-height: 200px;overflow-y: auto;">
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>N°</th> 
                              <th>Dirigent</th>
                              <th>Fikambanana masina</th>
                              <!-- <th>Année</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                        $query = "SELECT konty.libPseudo, YEAR(konty.dteCrea) AS anneeCrea, masina.libMasina, konty.* 
                                                  FROM konty 
                                                  LEFT JOIN masina ON masina.idMasina= konty.idMasina
                                                  WHERE konty.idMasina!= '0';
                                                  ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;

                        echo "<tr class='user1-row' data-toggle='modal' data-target='#exampleModal1'

                          data-pseudo='" . $row['libPseudo'] . "'
                          data-code='" . $row['codeKonty'] . "'
                          data-sexe='" . $row['sexeKonty'] . "'
                          data-nom='" . $row['nomKonty'] . "'
                          data-prenom='" . $row['prenomKonty'] . "'
                          data-apv='" . $row['apvKonty'] . "'
                          data-adresy='" . $row['adresyKonty'] . "'
                          data-masina='" . $row['libMasina'] . "'
                          data-sary='" . $row['saryKonty'] . "'>
                              <td>" . $i . "</td> 
                              <td>" . $row['nomKonty'] . "  " . $row['nomKonty'] . "</td>
                              <td>" . $row['libMasina'] . "</td>
                          
                        </tr>";
                      }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>
                    </table>  
            </div>
        </div>
        </div>
        </div>


        <!-- Modal -->
            <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  

                    <p id="user-details">
                        <img style='border-radius: 50%;' class='img-responsive'
                          width='100' height='100' id="user1-photo">
                        <ul>
                            <li><strong>Pseudo : </strong><span id="user1-pseudo"></span></li>
                            <li><strong>Code : </strong><span id="user1-code"></span></li>
                            <li><strong>Sexe : </strong><span id="user1-sexe"></span></li>
                            <li><strong>Nom : </strong><span id="user1-nom"></span></li>
                            <li><strong>Prénom(s) : </strong><span id="user1-prenom"></span></li>
                            <li><strong>APV : </strong><span id="user1-apv"></span></li>
                            <li><strong>Adresse : </strong><span id="user1-adresse"></span></li>
                            <!-- <li><strong>Faritra : </strong><span id="user1-libFaritra"></span></li> -->
                            <li><strong>Fikambanana Masina : </strong><span id="user1-libMasina"></span></li>
                            <!-- <li><strong>Vaomiera ny asa: </strong><span id="user-libVaomiera"></span></li> -->
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>



<script>
    $(document).ready(function() {
        $('.user1-row').click(function() {
            $('#user1-nom').text($(this).data('nom'));

            var pseudoValue = $(this).data('pseudo');
            if (pseudoValue !== null && pseudoValue !== undefined) {
                $('#user1-pseudo').text(pseudoValue);
            } else {
                $('#user1-pseudo').text("N/A");
            }

            var codeValue = $(this).data('code');
            if (codeValue !== null && codeValue !== undefined) {
                $('#user1-code').text(codeValue);
            } else {
                $('#user1-code').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== null && sexeValue !== undefined) {
                $('#user1-sexe').text(codeValue);
            } else {
                $('#user1-sexe').text("N/A");
            }
            
            var prenomValue = $(this).data('prenom');
            if (prenomValue !== null && prenomValue !== undefined) {
                $('#user1-prenom').text(prenomValue);
            } else {
                $('#user1-prenom').text("N/A");
            }

            var apvValue = $(this).data('apv');
            if (apvValue !== null && apvValue !== undefined) {
                $('#user1-apv').text(sexeValue);
            } else {
                $('#user1-apv').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== null && adresseValue !== undefined) {
                $('#user1-adresse').text(adresseValue);
            } else {
                $('#user1-adresse').text("N/A");
            }

            var faritraValue = $(this).data('faritra');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user1-libFaritra').text(faritraValue);
            } else {
                $('#user1-libFaritra').text("N/A");
            }

            var lieuValue = $(this).data('lieu');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user1-lieuSakramenta').text(lieuValue);
            } else {
                $('#user1-lieuSakramenta').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== null && masinaValue !== undefined) {
                $('#user1-libMasina').text(masinaValue);
            } else {
                $('#user1-libMasina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== null && vaomieraValue !== undefined) {
                $('#user1-libVaomiera').text(vaomieraValue);
            } else {
                $('#user1-libVaomiera').text("N/A");
            }

            var andraikitraValue = $(this).data('andraikitra');
            if (andraikitraValue !== null && andraikitraValue !== undefined) {
                $('#user1-libAndraikitra').text(andraikitraValue);
            } else {
                $('#user1-libAndraikitra').text("N/A");
            }

            var photoNom = $(this).data('sary');
            $('#user1-photo').attr('src', './uploads/masina/' + photoNom);

            $('#exampleModal1').modal('show');
        });
    });
</script>

        <!-- row faharoa -->
                      <br>
        <div class="row">
    <div class="col-md-6">
       
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Filohan’ny Vaomieran’asa</h6>
            </div>
            <div class="card-body" style="max-height: 200px;overflow-y: auto;">
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>N°</th> 
                              <th>Dirigent</th>
                              <th>Vaomieran'asa</th>
                              <!-- <th>Année</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                        $query = "SELECT konty.libPseudo, YEAR(konty.dteCrea) AS anneeCrea, vaomiera.libVaomiera, konty.* 
                                                  FROM konty 
                                                  LEFT JOIN vaomiera ON vaomiera.idVaomiera = konty.idVaomiera
                                                  WHERE konty.idVaomiera != '0';
                                                  ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                        echo "<tr class='user2-row' data-toggle='modal' data-target='#exampleModal2'
                          data-pseudo='" . $row['libPseudo'] . "'
                          data-code='" . $row['codeKonty'] . "'
                          data-sexe='" . $row['sexeKonty'] . "'
                          data-nom='" . $row['nomKonty'] . "'
                          data-prenom='" . $row['prenomKonty'] . "'
                          data-apv='" . $row['apvKonty'] . "'
                          data-adresy='" . $row['adresyKonty'] . "'
                          data-vaomiera='" . $row['libVaomiera'] . "'

                          data-sary='" . $row['saryKonty'] . "'>
                              <td>" . $i . "</td> 
                              <td>" . $row['nomKonty'] . "  " . $row['nomKonty'] . "</td>
                              <td>" . $row['libVaomiera'] . "</td>
                          
                        </tr>";
                      }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>
                    </table>  
            </div>
        </div>
        </div>
        
        </div>

        <!-- Modal -->
            <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  

                    <p id="user-details">
                        <img style='border-radius: 50%;' class='img-responsive'
                          width='100' height='100' id="user2-photo">
                        <ul>
                            <li><strong>Pseudo : </strong><span id="user2-pseudo"></span></li>
                            <li><strong>Code : </strong><span id="user2-code"></span></li>
                            <li><strong>Sexe : </strong><span id="user2-sexe"></span></li>
                            <li><strong>Nom : </strong><span id="user2-nom"></span></li>
                            <li><strong>Prénom(s) : </strong><span id="user2-prenom"></span></li>
                            <li><strong>APV : </strong><span id="user2-apv"></span></li>
                            <li><strong>Adresse : </strong><span id="user2-adresse"></span></li>
                            <!-- <li><strong>Faritra : </strong><span id="user1-libFaritra"></span></li> -->
                            <!-- <li><strong>Fikambanana Masina : </strong><span id="user1-libMasina"></span></li> -->
                            <li><strong>Vaomiera ny asa: </strong><span id="user2-libVaomiera"></span></li>
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>



<script>
    $(document).ready(function() {
        $('.user2-row').click(function() {
            $('#user2-nom').text($(this).data('nom'));

            var pseudoValue = $(this).data('pseudo');
            if (pseudoValue !== null && pseudoValue !== undefined) {
                $('#user2-pseudo').text(pseudoValue);
            } else {
                $('#user2-pseudo').text("N/A");
            }

            var codeValue = $(this).data('code');
            if (codeValue !== null && codeValue !== undefined) {
                $('#user2-code').text(codeValue);
            } else {
                $('#user2-code').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== null && sexeValue !== undefined) {
                $('#user2-sexe').text(codeValue);
            } else {
                $('#user2-sexe').text("N/A");
            }
            
            var prenomValue = $(this).data('prenom');
            if (prenomValue !== null && prenomValue !== undefined) {
                $('#user2-prenom').text(prenomValue);
            } else {
                $('#user2-prenom').text("N/A");
            }

            var apvValue = $(this).data('apv');
            if (apvValue !== null && apvValue !== undefined) {
                $('#user2-apv').text(sexeValue);
            } else {
                $('#user2-apv').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== null && adresseValue !== undefined) {
                $('#user2-adresse').text(adresseValue);
            } else {
                $('#user2-adresse').text("N/A");
            }

            var faritraValue = $(this).data('faritra');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user2-libFaritra').text(faritraValue);
            } else {
                $('#user2-libFaritra').text("N/A");
            }


            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== null && vaomieraValue !== undefined) {
                $('#user2-libVaomiera').text(vaomieraValue);
            } else {
                $('#user2-libVaomiera').text("N/A");
            }

            var photoNom = $(this).data('sary');
            $('#user2-photo').attr('src', './uploads/vaomiera/' + photoNom);

            $('#exampleModal1').modal('show');
        });
    });
</script>

    </div>
    <br>
<?php include 'pannelAmbany.php'; ?> 

