-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 26 déc. 2023 à 13:36
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `jead0`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE `activite` (
  `idActivite` int(11) NOT NULL,
  `libActivite` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `andraikitra`
--

CREATE TABLE `andraikitra` (
  `idAndraikitra` int(11) NOT NULL,
  `libAndraikitra` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `billet`
--

CREATE TABLE `billet` (
  `idBillet` int(11) NOT NULL,
  `de` int(11) NOT NULL,
  `a` int(11) NOT NULL,
  `idOperation` int(11) NOT NULL,
  `idKonty` int(11) NOT NULL,
  `paye` varchar(255) DEFAULT NULL,
  `distri` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `caisse`
--

CREATE TABLE `caisse` (
  `idCaisse` int(11) NOT NULL,
  `motif` varchar(250) NOT NULL,
  `type` varchar(255) NOT NULL,
  `montant` int(11) NOT NULL,
  `daty` date NOT NULL DEFAULT current_timestamp(),
  `solde` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ev`
--

CREATE TABLE `ev` (
  `idEv` int(11) NOT NULL,
  `libEv` varchar(255) NOT NULL,
  `debutEv` date NOT NULL,
  `finEv` date NOT NULL,
  `placeEv` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `faritra`
--

CREATE TABLE `faritra` (
  `idFaritra` int(11) NOT NULL,
  `codeFaritra` varchar(250) NOT NULL,
  `libFaritra` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `konty`
--

CREATE TABLE `konty` (
  `idKonty` int(11) NOT NULL,
  `libPseudo` varchar(250) NOT NULL,
  `libPass` varchar(255) NOT NULL,
  `libCategorie` varchar(200) NOT NULL,
  `idFaritra` int(11) DEFAULT NULL,
  `codeKonty` varchar(200) NOT NULL,
  `hashKonty` text NOT NULL,
  `idSakramenta` int(11) DEFAULT NULL,
  `idMasina` int(11) DEFAULT NULL,
  `idVaomiera` int(11) DEFAULT NULL,
  `saryKonty` varchar(200) DEFAULT NULL,
  `dteCrea` date NOT NULL,
  `sexeKonty` varchar(150) DEFAULT NULL,
  `nomKonty` varchar(255) DEFAULT NULL,
  `prenomKonty` varchar(255) DEFAULT NULL,
  `dteNaissKonty` date DEFAULT NULL,
  `apvKonty` varchar(150) DEFAULT NULL,
  `adresyKonty` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `konty`
--

INSERT INTO `konty` (`idKonty`, `libPseudo`, `libPass`, `libCategorie`, `idFaritra`, `codeKonty`, `hashKonty`, `idSakramenta`, `idMasina`, `idVaomiera`, `saryKonty`, `dteCrea`, `sexeKonty`, `nomKonty`, `prenomKonty`, `dteNaissKonty`, `apvKonty`, `adresyKonty`) VALUES
(1, 'jead', 'jeannot', 'superAdmin', 0, '', '', 0, 0, 0, 'img1.jpg', '0000-00-00', NULL, 'f', 'fg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `masina`
--

CREATE TABLE `masina` (
  `idMasina` int(11) NOT NULL,
  `codeMasina` varchar(250) NOT NULL,
  `libMasina` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `operation`
--

CREATE TABLE `operation` (
  `idOperation` int(11) NOT NULL,
  `libOperation` varchar(255) NOT NULL,
  `nbBillet` int(10) NOT NULL,
  `dteOperation` date NOT NULL,
  `descOperation` varchar(255) NOT NULL,
  `prixBillet` int(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `proactivite`
--

CREATE TABLE `proactivite` (
  `idPro` int(11) NOT NULL,
  `libActivite` varchar(200) NOT NULL,
  `debutActivite` date NOT NULL,
  `finActivite` date NOT NULL,
  `descActivite` text NOT NULL,
  `etatActivite` int(11) DEFAULT NULL,
  `placeActivite` varchar(200) NOT NULL,
  `idKonty` int(11) NOT NULL,
  `dtePresence` date DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `actif` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sakramenta`
--

CREATE TABLE `sakramenta` (
  `idSakramenta` int(11) NOT NULL,
  `libSakramenta` varchar(250) NOT NULL,
  `dteSakramenta` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `stocksakramenta`
--

CREATE TABLE `stocksakramenta` (
  `idStockSakramenta` int(11) NOT NULL,
  `idKonty` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idSakramenta` int(11) NOT NULL,
  `dteStockSakramenta` varchar(200) NOT NULL,
  `lieuStockSakramenta` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `idFaritra` int(11) NOT NULL,
  `idMasina` int(11) DEFAULT NULL,
  `idVaomiera` int(11) DEFAULT NULL,
  `idAndraikitra` int(11) DEFAULT NULL,
  `idSakramenta` int(11) DEFAULT NULL,
  `nomUser` varchar(200) NOT NULL,
  `codeUser` varchar(250) NOT NULL,
  `prenomUser` varchar(255) NOT NULL,
  `lieuSakramenta` varchar(250) DEFAULT NULL,
  `dteUser` date NOT NULL DEFAULT current_timestamp(),
  `sexeUser` varchar(110) NOT NULL,
  `qrUser` varchar(200) DEFAULT NULL,
  `saryUser` varchar(250) NOT NULL,
  `dteNaissUser` date NOT NULL DEFAULT current_timestamp(),
  `apvUser` varchar(250) NOT NULL,
  `adresyUser` varchar(255) NOT NULL,
  `dteSakramentaUser` date DEFAULT NULL,
  `hashKonty` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `vaomiera`
--

CREATE TABLE `vaomiera` (
  `idVaomiera` int(11) NOT NULL,
  `codeVaomiera` varchar(250) NOT NULL,
  `libVaomiera` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `vaomiera`
--

INSERT INTO `vaomiera` (`idVaomiera`, `codeVaomiera`, `libVaomiera`) VALUES
(4, 'va', 'dvsdv');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `activite`
--
ALTER TABLE `activite`
  ADD PRIMARY KEY (`idActivite`);

--
-- Index pour la table `andraikitra`
--
ALTER TABLE `andraikitra`
  ADD PRIMARY KEY (`idAndraikitra`);

--
-- Index pour la table `billet`
--
ALTER TABLE `billet`
  ADD PRIMARY KEY (`idBillet`);

--
-- Index pour la table `caisse`
--
ALTER TABLE `caisse`
  ADD PRIMARY KEY (`idCaisse`);

--
-- Index pour la table `ev`
--
ALTER TABLE `ev`
  ADD PRIMARY KEY (`idEv`);

--
-- Index pour la table `faritra`
--
ALTER TABLE `faritra`
  ADD PRIMARY KEY (`idFaritra`);

--
-- Index pour la table `konty`
--
ALTER TABLE `konty`
  ADD PRIMARY KEY (`idKonty`);

--
-- Index pour la table `masina`
--
ALTER TABLE `masina`
  ADD PRIMARY KEY (`idMasina`);

--
-- Index pour la table `operation`
--
ALTER TABLE `operation`
  ADD PRIMARY KEY (`idOperation`);

--
-- Index pour la table `proactivite`
--
ALTER TABLE `proactivite`
  ADD PRIMARY KEY (`idPro`);

--
-- Index pour la table `sakramenta`
--
ALTER TABLE `sakramenta`
  ADD PRIMARY KEY (`idSakramenta`);

--
-- Index pour la table `stocksakramenta`
--
ALTER TABLE `stocksakramenta`
  ADD PRIMARY KEY (`idStockSakramenta`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- Index pour la table `vaomiera`
--
ALTER TABLE `vaomiera`
  ADD PRIMARY KEY (`idVaomiera`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `activite`
--
ALTER TABLE `activite`
  MODIFY `idActivite` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `andraikitra`
--
ALTER TABLE `andraikitra`
  MODIFY `idAndraikitra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `billet`
--
ALTER TABLE `billet`
  MODIFY `idBillet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `caisse`
--
ALTER TABLE `caisse`
  MODIFY `idCaisse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT pour la table `ev`
--
ALTER TABLE `ev`
  MODIFY `idEv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `faritra`
--
ALTER TABLE `faritra`
  MODIFY `idFaritra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `konty`
--
ALTER TABLE `konty`
  MODIFY `idKonty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pour la table `masina`
--
ALTER TABLE `masina`
  MODIFY `idMasina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `operation`
--
ALTER TABLE `operation`
  MODIFY `idOperation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `proactivite`
--
ALTER TABLE `proactivite`
  MODIFY `idPro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `sakramenta`
--
ALTER TABLE `sakramenta`
  MODIFY `idSakramenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `stocksakramenta`
--
ALTER TABLE `stocksakramenta`
  MODIFY `idStockSakramenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT pour la table `vaomiera`
--
ALTER TABLE `vaomiera`
  MODIFY `idVaomiera` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
