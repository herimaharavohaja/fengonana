<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>À Propos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }

        header {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #343a40;
        }

        p {
            color: #666666;
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<?php
    include 'connect.php';
    session_start();
    $cat = isset($_SESSION['libCategorie']) ? $_SESSION['libCategorie'] : '';
    $fari = isset($_SESSION['idMasina']) ? $_SESSION['idMasina'] : '';
    include 'pannelAmbony.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <header>
                <h1>À propos de J.F.D.S</h1>
            </header>
        </div>
    </div>

    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <section>
                <h2>Nous sommes qui ?</h2>
                <p>J.F.D.S ou plus précisement Jeune Foi Digital Soavimasoandro <br>
                    est un 
                    plateforme d'association des jeunes croyant de l'église catholique sise à 
                    Soavimasoandro</p>

                <h2>Nos contacts</h2>
                <p>mail : <strong>vdktsoavimasoandro@gmail.com</strong></p>
                <p>téléphone :<strong> 0341256232 </strong></p>
                <p>facebook : <strong><a style="text-decoration: none;" href="">vdkt soavimasoandro</a></strong></p>

                <h2>Créé par: </h2>
                <p>&copy; jead 2023 ( adlinjeannot@gmail.com / 0326891205 )</p>
            </section>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>

<?php include 'pannelAmbany.php'; ?>
</body>
</html>
