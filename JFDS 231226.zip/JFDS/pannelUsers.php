<?php 

    include('connect.php');


    $isAdmin = $_SESSION['libCategorie'];
    $libPseudo = $_SESSION['libPseudo'];

    if ($isAdmin == "User") { // Notez que je mets en minuscules "user" car vous vérifiez plus tard si c'est "User"
?>
<hr class="sidebar-divider m-0">
<?php 
    $sqlF = "SELECT konty.*, faritra.libFaritra AS faritra, masina.libMasina AS masina, vaomiera.libVaomiera AS vaomiera FROM konty 
        LEFT JOIN faritra ON faritra.idFaritra = konty.idFaritra
        LEFT JOIN masina ON masina.idMasina = konty.idMasina
        LEFT JOIN vaomiera ON vaomiera.idVaomiera = konty.idVaomiera
        WHERE konty.libPseudo = '$libPseudo'";

    $resultF = mysqli_query($conn, $sqlF);

    if (mysqli_num_rows($resultF) > 0) {
        $rowF = mysqli_fetch_assoc($resultF);
        $idFaritraF = $rowF["idFaritra"];
        $idMasinaF = $rowF["idMasina"];
        $idVaomieraF = $rowF["idVaomiera"];
        if ($idFaritraF > 0) {
?>          
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages" style="padding: 8px;">
                    <i class="bi bi-diagram-3-fill"></i>
                    <span>Faritra 
                        <?php 
                        // echo $rowF["faritra"]; 
                        ?>
                    </span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Diverses actions:</h6>
                        
                        <!-- <a class="collapse-item" href="respFaritra.php">Filoha</a> -->
                        <a class="collapse-item" href="faritraUser.php">Mpikambana</a>
                        <a class="collapse-item" href="stockSakramenta.php">Sakramenta</a>
                        <!-- <a class="collapse-item" href="creaActivite.php">Hetsika</a> -->
                    </div>
                </div>
            </li>
<?php 
        } elseif ($idMasinaF > 0) {
?>          
            <!-- <hr class="sidebar-divider"> -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages1"
                    aria-expanded="true" aria-controls="collapsePages" style="padding: 8px;">
                    <i class="bi bi-diagram-3-fill"></i>
                    <span>Fikambanana Masina 
                        <?php 
                        // echo $rowF["masina"];
                         ?>
                    </span>
                </a>
                <div id="collapsePages1" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Diverses actions:</h6>

                        <!-- <a class="collapse-item" href="respMasina.php">Filoha</a> -->
                        <a class="collapse-item" href="masinaUser.php">Mpikambana</a>
                        <!-- <a class="collapse-item" href="creaActivite.php">Teti-andro</a> -->
                    </div>
                </div>
            </li>
<?php 
        } elseif ($idVaomieraF > 0) {
?>          
            <!-- <hr class="sidebar-divider"> -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages2"
                    aria-expanded="true" aria-controls="collapsePages" style="padding: 8px;">
                    <i class="bi bi-diagram-3-fill"></i>
                    <span>Vaomieran'asa 
                        <?php 
                        // echo $rowF["vaomiera"]; 
                        ?>
                    </span>
                </a>
                <div id="collapsePages2" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Diverses actions:</h6>
                        <!-- <a class="collapse-item" href="respVaomiera.php">Filoha</a> -->
                        <a class="collapse-item" href="vaomieraUser.php">Mpikambana</a>
                        <!-- <a class="collapse-item" href="creaActivite.php">Teti-andro</a> -->
                    </div>
                </div>
            </li>
<?php 
        }
    }
}
?>
