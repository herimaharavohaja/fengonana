<?php
// saveEdit.php
include 'connect.php';  

header('Content-Type: application/json');

// Récupérer les données du corps de la requête
$data = json_decode(file_get_contents('php://input'), true);

// Ajoutez des logs pour afficher les données reçues
file_put_contents('log.txt', print_r($data, true), FILE_APPEND);

if ($data && isset($data['id']) ) {
    // Utilisez les données pour mettre à jour la base de données
    $id = $data['id'];
    $editedCode = $data['editedCode'];
    $editedNom = $data['editedNom'];
    $editedPrenom = $data['editedPrenom'];
    $editedAdresy = $data['editedAdresy'];

    // Échapper les valeurs pour éviter les injections SQL
    $editedCode = $conn->real_escape_string($editedCode);
    $editedNom = $conn->real_escape_string($editedNom);
    $editedPrenom= $conn->real_escape_string($editedPrenom);
    $editedAdresy = $conn->real_escape_string($editedAdresy);
    $id = (int)$id;

    // Exécuter la requête SQL de mise à jour
    $query = "UPDATE user SET codeUser = '$editedCode', nomUser = '$editedNom', prenomUser = '$editedPrenom', adresyUser = '$editedAdresy' WHERE idUser = $id";

    // Ajoutez des logs pour afficher la requête SQL
    file_put_contents('log.txt', "\n$query\n", FILE_APPEND);

    if ($conn->query($query) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }

    // Fermer la connexion à la base de données
    $conn->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Données non valides']);
}
?>
