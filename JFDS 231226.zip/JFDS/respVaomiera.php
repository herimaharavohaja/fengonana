<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idVaomiera'];

?>          
<?php include 'pannelAmbony.php'; ?>  
        <div class="container">
            
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="">
                    <div >
                        <?php 
                          $sqlF = "SELECT konty.*, vaomiera.* FROM konty 
                            left JOIN vaomiera ON vaomiera.idVaomiera= konty.idVaomiera
                            WHERE konty.libPseudo = '$libPseudo'";

                          $resultF = mysqli_query($conn, $sqlF);

                          if (mysqli_num_rows($resultF) > 0) {
                              $rowF = mysqli_fetch_assoc($resultF);
                              $idVaomieraF = $rowF["idVaomiera"];
                              $libVaomieraF = $rowF["libVaomiera"];
                         ?>
                        <h4 class="text-center"><b><?php echo ("Mpandrindra ny vaomieran'asa"); ?> <?php echo $rowF["libVaomiera"]; }?></b></h4>
                        
                    </div>
                    <div class="text-center" style="max-height: 400px;overflow-y: auto;">
                        <table class="table table-bordered">
                        <thead class="alert-success " style="background: navy; color: white;">

                          <tr class="text-center">
                            <th>N°</th>
                            <th class="text-center">Pseudo</th>

                          </tr>
                        </thead>
                        <tbody>
                          <?php 

                        // Requête SQL pour sélectionner tous les utilisateurs
                        $sqlL = "SELECT konty.*, vaomiera.* FROM konty 
                            INNER JOIN vaomiera ON vaomiera.idVaomiera = konty.idVaomiera
                            WHERE vaomiera.libVaomiera = '$libVaomieraF'";
                        $resultL = mysqli_query($conn, $sqlL);

                        if (mysqli_num_rows($resultL) > 0 ) {
                            $i = 0;
                            // Affichage des données de chaque utilisateur
                            while($rowL = mysqli_fetch_assoc($resultL)) {
                                $i = $i+1;
                                $libPseudo = $rowL["libPseudo"];

                                ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $libPseudo; ?></td>
                                </tr>
 
                <?php 
                }
            } else {
                echo "Néant";
            }

            // Fermeture de la connexion
            mysqli_close($conn);
          ?>
          </tbody>
                </table>
                    </div>
                    <br><br>
                </div>
            </div>

            <div class="col-md-1"></div>
        </div>
    </div>
    <br><br>
<?php include 'pannelAmbany.php'; ?> 