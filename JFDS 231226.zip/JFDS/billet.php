<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

if (isset($_POST['enregistrer'])) {
    $idOperation = $_POST['idOperation'];
    $idKonty = $_POST['idKonty'];
    $de = $_POST['de'];
    $a = $_POST['a'];

    // Récupérer le maximum de 'de' et le minimum de 'a' pour idOperation = 1
    $querySelect = "SELECT MAX(de) AS maxDe, MIN(a) AS minA FROM billet WHERE idOperation = '$idOperation'";
    $resultSelect = $conn->query($querySelect);

    if ($resultSelect->num_rows > 0) {
        $row = $resultSelect->fetch_assoc();
        $maxDeActuel = $row['maxDe'];
        $minAActuel = $row['minA'];

        // Vérifier si le nombre de 'de' ou de 'a' n'est pas compris dans la plage spécifiée
        if ($de < $maxDeActuel || $a > $minAActuel) {
            // Insertion si la condition est satisfaite
            $queryInsert = "INSERT INTO billet (de, a, idOperation, idKonty) VALUES ('$de', '$a', '$idOperation', '$idKonty')";
            $resultInsert = $conn->query($queryInsert);

            if ($resultInsert) {
                header("Location: billet.php");
            } else {
                echo "Erreur lors de l'insertion dans la table billet.";
            }
        } else {
            echo "<div id='notification' 
                    style='display:none;margin-top:-50px;margin-left:480px;width:border-radius: 20px;position:absolute;z-index:999999;padding:18px;background: red;color: white;'>
                    Le nombre de Debut ou de la fin est déjà occupé.</div>";
            echo "<script>
                    document.getElementById('notification').style.display = 'block';
                    setTimeout(function(){
                        document.getElementById('notification').style.display = 'none';
                    }, 10000);
                  </script>";
        }
    } else {
        echo "Aucune valeur.";
    }
}


      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte2.php'; ?>   
<br>

    <div class="container" style="border-radius: ">
    <div class="row">
    <div class="col-md-4">
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Billet</h6>
            </div>
            <div class="card-body" style='max-height: 400px; overflow-y: auto;'>
                <form action="" method="POST" enctype="multipart/form-data">
                	<div style="display: flex; align-items: center;">
                        <!-- <label class="form-label" >Opérations</label> -->
                        <?php 
                                    $sqlOperation = "SELECT * FROM operation";
                                    $resultOperation = $conn->query($sqlOperation);

                                    $optionOperation = [];
                                    if ($resultOperation->num_rows > 0) {
                                        while ($rowOperation = $resultOperation->fetch_assoc()) {
                                            $optionOperation[] = $rowOperation;
                                        }
                                    }
                        ?>
                        <div class="form-outline mb-4">
                            <select name="idOperation" required class="form-control" style="width: 140px;">
                                        <option value="" disabled selected hidden>Opération</option>
                                        <?php foreach ($optionOperation as $optionOperation ) : ?>
                                            <option value="<?php echo $optionOperation['idOperation']; ?>">
                                                
                                                <?php echo $optionOperation['libOperation']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                        </div>
                    </div>

                    <div style="display: flex; align-items: center;">
                        <!-- <label class="form-label" >Staff</label> -->
                        <?php 
                                    $sqlKonty = "SELECT * FROM konty";
                                    $resultKonty = $conn->query($sqlKonty);

                                    $optionKonty = [];
                                    if ($resultKonty->num_rows > 0) {
                                        while ($rowKonty = $resultKonty->fetch_assoc()) {
                                            $optionKonty[] = $rowKonty;
                                        }
                                    }
                        ?>
                        <div class="form-outline mb-4">
                            <select name="idKonty" required class="form-control" style="width: 140px;">
                                        <option value="" disabled selected hidden>Membre</option>
                                        <?php foreach ($optionKonty as $optionKonty ) : ?>
                                            <option value="<?php echo $optionKonty['idKonty']; ?>">
                                                
                                                <?php echo $optionKonty['nomKonty'] . ' ' . $optionKonty['prenomKonty']; ?>

                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                        </div>
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Code</label> -->
                        <input type="text"  name="de" class="form-control" required placeholder="De" style="width: 60px;" />
                        &nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="text"  name="a" class="form-control" required placeholder="à" style="width: 60px;" />
                    </div>

                    
                    <div>

                        <input type="submit" class="btn btn-info" name="enregistrer" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Lisitry ny billet</h6>

            </div>
            <div class="card-body" style="max-height: 450px;overflow-y: auto;">
                    <!-- ... Votre tableau HTML ... -->
            <table id="Table_util" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>De</th>
                        <th>à</th>
                        <th>Opération</th>
                        <th>Staff</th>
                        <th colspan="2" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 0;
                        $query = "SELECT 
                                    b.idBillet,
                                    b.de, 
                                    b.a,
                                    o.libOperation as operation,
                                    CONCAT(k.nomKonty, ' ', k.prenomKonty) AS staff
                                    FROM billet b
                                    LEFT JOIN operation o ON o.idOperation = b.idOperation
                                    LEFT JOIN konty k ON k.idKonty = b.idKonty
                                    ";
                        $result = $conn->query($query);

                        if ($result->num_rows > 0) {
                            while ($rowK = $result->fetch_array()) {
                                $i = $i + 1;
                    ?>

                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $rowK['de'] ?></td>
                        <td><?php echo $rowK['a']?></td>
                        <td><?php echo $rowK['operation']?></td>
                        <td><?php echo $rowK['staff']?></td>
                        <td style="text-align: right;">
                            <a href="deleteKonty.php?billet=<?php echo $rowK['idBillet']; ?>">
                                <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i>
                                </button>
                            </a>
                        </td>
                    </tr>

                    <?php }

                    } else {
                        echo "<p>Il n'y a pas d'enregistrement!</p>";
                    } ?>
                </tbody>
            </table>

            </div>
        </div>
    </div>
    </div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 