<?php

include 'connect.php'; // Assurez-vous d'inclure votre script de connexion à la base de données

$query = "SELECT * FROM vaomiera";
$result = $conn->query($query);

$vaomieraList = array();
while ($row = $result->fetch_assoc()) {
    $vaomieraList[] = $row;
}

echo json_encode($vaomieraList);
?>
