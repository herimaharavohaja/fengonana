<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $sql = "SELECT *
      FROM proActivite
      WHERE idPro = $ida";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  // $id = $row['id'];
  $debutActivite = $row['debutActivite'];
  $finActivite = $row['finActivite'];
  $descActivite = $row['descActivite'];
  }


  if (isset($_POST['modif'])) {
  $libActivite = $conn->real_escape_string(($_POST['libActivite']));
  $debutActivite = $conn->real_escape_string($_POST['debutActivite']);
  $finActivite = $conn->real_escape_string($_POST['finActivite']);
  $descActivite = $conn->real_escape_string(($_POST['descActivite']));

    $query = "UPDATE proActivite SET libActivite='$libActivite', debutActivite='$debutActivite', finActivite='$finActivite', descActivite = '$descActivite' WHERE idPro=$ida";
    $result1 = $conn->query($query);
     header("Location:creaActivite.php");
  }else{
  }


 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Modification du programme d'activité</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">


                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Activité</label>
                        <?php 
                                $sqlActivite = "SELECT * FROM activite";
                  $resultActivite = $conn->query($sqlActivite);

                  $optionActivite = [];
                  if ($resultActivite->num_rows > 0) {
                    while ($rowActivite = $resultActivite->fetch_assoc()) {
                      $optionActivite[] = $rowActivite;
                    }
                  }
            ?>
                        <div class="form-outline mb-4">
                            <select name="libActivite"  class="form-control" required>
                                  <option value="" disabled selected hidden>Activite</option>
                                  <?php foreach ($optionActivite as $optionsActivite ) : ?>
                                    <option value="<?php echo $optionsActivite['libActivite']; ?>">
                                      
                                      <?php echo $optionsActivite['libActivite']; ?>
                                    </option>
                                  <?php endforeach; ?>
                                </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Du</label>
                        <div class="form-outline mb-4">
                            <input type="date" id="form1Example1" name="debutActivite" class="form-control" value="<?php echo $debutActivite; ?>"/>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Au</label>
                        <div class="form-outline mb-4">
                            <input type="date" id="form1Example1" name="finActivite" class="form-control" value="<?php echo $finActivite; ?>" />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Déscription</label>
                        <div class="form-outline mb-4">
                            <textarea name="descActivite" class="form-control" ><?php echo $descActivite; ?></textarea>
                        </div>
                     </div>


                    <div class="mb-3">

                        <input type="submit" class="btn btn-info" name="modif" value="Modifier"  />
                    </div>
                </form>
                                </div>
                            </div>
    </div>
    <div class="col-md-4"></div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 