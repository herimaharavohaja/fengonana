<?php
include 'connect.php';

// Vérifier si l'ID du membre est passé en POST
if (isset($_POST['idKonty'])) {
    $idKonty = $_POST['idKonty'];
    $idOperation = $_POST['idOperation'];

    // Requête SQL pour récupérer les numéros de billet du membre sélectionné
    $sql = "SELECT * FROM billet WHERE idKonty = $idKonty AND idOperation = $idOperation";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Construire la liste des numéros de billet avec des cases à cocher
        echo '<form id="billetList" action="processForm.php" method="post">';
        while ($row = $result->fetch_assoc()) {
            $de = (int)$row['de'];
            $a = (int)$row['a'];

            echo '<div class="billet-group">';
            // Boucle pour générer la séquence de numéros de billet
            for ($i = $de; $i <= $a; $i++) {
                $checked = in_array($i, explode(',', $row['paye'])) ? 'checked' : '';

                echo '<div class="billet-item">';
                echo '<input type="checkbox" name="billets[]" value="' . $i . '" ' . $checked . '> ' . $i ;
                echo '<input type="hidden" name="idBillet" value="' . $row['idBillet'] . '"> ';
                echo '</div>';

                // Passer à la ligne après chaque groupe de 5 numéros
                if ($i % 5 == 0) {
                    echo '<br>';
                }
            }
            echo '</div>';
        }
        echo '<button type="submit" name="submit1" class="btn btn-info">Marquer payé</button>';
        echo '</form>';
    } else {
        echo 'Aucun billet trouvé pour ce membre.';
    }
} else {
    echo 'ID du membre non spécifié.';
}

// Fermer la connexion à la base de données
$conn->close();
?>

<style type="text/css">
    .billet-group {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 10px; 
        max-height: 450px;
        overflow-y: auto;
    }

    .billet-item {
        width: 80px; /* Largeur fixe pour chaque élément de la liste */
        margin-right: 10px; /* Espacement entre les numéros de billet */
    }
</style>
