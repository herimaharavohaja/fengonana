<?php

include 'connect.php';
// Vérification de la soumission du formulaire
if (isset($_POST['submitSakramenta'])) {

    // Récupération des données du formulaire
    $idSakramenta = $_POST['idSakramenta'];
    $dteSakramentaUser = $_POST['dteSakramentaUser'];
    $lieuSakramenta = $_POST['lieuSakramenta'];
    

    // Insertion des données dans la base de données si aucune erreur n'a été détectée
    if (empty($erreurs)) {
        $sql = "INSERT INTO user (idFaritra, idSakramenta, nomUser, prenomUser, dteUser, sexeUser, dteNaissUser, apvUser, adresyUser, dteSakramentaUser, lieuSakramenta, saryUser) VALUES ('$fari', '$idSakramenta', '$nomUser', '$prenomUser',  '$daty', '$sexeUser', '$dteNaissUser', '$apvUser', '$adresyUser',  '$dteSakramentaUser', '$lieuSakramenta', '$nomImagesaryUser')";   

        if ($conn->query($sql) === TRUE) {
            
            ?>
                <script>
			    window.location.href='creaSakramenta.php';
			    </script>
			<?php

        } else {
            header('Location: creaFaritra.php');
        }
    } 

} 

?>			
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					<h4 class='text-center' style=''><b>Ajouter un membre<br></b><br></h4>
					<form method='post' enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class='form-group'>
		                            <label>Sary:</label> 
		                            <input type="file" class="form-control" style="border:none; background: none;" name="saryUser" required/>
                        		</div>
							</div>
							<div class="col-md-8"></div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
		                            <label>Sexe:</label> 
		                            <br>
		                            <select name="sexeUser" required class="form-control">
		                            	<option value="" disabled selected hidden>Sexe</option>
		                            	<option value="Masculin">Masculin</option>
		                            	<option value="Féminin">Féminin</option>
		                            </select>
		                            
                        		</div>
							</div>
							<div class="col-md-6">
								<div class='form-group'>
									<label>Nom:</label> 
		                            <input class='form-control' required type='text' name='nomUser'>
		                            <br>
                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
									<label>Prénom(s):</label> 
		                            <input class='form-control' type='text' name='prenomUser'>
		                            <br>
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
		                            <label>Date de naissance:</label> 
		                            <input type="date" name="dteNaissUser" class="form-control" required>
                        		</div>
							</div>
							<div class="col-md-6">
								<div class='form-group'>
									<label>APV:</label> 
		                            <input class='form-control' required type='text' name='apvUser'>

                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
		                            <label>Adresse actuelle:</label> 
		                            <input class='form-control' required type='text' name='adresyUser'>
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
										<br>
		                            <label>Daty sakramenta:</label>
		                            <br> 
		                            <input type="date" name="dteSakramentaUser" class="form-control" >
                        		</div>
							</div>

							<div class="col-md-6">
								<div class='form-group'>
		                            <?php 
		                            
									$sqlSakramenta = "SELECT * FROM sakramenta";
									$resultSakramenta = $conn->query($sqlSakramenta);

									$optionSakramenta = [];
									if ($resultSakramenta->num_rows > 0) {
										while ($rowSakramenta = $resultSakramenta->fetch_assoc()) {
											$optionSakramenta[] = $rowSakramenta;
										}
									}
								 ?>
								 	<br>
		                            <label>Sakramenta:</label> 
		                            <br>
		                            <select name="idSakramenta" class="form-control">
		                            	<option value="" disabled selected hidden>Sakramenta</option>
		                            	<?php foreach ($optionSakramenta as $optionsSakramenta ) : ?>
		                            		<option value="<?php echo $optionsSakramenta['idSakramenta']; ?>">
		                            			
		                            			<?php echo $optionsSakramenta['libSakramenta']; ?>
		                            		</option>
		                            	<?php endforeach; ?>
		                            </select>
                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
										<br>
		                            <label>Lieu du sakramenta:</label>
		                            <br> 
		                            <input type="text" name="lieuSakramenta" class="form-control" >
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-5"></div>
							<div class="col-md-4">
								<br>
								<button type="submit" name= "submitSakramenta" class="btn btn-success" >
	                    			<span class="bi bi-trash"></span> Créer 
	                    		</button>
							</div>
							<div class="col-md-3"></div>
						</div>
					</form>
				</div>
				<div class="col-md-1"></div>
			</div>
				
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10">
                <div class="">
                	<div >
                		<br><br>
                        <h4 class="text-center"><b><?php echo ("Liste de membre"); ?></b></h4>
                        
                    </div>
                    <div class="text-center">
                        <table class="table table-bordered">
				        <thead class="alert-success " style="background: navy;color: white;">

						  <tr class="text-center">
				            <!-- <th>N°</th> -->
				            <th class="text-center">Code</th>
				            <th class="text-center">Nom</th>
				            <th class="text-center">Prénom(s)</th>
				            <!-- <th class="text-center">Âge</th> -->
				            <th class="text-center">Adresse</th>
				            <th class="text-center">Andraikitra</th>
				            <th class="text-center">Sakramenta</th>
				            <th class="text-center">Date d'inscription</th>
				            <th class="text-center" colspan="2">Actions</th>
				          </tr>
				        </thead>
				        <tbody>
				          <?php 

						// Requête SQL pour sélectionner tous les utilisateurs
						$sqlkonty = "SELECT faritra.*, user.*, sakramenta.*, andraikitra.* FROM user 
							INNER JOIN faritra ON faritra.idFaritra = user.idFaritra
							INNER JOIN andraikitra ON andraikitra.idAndraikitra = user.idAndraikitra
							INNER JOIN sakramenta ON sakramenta.idSakramenta = user.idSakramenta
							ORDER BY user.IdUser DESC LIMIT 4";
						$resultkonty = mysqli_query($conn, $sqlkonty);

						if (mysqli_num_rows($resultkonty) > 0 ) {
							$i = 0;
						    // Affichage des données de chaque utilisateur
						    while($row = mysqli_fetch_assoc($resultkonty)) {
						    	// $i = $i+1;
						    	$idUser = $row["idUser"];
						        $codeUser = $row["codeUser"];
						        $nomUser = $row["nomUser"];
						        $prenomUser = $row["prenomUser"];
						        $dteNaissUser = $row["dteNaissUser"];
						        $adresyUser = $row["adresyUser"];
						        $libAndraikitra = $row["libAndraikitra"];
						        $libSakramenta = $row["libSakramenta"];
						        $dteUser = $row["dteUser"];
						        $sexeUser = $row["sexeUser"];
						        ?>
						        <tr>
				                    <td><?php echo $codeUser; ?></td>
				                    <td><?php echo $nomUser; ?></td>
				                    <td><?php echo $prenomUser; ?></td>
				                    <!-- <td><?php echo $dteNaissUser; ?></td> -->
				                    <td><?php echo $adresyUser; ?></td>
				                    <td><?php echo $libAndraikitra; ?></td>
				                    <td><?php echo $libSakramenta; ?></td>
				                    <td><?php echo $dteUser; ?></td>
				                    <td class="text-center">
				                    	<a href="modifMembre.php?id=<?php echo $row['idUser']; ?>">
		                                  <button type="button" class="btn btn-primary" >Modifier </button>
		                                </a>
		                            </td>
		                            <td>
		                                <a href="deleteKonty.php?supprMembre=<?php echo $row['idUser']; ?>">
		                                  <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ce compte?')">Supprimer </button>
		                                </a>
	                    			</td>
                    
                  	</tr>
 
               	<?php 
			    }
			} else {
			    echo "Néant";
			}

			// Fermeture de la connexion
			mysqli_close($conn);
          ?>
          </tbody>
      			</table>
                    </div>
                    <br><br>
                </div>
            </div>

            <div class="col-md-1"></div>
        </div>
        <br><br><br><br>