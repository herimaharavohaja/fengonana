<?php
// Connexion à la base de données
include 'connect.php';

// Vérifiez si le formulaire a été soumis
if (isset($_POST['submit1'])) {
    // Récupérez les numéros de billet cochés
    if (isset($_POST['billets']) && is_array($_POST['billets'])) {
        $billetsPayes = $_POST['billets'];
        $idBillet = $_POST['idBillet'];

        // Vérifiez si les billets n'ont pas déjà été payés
        $existingPayedBillets = [];
        $sqlCheckPayed = "SELECT paye FROM billet WHERE idBillet = '$idBillet'";
        $resultCheckPayed = $conn->query($sqlCheckPayed);

        if ($resultCheckPayed->num_rows > 0) {
            $rowCheckPayed = $resultCheckPayed->fetch_assoc();
            $existingPayedBillets = explode(',', $rowCheckPayed['paye']);
        }

        $newPayedBillets = array_unique(array_merge($existingPayedBillets, $billetsPayes));

        // Mettez à jour la colonne 'paye' pour les numéros de billet sélectionnés
        $newPayedBilletsString = implode(',', $newPayedBillets);
        $sqlUpdate = "UPDATE billet SET paye = '$newPayedBilletsString' WHERE idBillet = '$idBillet'";
        $conn->query($sqlUpdate);
        header("Location: mark.php");
        // Affichez un message de succès
        // echo "Billets payés avec succès!";
    } else {
        // Affichez un message d'erreur si aucun billet n'a été sélectionné
        // echo "Aucun billet sélectionné.";
        header("Location: mark.php");
    }
}

// Fermez la connexion à la base de données
$conn->close();
?>
