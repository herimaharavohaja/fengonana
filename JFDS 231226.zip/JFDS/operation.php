<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
// echo $fari;
 if (isset($_POST['enregistrer'])) {
    $libOperation = $_POST['libOperation'];
    $nbBillet = $_POST['nbBillet'];
    $prixBillet = $_POST['prixBillet'];
    $libOperation = mysqli_real_escape_string($conn, $libOperation);
    $dteOperation = $_POST['dteOperation'];
    $descOperation = $_POST['descOperation'];
    $descOperation = mysqli_real_escape_string($conn, $descOperation);

            // Si la valeur n'existe pas, faire quelque chose d'autre ici
            $query  = "INSERT INTO operation 
                (libOperation, nbBillet, dteOperation, descOperation, prixBillet) 
                VALUES ('$libOperation', '$nbBillet','$dteOperation', '$descOperation', '$prixBillet')";
            $result = $conn->query($query);
            header("Location: operation.php");
      }
      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte2.php'; ?>   
<br>
    <div class="container">
    <div class="row">
    <div class="col-md-4">
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Opération</h6>
            </div>
            <div class="card-body" style='max-height: 400px; overflow-y: auto;'>
                <form action="" method="POST" enctype="multipart/form-data">
                	
                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Code</label> -->
                        <input type="text"  name="libOperation" class="form-control" required placeholder="Nom de l'opération" />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Pseudo</label> -->
                        <input type="text"  name="nbBillet" class="form-control" required placeholder="Nombre de billet" />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Mot de passe</label> -->
                        <input type="text" id="form1Example2" name="prixBillet"  class="form-control" required placeholder="Prix de billet (Ariary)" />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <textarea class='form-control' name='descOperation' placeholder="description">
                        </textarea>
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Prénom(s):</label>  -->
                        <input class='form-control' type='date' name='dteOperation' placeholder="Date d'opération">
                    </div>
                    <div>

                        <input type="submit" class="btn btn-info" name="enregistrer" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Lisitry ny opération</h6>

            </div>
            <div class="card-body" style="max-height: 450px;overflow-y: auto;">
                    <!-- ... Votre tableau HTML ... -->
            <table id="Table_util" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Libéllé</th>
                        <th>Nombre</th>
                        <th>date</th>
                        <th>Description</th>
                        <th colspan="2" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 0;
                        $query = "SELECT * FROM operation ORDER BY dteOperation ASC";
                        $result = $conn->query($query);

                        if ($result->num_rows > 0) {
                            while ($rowK = $result->fetch_array()) {
                                $i = $i + 1;
                    ?>

                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $rowK['libOperation'] ?></td>
                        <td><?php echo $rowK['nbBillet']?></td>
                        <td><?php echo $rowK['dteOperation']?></td>
                        <td><?php echo $rowK['descOperation']?></td>
                        <td style="text-align: right;">
                            <a href="deleteKonty.php?operation=<?php echo $rowK['idOperation']; ?>">
                                <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i>
                                </button>
                            </a>
                        </td>
                    </tr>

                    <?php }

                    } else {
                        echo "<p>Il n'y a pas d'enregistrement!</p>";
                    } ?>
                </tbody>
            </table>

            </div>
        </div>
    </div>
    </div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 