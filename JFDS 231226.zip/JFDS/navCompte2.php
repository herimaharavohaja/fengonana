<style>
    .collapsible-container {
      display: flex;
      justify-content: space-between;
      margin-top: -24px;
    }

    .collapsible {
      background-color: #777;
      color: white;
      cursor: pointer;
      padding: 18px;
      flex-grow: 1;
      border: none;
      text-align: center;
      outline: none;
      font-size: 15px;
      transition: background-color 0.3s;
    }
    .collapsible:hover {
      background-color: skyblue; /* Changement de couleur au survol de la souris */
    }

    .collapsible.active {
      background-color: #555; 
    }

    .content {
      padding: 0 18px;
      display: none;
      overflow: hidden;
      background-color: #f1f1f1;
      width: 100%;
    }

    .noButton {
        border: none;
        background: none;
        padding: 0;
        margin: 0;
        font-size: inherit;
        color: white;
    }
  </style>

<div class="collapsible-container">
        <a href="operation.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'operation.php') ? 'active' : ''; ?>">
            <button class="noButton">Opération</button>
        </a>
        <a href="billet.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'billet.php') ? 'active' : ''; ?>">
            <button class="noButton">Billet</button>
        </a>
        <a href="mark.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'mark.php') ? 'active' : ''; ?>">
            <button class="noButton">Marquage</button>
        </a>
        <a href="situation.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'situation.php') ? 'active' : ''; ?>">
            <button class="noButton">Situation</button>
        </a>
        <a href="distri.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'distri.php') ? 'active' : ''; ?>">
          <button class="noButton">Distribution</button>
        </a>
        <a href="resu.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'resu.php') ? 'active' : ''; ?>">
          <button class="noButton">Résultat</button>
        </a>
</div>