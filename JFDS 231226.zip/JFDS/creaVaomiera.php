<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];

if (isset($_POST['enregistrerVaomiera'])) {
    $codeVaomiera = $_POST['codeVaomiera'];
    $libVaomiera = $_POST['libVaomiera'];

    $codeVaomiera = mysqli_real_escape_string($conn, $codeVaomiera);
    $libVaomiera = mysqli_real_escape_string($conn, $libVaomiera);

            // Si la valeur n'existe pas, faire quelque chose d'autre ici
            $query  = "INSERT INTO vaomiera (codeVaomiera, libVaomiera) VALUES ('$codeVaomiera', '$libVaomiera')";
            $result = $conn->query($query);
            header("Location: creaVaomiera.php");
      
      }
 ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte1.php'; ?>   
<br>
  <?php if ($cat == "User" OR $cat == "membre") {
    //page user faritra
    // include 'faritraUser.php';
    header("Location: index.php");
  } else { ?>
    <div class="container">
    <div class="row">
    <div class="col-md-4">
        <br>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Vaomieran'asa</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Code</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="codeVaomiera" class="form-control" required />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Libellé</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libVaomiera" class="form-control" required />
                        </div>
                    </div>

                    <div class="mb-3">

                        <input type="submit" class="btn btn-success" name="enregistrerVaomiera" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <br>
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Listry ny Vaomieran’asa</h6>
                
            </div>
            <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <!-- <th>Numéro</th> -->
                              <th>Code</th>
                              <th>Libellé</th>
                              <th colspan="2" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                $query = "SELECT * FROM vaomiera ORDER BY idVaomiera ASC ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  

                        <tr>
                            <td>
                <span id="code_<?php echo $row['idVaomiera']; ?>">
                    <?php echo $row['codeVaomiera'] ?>
                </span>
                <form id="code_form_<?php echo $row['idVaomiera']; ?>" style="display:none;">
                    <input type="text" name="editedCode" class="form-control" value="<?php echo $row['codeVaomiera']; ?>">
                </form>
            </td>
            <td>
                <span id="lib_<?php echo $row['idVaomiera']; ?>">
                    <?php echo $row['libVaomiera']?>
                </span>
                <form id="lib_form_<?php echo $row['idVaomiera']; ?>" style="display:none;">
                    <input type="text" name="editedValue" class="form-control" value="<?php echo $row['libVaomiera']; ?>">
                </form>
            </td>
            <td style="text-align: right;">
                <button type="button" id="mod_<?php echo $row['idVaomiera']; ?>" class="btn btn-primary" onclick="editRow(<?php echo $row['idVaomiera']; ?>)"><i class="bi bi-pen"></i></button>
                <button type="button" id="enre_<?php echo $row['idVaomiera']; ?>" class="btn btn-success" onclick="saveEdit(<?php echo $row['idVaomiera']; ?>)"style="display:none;" >Enregistrer</button>
                <a href="deleteKonty.php?supprVaomiera=<?php echo $row['idVaomiera']; ?>">
                <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i></button>
                </a>
            </td>
                        </tr>
                        

                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>

                    </table>
                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function editRow(id) {
        // Masquer le texte et afficher le formulaire
        $("#code_" + id).hide();
        $("#lib_" + id).hide();
        $("#mod_" + id).hide();
        $("#code_form_" + id).show();
        $("#lib_form_" + id).show();
        $("#enre_" + id).show();
    }

    function saveEdit(id) {
        // Récupérer les valeurs éditées
        var editedCode = $("form#code_form_" + id + " input[name='editedCode']").val();
        var editedValue = $("form#lib_form_" + id + " input[name='editedValue']").val();

        console.log('ID:', id);
        console.log('Edited Code:', editedCode);
        console.log('Edited Value:', editedValue);

        // Envoyer les données au serveur avec AJAX
        fetch('saveEditVaomiera.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id, editedCode: editedCode, editedValue: editedValue }),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response from server:', data);

            // Mettre à jour l'affichage après avoir reçu la réponse du serveur
            if (data.success) {
                console.log('Mise à jour réussie dans la base de données.');
                $("#code_" + id).html(editedCode);
                $("#lib_" + id).html(editedValue);

                // Afficher à nouveau le texte
                $("#code_" + id).show();
                $("#lib_" + id).show();
                $("#mod_" + id).show();
                // Masquer les formulaires
                $("#code_form_" + id).hide();
                $("#lib_form_" + id).hide();
                $("#enre_" + id).hide();
            } else {
                console.error('Erreur lors de la mise à jour dans la base de données.');
                alert('Erreur lors de la sauvegarde.');
            }
        })
        .catch((error) => {
            console.error('Erreur de fetch :', error);
        });
    }
</script>
            </div>
        </div>
    </div>

    </div>
    
</div>
<?php }  ?>

<?php include 'pannelAmbany.php'; ?> 