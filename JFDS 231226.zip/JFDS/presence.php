<?php
 include './phpqrcode/qrlib.php';
 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
 $daty = date('Y-m-d');

 if (!isset($cat)) {
    header("Location:index.php");
   
}

 if ($cat == 'membre') {
    header("Location:index.php");
   
}


 if (isset($_POST['submitFiche'])) {
    $libActivite = $_POST['libActivite'];
    $libActivite = escape_data($conn, $libActivite);

    $sqlL = "SELECT * FROM proactivite WHERE libActivite= '$libActivite' AND dtePresence IS NOT NULL";
    $resultL = mysqli_query($conn, $sqlL);
    if (mysqli_num_rows($resultL) > 0 ) {
        ?>
                <script>
                    alert('Efa manana fiche de présence io hetsika io!');
                    // window.location.href='index.php';
                </script>
        <?php
    } else {

    // Vérifier si le fichier JSON existe déjà
    $jsonFileName = 'fiche/' . $libActivite . '_' . $daty . '.json';
    if (!file_exists($jsonFileName)) {
        // Créer un tableau de données pour le fichier JSON
        $jsonData = array(
            'date' => $daty,
            'libActivite' => $libActivite,
            'cases' => array()
        );

        // Convertir le tableau en format JSON
        $jsonContent = json_encode($jsonData);

        // Enregistrer le contenu JSON dans un fichier
        file_put_contents($jsonFileName, $jsonContent);

        $query = "UPDATE proactivite SET dtePresence='$daty' WHERE libActivite = '$libActivite'";
        $result1 = $conn->query($query);
        header("Location:presence.php"); 
    }
    else {
        ?>
                <script>
                    alert('Erreur de création de la lsite!');
                </script>
        <?php
    }

    }
}
?>          
<?php include 'pannelAmbony.php'; ?>  
<center>
    <h4 class='text-center' style="background: #4e73df;padding: 7px;color: white;margin-top: -20px;">
        <b>
            Présence<br>
        </b>
    </h4>
</center>
        <div class="container">

            <form method='post'>
                
                <div class="row">

                <div class="col-md-1"></div>

                <div class="col-md-8">
                                <?php 
                                    $sqlActivite = "SELECT * FROM proactivite";
                                    $resultActivite = $conn->query($sqlActivite);

                                    $optionActivite = [];
                                    if ($resultActivite->num_rows > 0) {
                                        while ($rowActivite = $resultActivite->fetch_assoc()) {
                                            $optionActivite[] = $rowActivite;
                                        }
                                    }
                        ?>
                                <div class='form-group'>
                                    <label>Hetsika:</label> 
                                    <select name="libActivite" class="form-control">
                                        <option value="" disabled selected hidden>Hetsika</option>
                                        <?php foreach ($optionActivite as $optionsActivite ) : ?>
                                            <option value="<?php echo $optionsActivite['libActivite']; ?>">
                                                
                                                <?php echo $optionsActivite['libActivite']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" name= "submitFiche" class="btn btn-success" style="margin-top: 32px;">
                        <i class="bi bi-journal-plus"></i> Créer 
                    </button>
                </div>

                <div class="col-md-1"></div>
                <!--  -->
            </div>
            </form>   
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="">
                    <div >
                        <br><br>
                        <h4 class="text-center"><b>Liste de fiche de présence</b></h4>
                        
                    </div>
                    <div class="text-center" style="max-height: 350px;overflow-y: auto;">
                        <table class="table table-bordered" >
    <thead class="alert-success ">
        <tr class="text-center" style="background: navy;color: white;">
            <th>N°</th>
            <th class="text-center">Titre</th>
            <th class="text-center">Date de création</th>
            <?php
            $showActionsHeader = false; // Variable pour indiquer si l'entête "Actions" doit être affiché
            $sqlkonty = "SELECT * FROM proactivite WHERE dtePresence IS NOT NULL ORDER BY dtePresence DESC";
            $resultkonty = mysqli_query($conn, $sqlkonty);

            if ($resultkonty && mysqli_num_rows($resultkonty) > 0) {
            foreach ($resultkonty as $row) {
                $libActivite = $row["libActivite"];
                $dtePresence = $row["dtePresence"];
                $jsonFileName = 'fiche/' . $libActivite . '_' . $dtePresence . '.json';
                // $jsonContents = file_get_contents($jsonFileName);
                $jsonContents = @file_get_contents($jsonFileName) ?? "La fiche est introuvable";
                $data = json_decode($jsonContents, true);
                if (isset($data['cases']) && !empty($data['cases'])) {
                    $showActionsHeader = true; 
                }
            }
            if ($showActionsHeader) {
                echo '<th class="text-center">Actions</th>';
            }
            ?>
        </tr>
    </thead>
    <tbody>
        <?php
        $i = 0;
        foreach ($resultkonty as $row) {
            $i = $i + 1;
            $libActivite = $row["libActivite"];
            $dtePresence = $row["dtePresence"];
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td>
                    <?php
                    require_once('kajyPresence.php');
                    echo '<a href="ajoutPresence.php?id=' . $row['idPro'] . '" style="text-decoration: none;">' . $libActivite . ' (' . $present . '/' . $total . ')</a>';
                    ?>
                </td>
                <td><?php echo $dtePresence; ?></td>
                <?php
                $jsonFileName = 'fiche/' . $libActivite . '_' . $dtePresence . '.json';
                // $jsonContents = file_get_contents($jsonFileName);
                $jsonContents = @file_get_contents($jsonFileName) ?? "La fiche est introuvable";

                $data = json_decode($jsonContents, true);
                if ($showActionsHeader) {
                    // Afficher le bouton PDF uniquement si l'entête "Actions" doit être affiché
                    if (isset($data['cases']) && !empty($data['cases'])) {
                        echo '<td class="text-center">';
                        echo '<a href="fpdf/pdfList.php?id=' . $row['idPro'] . '" style="text-decoration: none;">';
                        echo '<button class="btn btn-secondary">PDF</button>';
                        echo '</a>';
                        echo '</td>';
                    } else {
                        // La colonne 'cases' est vide, ou elle n'existe pas, ne pas afficher le bouton PDF
                        echo '<td class="text-center"></td>';
                    }
                }
                ?>
            </tr>
        <?php
        }
    }
        ?>
    </tbody>
</table>

                    </div>
                    <br><br>
                </div>
            </div>

            <div class="col-md-1"></div>
        </div>
    </div>
    <br><br>
<?php include 'pannelAmbany.php'; ?> 