<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérez les données postées depuis le formulaire
    $libActivite = $_POST['libActivite'];
    $dtePresence = $_POST['dtePresence'];
    $userData = json_decode($_POST['userData'], true); // C'est un objet JSON contenant les données de l'utilisateur
    $userData['date'] = date('Y-m-d H:i:s');
    
    // Construisez le nom du fichier JSON
    $jsonFileName = 'fiche/' . $libActivite . '_' . $dtePresence . '.json';

    // Vérifiez si le fichier JSON existe déjà
    if (file_exists($jsonFileName)) {
        // Chargez le contenu JSON existant
        $data = json_decode(file_get_contents($jsonFileName), true);

        // Vérifiez si le tableau 'cases' existe déjà, sinon créez-le
        if (!isset($data['cases'])) {
            $data['cases'] = [];
        }

        // Vérifiez si le nom d'utilisateur existe déjà
        $userExists = false;
        foreach ($data['cases'] as $existingUser) {
            if ($existingUser['nomUser'] === $userData['nomUser']) {
                $userExists = true;
                break;
            }
        }

        if ($userExists) {
            // Si l'utilisateur existe déjà, renvoyez un message d'erreur
            echo json_encode(['success' => false, 'message' => 'Le compte a déjà été scanné.']);
        } else {
            // Ajoutez les nouvelles données utilisateur au tableau 'cases'
            $data['cases'][] = $userData;

            // Enregistrez les données mises à jour dans le fichier JSON
            file_put_contents($jsonFileName, json_encode($data));

            // Répondez avec un message de succès
            echo json_encode(['success' => true, 'message' => 'Informations ajoutées avec succès dans le fichier JSON.']);
        }
    } else {
        // Si le fichier JSON n'existe pas, renvoyez une erreur
        echo json_encode(['success' => false, 'message' => 'Le fichier JSON n\'existe pas.']);
    }
} else {
    // Si la requête n'est pas une requête POST, renvoyez une erreur
    echo json_encode(['success' => false, 'message' => 'Requête non autorisée.']);
}

?>
