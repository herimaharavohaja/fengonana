<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
 include './phpqrcode/qrlib.php';
// echo $fari;
 if (isset($_POST['enregistrer'])) {
    $codeKonty = $_POST['codeKonty'];
    $sexeUser = $_POST['sexeUser'];
    $sexeUser = mysqli_real_escape_string($conn, $sexeUser);
    $nomUser = $_POST['nomUser'];
    $nomUser = mysqli_real_escape_string($conn, $nomUser);
    $prenomUser = $_POST['prenomUser'];
    $prenomUser = mysqli_real_escape_string($conn, $prenomUser);
    $dteNaissUser = $_POST['dteNaissUser'];
    $apvUser = $_POST['apvUser'];
    $adresyUser = $_POST['adresyUser'];
    $adresyUser = mysqli_real_escape_string($conn, $adresyUser);
    $nomImagesaryUser = $_FILES["saryUser"]["name"];
    $imageTmpsaryUser = $_FILES["saryUser"]["tmp_name"];
    $toerana = 'masina';
    $cheminDossierMembre = "uploads/" . $toerana;
    // Vérifier si le dossier du membre existe
    if (!file_exists($cheminDossierMembre)) {
        // Si le dossier n'existe pas, le créer avec les permissions 0755
        mkdir($cheminDossierMembre, 0755, true);
    }

    // Construire le chemin complet de l'image
    $cheminImagesaryUser = $cheminDossierMembre . "/" . $nomImagesaryUser;
    move_uploaded_file($imageTmpsaryUser, $cheminImagesaryUser);

    $hashKonty = base64_encode($codeKonty);
    $libPseudo = $_POST['libPseudo'];
    $libPseudo = mysqli_real_escape_string($conn, $libPseudo);
    $libPass = $_POST['libPass'];
    $libPass = mysqli_real_escape_string($conn, $libPass);
    $libCategorie = 'User';
    $idMasina = $_POST['idMasina'];
    $dateDuJour = date("Y-m-d");

            // Si la valeur n'existe pas, faire quelque chose d'autre ici
            $query  = "INSERT INTO konty (libPseudo, libPass, libCategorie, idMasina, codeKonty, hashKonty, dteCrea
                ,saryKonty, sexeKonty, nomKonty, prenomKonty, dteNaissKonty, apvKonty, adresyKonty) 
                VALUES ('$libPseudo', '$libPass','$libCategorie', '$idMasina', '$codeKonty', '$hashKonty', '$dateDuJour', '$nomImagesaryUser','$sexeUser', '$nomUser', '$prenomUser', '$dteNaissUser', '$apvUser', '$adresyUser')";
            // $result = $conn->query($query);
            // header("Location: compteMasina.php");

                if ($conn->query($query) === TRUE) {
            // Générez le QR code
            $cheminDossierQr = "./qrcodes/" . $toerana;
            if (!file_exists($cheminDossierQr)) {
                // Si le dossier n'existe pas, le créer avec les permissions 0755
                mkdir($cheminDossierQr, 0755, true);
            }
            QRcode::png($hashKonty, $cheminDossierQr . '/' . $nomUser . ' ' . $prenomUser . '.png');
            ?>
                <script>
                    window.location.href='compteMasina.php';
                </script>
            <?php

        } else {
            header('Location: compteMasina.php');
        }

      }
      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte.php'; ?>   
<br>
    <div class="container">
    <div class="row">
    <div class="col-md-4">
        <div class="card shadow ">
            
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Fikambanana Masina</h6>
            </div>
            <div class="card-body" style='max-height: 400px; overflow-y: auto;'>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div style="display: flex; align-items: center;">
                        <label class="form-label" >Fikambanana Masina</label>
                        <?php 
		                           	$sqlMasina = "SELECT * FROM masina";
									$resultMasina = $conn->query($sqlMasina);

									$optionMasina = [];
									if ($resultMasina->num_rows > 0) {
										while ($rowMasina = $resultMasina->fetch_assoc()) {
											$optionMasina[] = $rowMasina;
										}
									}
						?>
                        <div class="form-outline mb-4">
                            <select name="idMasina" required class="form-control">
		                            	<option value="" disabled selected hidden>Fikambanana masina</option>
		                            	<?php foreach ($optionMasina as $optionMasina ) : ?>
		                            		<option value="<?php echo $optionMasina['idMasina']; ?>">
		                            			
		                            			<?php echo $optionMasina['libMasina']; ?>
		                            		</option>
		                            	<?php endforeach; ?>
		                            </select>
                        </div>
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                            <input type="text"  name="codeKonty" class="form-control" placeholder="Code" required />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Pseudo</label> -->
                        <input type="text"  name="libPseudo" class="form-control" required placeholder="Pseudo" />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Mot de passe</label> -->
                        <input type="password" id="form1Example2" name="libPass"  class="form-control" required placeholder="Mot de passe" />
                    </div>

                    <!-- fanampiny info -->
                    <div style="display: flex; align-items: center;" class="mb-2">
                        <label style="margin-top: 10px;">Sary:</label> 
                        <input type="file" class="form-control" style="border:none; background: none;" 
                        name="saryUser" required placeholder="Sary" />
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Sexe:</label>  -->
                        <select name="sexeUser" required class="form-control" >
                            <option value="" disabled selected hidden>Sexe</option>
                            <option value="Masculin">Masculin</option>
                            <option value="Féminin">Féminin</option>
                        </select>
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Nom:</label>  -->
                        <input class='form-control' required type='text' name='nomUser' placeholder="Nom">
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Prénom(s):</label>  -->
                        <input class='form-control' type='text' name='prenomUser' placeholder="Prénom(s)">
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Date naissance:</label> -->
                        <input type="date" name="dteNaissUser" class="form-control" placeholder="Date naissance" required>
                    </div>

                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="">APV:</label>  -->
                        <input class='form-control' required type='text' name='apvUser' placeholder="APV">
                    </div>
                    <div style="display: flex; align-items: center;" class="mb-2">
                        <!-- <label style="margin-top: 10px;">Adresse actuelle:</label>  -->
                        <input class='form-control' required type='text' name='adresyUser' placeholder="Adresse actuelle">
                    </div>


                    <div>

                        <input type="submit" class="btn btn-info" name="enregistrer" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Lisitry ny Fikambanana Masina</h6>
                
            </div>
            <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                <form>
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>Code</th>
                              <th>Pseudo</th>
                              <th>Mot de Passe</th>
                              <th>Fikambanana Masina</th>
                              <th colspan="2" >Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                
                                        

                                        $query = "SELECT konty.*, masina.*, masina.libMasina AS log FROM konty 
                                                    INNER JOIN masina  ON masina.idMasina= konty.idMasina
                                                    WHERE libCategorie = 'User' 
                                                    ORDER BY idKonty ASC";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($rowK = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  

            <tr>
                          
            <td>
                <span id="codeK_<?php echo $rowK['idKonty']; ?>">
                    <?php echo $rowK['codeKonty'] ?>
                </span>
                <form id="code_formK1_<?php echo $rowK['idKonty']; ?>" style="display:none;">
                    <input type="text" name="editedCodeK" class="form-control" value="<?php echo $rowK['codeKonty']; ?>">
                </form>
            </td>
            <!-- <td><?php echo $rowK['libPseudo']?></td> -->
            <td>
                <span id="libK_<?php echo $rowK['idKonty']; ?>">
                    <?php echo $rowK['libPseudo']?>
                </span>
                <form id="lib_formK_<?php echo $rowK['idKonty']; ?>" style="display:none;">
                    <input type="text" name="editedValueK" class="form-control" value="<?php echo $rowK['libPseudo']; ?>">
                </form>
            </td>
            <!-- <td><?php echo $rowK['libPass']?></td> -->
            <td>
                <span id="passK_<?php echo $rowK['idKonty']; ?>">
                    <?php echo $rowK['libPass']?>
                </span>
                <form id="pass_formK_<?php echo $rowK['idKonty']; ?>" style="display:none;">
                    <input type="text" name="passValueK" class="form-control" value="<?php echo $rowK['libPass']; ?>">
                </form>
            </td>

            <td><?php echo $rowK['log']?></td> 
            <td style="text-align: right;display: flex; align-items: center;">
                <button type="button" id="modK_<?php echo $rowK['idKonty']; ?>" class="btn btn-primary" onclick="editRowK(<?php echo $rowK['idKonty']; ?>)"><i class="bi bi-pen"></i></button>
                <button type="button" id="enreK_<?php echo $rowK['idKonty']; ?>" class="btn btn-success" onclick="saveEditK(<?php echo $rowK['idKonty']; ?>)" style="display:none;" >Enregistrer</button>
                &nbsp;&nbsp;
                <a href="deleteKonty.php?gerMasina=<?php echo $rowK['idKonty']; ?>">
                <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i></button>
                </a>
            </td>
            </tr>
                        

                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>
                    </table>       
                <script>
                    function editRowK(id) {
                        // Masquer le texte et afficher le formulaire
                        $("#codeK_" + id).hide();
                        $("#libK_" + id).hide();
                        $("#passK_" + id).hide();

                        $("#modK_" + id).hide();

                        $("#code_formK1_" + id).show();
                        $("#lib_formK_" + id).show();
                        $("#pass_formK_" + id).show();

                        $("#enreK_" + id).show();
                    }

                    function saveEditK(id) {
                        // Récupérer les valeurs éditées
                        var editedCode = $("#code_formK1_" + id + " input[name='editedCodeK']").val();
                        var editedValue = $("#lib_formK_" + id + " input[name='editedValueK']").val();
                        var passValue = $("#pass_formK_" + id + " input[name='passValueK']").val();

                        console.log('ID:', id);
                        console.log('Edited Code:', editedCode);
                        console.log('Edited lib:', editedValue);
                        console.log('Edited pass:', passValue);

                        // Envoyer les données au serveur avec AJAX
                        fetch('saveEditKonty.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ id: id, editedCode: editedCode, editedValue: editedValue, passValue: passValue }),
                        })
                        .then(response => response.json())
                        .then(data => {
                            console.log('Response from server:', data);

                            // Mettre à jour l'affichage après avoir reçu la réponse du serveur
                            if (data.success) {
                                console.log('Mise à jour réussie dans la base de données.');
                                $("#codeK_" + id).html(editedCode);
                                $("#libK_" + id).html(editedValue);
                                $("#passK_" + id).html(passValue);

                                // Afficher à nouveau le texte
                                $("#codeK_" + id).show();
                                $("#libK_" + id).show();
                                $("#passK_" + id).show();
                                $("#modK_" + id).show();
                                // Masquer les formulaires
                                $("#code_formK1_" + id).hide();
                                $("#lib_formK_" + id).hide();
                                $("#pass_formK_" + id).hide();
                                $("#enreK_" + id).hide();
                            } else {
                                console.error('Erreur lors de la mise à jour dans la base de données.');
                                alert('Erreur lors de la sauvegarde.');
                            }
                        })
                        .catch((error) => {
                            console.error('Erreur de fetch :', error);
                        });
                    }
</script>

            </div>
        </div>
    </div>

    </div>
</div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 