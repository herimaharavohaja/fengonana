<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $sql = "SELECT *
      FROM konty
      WHERE idKonty = $ida";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  // $id = $row['id'];
  $codeKonty1 = $row['codeKonty'];
  $libPseudo1 = $row['libPseudo'];
  $libPass1 = $row['libPass'];
  }


  if (isset($_POST['modif'])) {
  $codeKonty = $conn->real_escape_string($_POST['codeKonty']);
  $libPseudo = $conn->real_escape_string($_POST['libPseudo']);
  $libPass = $conn->real_escape_string(($_POST['libPass']));
  $hashKonty = base64_encode($codeKonty);

    $query = "UPDATE konty SET codeKonty='$codeKonty', libPseudo='$libPseudo', libPass='$libPass', hashKonty = '$hashKonty' WHERE idKonty=$ida";
    $result1 = $conn->query($query);
     header("Location:creaFaritra.php");
  }else{
  }


 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Modification du compte</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Code</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="codeKonty" value="<?php echo $codeKonty1; ?>" class="form-control"  />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Pseudo</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libPseudo" value="<?php echo $libPseudo1; ?>" class="form-control"  />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Mot de passe</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example2" name="libPass" value="<?php echo $libPass1; ?>"  class="form-control"  />
                        </div>
                     </div>


                    <div class="mb-3">

                        <input type="submit" class="btn btn-info" name="modif" value="Modifier"  />
                    </div>
                </form>
                                </div>
                            </div>
    </div>
    <div class="col-md-4"></div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 