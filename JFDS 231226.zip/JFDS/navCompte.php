<style>
    .collapsible-container {
      display: flex;
      justify-content: space-between;
      margin-top: -24px;
    }

    .collapsible {
      background-color: #777;
      color: white;
      cursor: pointer;
      padding: 18px;
      flex-grow: 1;
      border: none;
      text-align: center;
      outline: none;
      font-size: 15px;
      transition: background-color 0.3s;
    }
    .collapsible:hover {
      background-color: skyblue; /* Changement de couleur au survol de la souris */
    }

    .collapsible.active {
      background-color: #555; 
    }

    .content {
      padding: 0 18px;
      display: none;
      overflow: hidden;
      background-color: #f1f1f1;
      width: 100%;
    }

    .noButton {
        border: none;
        background: none;
        padding: 0;
        margin: 0;
        font-size: inherit;
        color: white;
    }
  </style>

<div class="collapsible-container">
    <?php if ($cat == 'superAdmin') : ?>
        <a href="compteAdmin.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'compteAdmin.php') ? 'active' : ''; ?>">
            <button class="noButton">Administrateur</button>
        </a>

        </a>
    <?php endif; ?>

    <a href="compteFaritra.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'compteFaritra.php') ? 'active' : ''; ?>"><button class="noButton">Filohan’ny Faritra</button></a>
    <a href="compteMasina.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'compteMasina.php') ? 'active' : ''; ?>"><button class="noButton">Filohan’ny Fikambanana Masina</button></a>
    <a href="compteVaomiera.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'compteVaomiera.php') ? 'active' : ''; ?>"><button class="noButton">Filohan’ny Vaomieran'asa</button></a>
</div>