<?php
      error_reporting(E_ALL);
ini_set('display_errors', 1);

 include 'connect.php';
 include('db_function.php');  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $idKonty = $_SESSION['idKonty'];

if (isset($_POST['enregistrer'])) {
    $libActivite = $_POST['libActivite'];
    $libActivite = escape_data($conn, $libActivite);
    $debutActivite = $_POST['debutActivite'];
    // $finActivite = $_POST['finActivite'];
    $finActivite = isset($_POST['finActivite']) ? $_POST['finActivite'] : null;
    $descActivite = $_POST['descActivite'];
    $descActivite = escape_data($conn, $descActivite);
    $placeActivite = $_POST['placeActivite'];
    $placeActivite = escape_data($conn, $placeActivite);

    $elements = isset($_POST['elements']) ? $_POST['elements'] : [];

// Filtrer les valeurs pour supprimer 'on' et 'tout'
$elements = array_filter($elements, function ($value) {
    return $value !== 'on' && $value !== 'tout';
});
$elementsCoches = $elements;
    // $elementsCoches = $_POST['elements'];

    $elementsCochesString = implode(',', $elementsCoches);
    $elementsCochesString = $conn->real_escape_string($elementsCochesString);

            if ($cat != 'superAdmin') {
              $queryUser  = "SELECT *
                          FROM proactivite
                          WHERE idKonty = '1' AND '$debutActivite' BETWEEN debutActivite AND finActivite";
                $resultUser = $conn->query($queryUser);
                if ($resultUser->num_rows == 0) {
                  // Si la valeur n'existe pas, faire quelque chose d'autre ici
                  $query  = "INSERT INTO proactivite (libActivite, debutActivite, finActivite, descActivite, placeActivite, idKonty) VALUES ('$libActivite', '$debutActivite','$debutActivite', '$descActivite', '$placeActivite', '$idKonty')";
                  $result = $conn->query($query);

                  // Insérer les éléments cochés dans une colonne de la table proActivite
                  $queryM = "UPDATE proactivite SET role = '$elementsCochesString' WHERE idPro = LAST_INSERT_ID()"; 
                  $resultM =$conn->query($queryM);

                  header("Location: creaActivite.php");
                }
                else {
                  ?>
                    <script>
                          alert('Date réservée!');
                          window.location.href='creaActivite.php';
                          </script>
                  <?php
                }
            } else {
              // Si la valeur n'existe pas, faire quelque chose d'autre ici
              $query  = "INSERT INTO proactivite (libActivite, debutActivite, finActivite, descActivite, placeActivite, idKonty) VALUES ('$libActivite', '$debutActivite','$finActivite', '$descActivite', '$placeActivite', '$idKonty')";
              $result = $conn->query($query);

              // Insérer les éléments cochés dans une colonne de la table proActivite
                  $queryM = "UPDATE proactivite SET role = '$elementsCochesString' WHERE idPro = LAST_INSERT_ID()"; 
                  $resultM =$conn->query($queryM);
                  
              header("Location: creaActivite.php");
            }
      
      }
 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <div class="row">
    <div class="col-md-3">
        
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Famoronana hetsika hatao</h6>
            </div>
            <div class="card-body" style="max-height: 450px;overflow-y: auto;">
                <form action="" method="POST">
                	<div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Activité</label>

                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libActivite" class="form-control" required />
                        </div>
                    </div>
                    <div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Toerana</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="placeActivite" class="form-control" required />
                        </div>
                    </div>
                    <?php 
                      if ($cat != 'superAdmin') {
                    ?>
                        <div style="margin-top: -10px;">
                            <label class="form-label" for="form1Example1">Date</label>
                            <div class="form-outline mb-4">
                                <input type="date" id="form1Example1" name="debutActivite" class="form-control" required />
                            </div>
                        </div>

                    <?php
                      } else{
                        ?>
                        <div style="display: flex;">
                          <div style="margin-top: -10px;">
                            <label class="form-label" for="form1Example1">Date</label>
                            <div class="form-outline mb-4">
                                <input type="date" id="form1Example1" name="debutActivite" class="form-control" style="width: 100px;margin-right: 5px;" required />
                            </div>

                          </div>
                        <div style="margin-top: -10px;">
                            <label class="form-label" for="form1Example1">Au</label>
                            <div class="form-outline mb-4">
                                <input type="date" id="form1Example1" name="finActivite" class="form-control" required style="width: 100px;"/>
                            </div>
                        </div>
                      </div>
                    <?php
                      }
                    ?>
                    

                    <div style="margin-top: -10px;">
                        <label class="form-label" for="form1Example1">Déscription</label>
                        <div class="form-outline mb-4">
                            <textarea name="descActivite" class="form-control" required placeholder="Ecrivez une description comme conditions ou thème approprié ..."></textarea>
                        </div>
                    </div>

                    <?php 
                      if ($cat == 'superAdmin') {
                          ?>
                          <div class="tk">
                              <style>
                                  .checkbox-container {
                                      margin-bottom: 10px;
                                  }

                                  #checkAll {
                                      margin-right: 5px;
                                  }

                                  .btn {
                                      background-color: #28a745;
                                      color: #fff;
                                      padding: 5px 10px;
                                      border: none;
                                      cursor: pointer;
                                  }

                                  .btn:hover {
                                      background-color: #218838;
                                  }
                              </style>
                              <div class="checkbox-container">
                                  <input type='checkbox' id='checkAll' name='elements[]'> Tout &nbsp;
                                  <input type='checkbox' id='checkAll1' name='elements[]'> Filan-kevitra
                                  <hr>
                              </div>
                              <div class="checkbox-container">
                                  <?php 
                                  $queryK = "SELECT * FROM konty WHERE libCategorie != 'superAdmin'";
                                  $resultK = $conn->query($queryK);

                                  while ($rowK = $resultK->fetch_assoc()) {
                                      $class = ($rowK['libCategorie'] == 'User') ? 'user-checkbox' : '';
                                      echo "<input type='checkbox' class='$class' name='elements[]' value='" . $rowK['idKonty'] . "'> " . $rowK['libPseudo'] . "<br>";
                                  }
                                  ?>
                              </div>
                          </div>
                          <?php
                      }
                      ?>

                    <div style="margin-top: -10px;">

                        <input type="submit" class="btn btn-success" name="enregistrer" value="Créer"  />
                    </div>
                </form>
                <script>
                  var checkAll = document.getElementById('checkAll');
                  var checkAll1 = document.getElementById('checkAll1');
                  var checkboxes = document.getElementsByName('elements[]');
                  var userCheckboxes = document.getElementsByClassName('user-checkbox');

                  // Fonction pour cocher ou décocher tous les éléments
                  checkAll.addEventListener('change', function () {
                      for (var i = 0; i < checkboxes.length; i++) {
                          checkboxes[i].checked = this.checked;
                      }
                      updateCheckAll1State();
                  });

                  // Fonction pour cocher ou décocher sélectivement les éléments avec libCategorie = 'User'
                  checkAll1.addEventListener('change', function () {
                      for (var i = 0; i < userCheckboxes.length; i++) {
                          userCheckboxes[i].checked = this.checked;
                      }
                      updateCheckAllState();
                  });

                  // Fonction pour gérer la dé-sélection individuelle
                  for (var i = 0; i < checkboxes.length; i++) {
                      checkboxes[i].addEventListener('change', function () {
                          updateCheckAllState();
                          updateCheckAll1State();
                      });
                  }

                  // Fonction pour mettre à jour l'état de la case "Tout"
                  function updateCheckAllState() {
                      checkAll.checked = Array.from(checkboxes).every(function (checkbox) {
                          return checkbox.checked;
                      });
                  }

                  // Fonction pour mettre à jour l'état de la case "Filan-kevitra"
                  function updateCheckAll1State() {
                      checkAll1.checked = Array.from(userCheckboxes).every(function (checkbox) {
                          return checkbox.checked;
                      });
                  }
              </script>



            </div>

        </div>
        <br><br>
    </div> 

    <div class="col-md-9">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Hetsika ho avy</h6>
                
            </div>
            <div class="card-body" style="max-height: 400px;overflow-y: auto;">
                <form>
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>Début</th>
                              <th>Fin</th>
                              <th>Titre</th>
                              <th>Toerana</th>
                              <th>Déscription</th>
                              <th>Responsable</th>
                              <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 

                                        $query = "SELECT * FROM proactivite p LEFT JOIN konty k ON k.idKonty = p.idKonty ORDER BY idPro ASC";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  

                        <tr>
                              <td>
                                  <?php 
                                    // echo $row['debutActivite'];
                                  ?>
                                  <span id="debut_<?php echo $row['idPro']; ?>">
                                      <?php echo $row['debutActivite'] ?>
                                  </span>
                                  <form id="debut_form_<?php echo $row['idPro']; ?>" style="display:none;">
                                      <input type="date" name="editedDebut" class="form-control" value="<?php echo $row['debutActivite']; ?>">
                                  </form>
                              </td>
                              <td>
                                  <?php 
                                    // echo $row['finActivite']
                                  ?>
                                  <span id="fin_<?php echo $row['idPro']; ?>">
                                      <?php echo $row['finActivite']?>
                                  </span>
                                  <form id="fin_form_<?php echo $row['idPro']; ?>" style="display:none;">
                                      <input type="date" name="editedFin" class="form-control" value="<?php echo $row['finActivite']; ?>">
                                  </form>
                              </td>
                              <td>
                                  <?php 
                                    // echo $row['libActivite']
                                  ?>
                                  <span id="lib_<?php echo $row['idPro']; ?>">
                                      <?php echo $row['libActivite']?>
                                  </span>
                                  <form id="lib_form_<?php echo $row['idPro']; ?>" style="display:none;">
                                      <input type="text" name="editedValue" class="form-control" value="<?php echo $row['libActivite']; ?>">
                                  </form>
                              </td>
                              <td>
                                  <?php 
                                    // echo $row['placeActivite']
                                  ?>
                                  <span id="place_<?php echo $row['idPro']; ?>">
                                      <?php echo $row['placeActivite']?>
                                  </span>
                                  <form id="place_form_<?php echo $row['idPro']; ?>" style="display:none;">
                                      <input type="text" name="editedPlace" class="form-control" value="<?php echo $row['placeActivite']; ?>">
                                  </form>
                              </td>
                              <td>
                                  <?php 
                                    // echo $row['descActivite']
                                  ?>
                                  <span id="desc_<?php echo $row['idPro']; ?>">
                                      <?php echo $row['descActivite']?>
                                  </span>
                                  <form id="desc_form_<?php echo $row['idPro']; ?>" style="display:none;">
                                      <input type="text" name="editedDesc" class="form-control" value="<?php echo $row['descActivite']; ?>">
                                  </form>
                              </td>
                              <td>
                                <?php 
                                  if ($row['libCategorie'] == 'superAdmin' || $row['libCategorie'] == 'Admin'){
                                    echo "Administrateur";
                                  } elseif ($row['idFaritra'] != '0') {
                                    echo "Faritra";
                                  } elseif ($row['idMasina'] != '0') {
                                    echo "Fikambanana Masina";
                                  } elseif ($row['idVaomiera'] != '0') {
                                    echo "Vaomieran'asa";
                                  }

                                ?>  
                              </td>
                                <?php 
                                  if ($row['etatActivite'] == '0' AND ($cat == 'Admin' OR $cat == 'superAdmin')) {
                                ?>    

                                <?php 
                                  }
                                  elseif ($row['etatActivite'] == '0') {
                                ?>    

                                <?php 
                                  }
                                  if ($row['etatActivite'] == '1') {
                                ?>   

                                
                                <?php 
                                  }
                                ?>
                              <td style="text-align: right;">
                                <?php if ($cat == "superAdmin" ) { ?>
                                  <button type="button" id="mod_<?php echo $row['idPro']; ?>" class="btn btn-primary" onclick="editRow(<?php echo $row['idPro']; ?>)">
                                    <i class="bi bi-pen"></i>
                                  </button>

                                <?php } ?>
                                
                                <button type="button" id="enre_<?php echo $row['idPro']; ?>" class="btn btn-success" onclick="saveEdit(<?php echo $row['idPro']; ?>)"style="display:none;" >
                                  Enregistrer
                                </button>

                                <a href="deleteKonty.php?supprPro=<?php echo $row['idPro']; ?>">
                                  <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')">
                                    <i class="bi bi-trash"></i> 
                                  </button>
                                </a>
                              </td>
                          
                        </tr>
                        

                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>

                    </table>       
                </form>
                
            </div>
        </div>
    </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function editRow(id) {
        // Masquer le texte et afficher le formulaire
        $("#debut_" + id).hide();
        $("#fin_" + id).hide();
        $("#lib_" + id).hide();
        $("#place_" + id).hide();
        $("#desc_" + id).hide();
        $("#mod_" + id).hide();
        $("#debut_form_" + id).show();
        $("#fin_form_" + id).show();
        $("#lib_form_" + id).show();
        $("#place_form_" + id).show();
        $("#desc_form_" + id).show();
        $("#enre_" + id).show();
    }

    function saveEdit(id) {
        // Récupérer les valeurs éditées
        var editedDebut = $("form#debut_form_" + id + " input[name='editedDebut']").val();
        var editedFin = $("form#fin_form_" + id + " input[name='editedFin']").val();
        var editedValue = $("form#lib_form_" + id + " input[name='editedValue']").val();
        var editedPlace = $("form#place_form_" + id + " input[name='editedPlace']").val();
        var editedDesc = $("form#desc_form_" + id + " input[name='editedDesc']").val();

        console.log('ID:', id);
        console.log('Edited Code:', editedDebut);
        console.log('Edited Value:', editedValue);

        // Envoyer les données au serveur avec AJAX
        fetch('saveEditActivite.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id, editedDebut: editedDebut, editedFin: editedFin, editedValue: editedValue, editedPlace: editedPlace, editedDesc: editedDesc }),
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response from server:', data);

            // Mettre à jour l'affichage après avoir reçu la réponse du serveur
            if (data.success) {
                console.log('Mise à jour réussie dans la base de données.');
                $("#debut_" + id).html(editedDebut);
                $("#fin_" + id).html(editedFin);
                $("#lib_" + id).html(editedValue);
                $("#place_" + id).html(editedPlace);
                $("#desc_" + id).html(editedDesc);

                // Afficher à nouveau le texte
                $("#debut_" + id).show();
                $("#fin_" + id).show();
                $("#lib_" + id).show();
                $("#place_" + id).show();
                $("#desc_" + id).show();
                $("#mod_" + id).show();
                // Masquer les formulaires
                $("#debut_form_" + id).hide();
                $("#fin_form_" + id).hide();
                $("#lib_form_" + id).hide();
                $("#place_form_" + id).hide();
                $("#desc_form_" + id).hide();
                $("#enre_" + id).hide();
            } else {
                console.error('Erreur lors de la mise à jour dans la base de données.');
                alert('Erreur lors de la mise à jour dans la base de données..');
            }
        })
        .catch((error) => {
            console.error('Erreur de fetch :', error);
        });
    }
</script>

<br><br>
<?php include 'pannelAmbany.php'; ?> 