<?php
$lib = $_SESSION['libCategorie'];
$pseu = $_SESSION['libPseudo'];
// echo $pseu;
echo "<h6 style='margin: 10px;'>Equipes</h6>";

if ($lib == 'membre') {
    echo "<br><br><p style='text-align: center;'>Aucun équipe!</p>";
} elseif ($lib == 'superAdmin' || $lib == 'admin') {
    $sql1 = "SELECT user.*, faritra.*, masina.*, vaomiera.*, sakramenta.*, andraikitra.*, 
                    faritra.libFaritra AS faritra,
                    user.lieuSakramenta AS lieu,  
                    user.saryUser AS sary,
                    masina.libMasina AS masina,
                    vaomiera.libVaomiera AS vaomiera,
                    andraikitra.libAndraikitra AS andraikitra
                    FROM user 
                    LEFT  JOIN faritra ON faritra.idFaritra = user.idFaritra
                    LEFT  JOIN masina ON masina.idMasina = user.idMasina
                    LEFT  JOIN vaomiera ON vaomiera.idVaomiera = user.idVaomiera
                    LEFT  JOIN sakramenta ON sakramenta.idSakramenta = user.idSakramenta
                    LEFT  JOIN andraikitra ON andraikitra.idAndraikitra = user.idAndraikitra";

    $sql2 = "SELECT konty.*,
                faritra.libFaritra AS faritra, 
                konty.saryKonty AS sary,
                masina.libMasina AS masina,
                vaomiera.libVaomiera AS vaomiera
                FROM konty 
                LEFT  JOIN faritra ON faritra.idFaritra = konty.idFaritra
                LEFT  JOIN masina ON masina.idMasina = konty.idMasina
                LEFT  JOIN vaomiera ON vaomiera.idVaomiera = konty.idVaomiera
                LEFT  JOIN sakramenta ON sakramenta.idSakramenta = konty.idSakramenta
                WHERE libCategorie = 'User'";

    $resultat1 = mysqli_query($conn, $sql1);
    $resultat2 = mysqli_query($conn, $sql2);

    // Vérification s'il y a des activités aujourd'hui
    if (mysqli_num_rows($resultat1) > 0 || mysqli_num_rows($resultat2) > 0) {
        echo "<div style='max-height: 200px; overflow-y: auto;'><table class='table'>";

        // Affichage des résultats de la deuxième requête
        while ($ligne2 = mysqli_fetch_assoc($resultat2)) {
            echo "<tr class='user-row' data-toggle='modal' data-target='#exampleModal'
                    data-nom='" . $ligne2['nomKonty'] . "'
                    data-faritra='" . $ligne2['faritra'] . "'
                    data-libMasina='" . $ligne2['masina'] . "'
                    data-sary='" . $ligne2['sary'] . "'
                    data-vaomiera='" . $ligne2['vaomiera'] . "'
                    
                    data-prenom='" . $ligne2['prenomKonty'] . "'
                    data-sexe='" . $ligne2['sexeKonty'] . "'
                    data-apv='" . $ligne2['apvKonty'] . "'
                    data-adresy='" . $ligne2['adresyKonty'] . "'>
                        <td>";
            $nomImage = $ligne2['saryKonty'];
            $cheminImage = "uploads/faritra/" . $nomImage;
            $cheminImage1 = "uploads/gerant/" . $nomImage;
            $cheminImage2 = "uploads/masina/" . $nomImage;
            $cheminImage3 = "uploads/vaomiera/" . $nomImage;

            if (file_exists($cheminImage)) {
                echo "<img style='border-radius: 20%;' src='" . $cheminImage . "' class='img-fluid' width='50' height='50' >";
            } elseif (file_exists($cheminImage1)) {
                echo "<img style='border-radius: 20%;' src='" . $cheminImage1 . "' class='img-fluid' width='50' height='50' >";
            } elseif (file_exists($cheminImage2)) {
                echo "<img style='border-radius: 20%;' src='" . $cheminImage2 . "' class='img-fluid' width='50' height='50' >";
            } elseif (file_exists($cheminImage3)) {
                echo "<img style='border-radius: 20%;' src='" . $cheminImage3 . "' class='img-fluid' width='50' height='50' >";
            }

            echo "
                        </td>
                        <td>" . $ligne2['libPseudo'] . "</td>
                  </tr>";
        }

       
        // Affichage des résultats de la première requête
        while ($ligne1 = mysqli_fetch_assoc($resultat1)) {
            echo "<tr class='user-row' data-toggle='modal' data-target='#exampleModal' 
                    data-nom='" . $ligne1['nomUser'] . "'
                    data-prenom='" . $ligne1['prenomUser'] . "'
                    data-faritra='" . $ligne1['faritra'] . "'
                    data-lieu='" . $ligne1['lieu'] . "'
                    data-sexe='" . $ligne1['sexeUser'] . "'
                    data-libMasina='" . $ligne1['masina'] . "'
                    data-sary='" . $ligne1['sary'] . "'
                    data-vaomiera='" . $ligne1['vaomiera'] . "'
                    data-apv='" . $ligne1['apvUser'] . "'
                    data-adresy='" . $ligne1['adresyUser'] . "'
                    data-andraikitra='" . $ligne1['andraikitra'] . "'>

                        <td><img style='border-radius: 40px;' src='uploads/membres" . $ligne1['saryUser'] . "' class='img-fluid' width='40' height='40' ></td>
                        <td >" . $ligne1['nomUser'] . " " . $ligne1['prenomUser'] . "</td>
                    </tr>";
        }

        echo "</table></div>";
    } else {
        echo "<br><br><p style='text-align: center;'>Aucun équipe.</p>";
    }
} elseif ($lib == 'User') {
    $sql31 = "SELECT * FROM konty WHERE libPseudo = '$pseu'";

    $resultat31 = mysqli_query($conn, $sql31);
    $row31 = mysqli_fetch_assoc($resultat31);
    $ma= $row31["idMasina"];
    $vao= $row31["idVaomiera"];
    $fa= $row31["idFaritra"];

    $sql3 = "SELECT user.*, faritra.*, masina.*, vaomiera.*, sakramenta.*, andraikitra.*, 
                    faritra.libFaritra AS faritra,
                    user.lieuSakramenta AS lieu,  
                    user.saryUser AS sary,
                    masina.libMasina AS masina,
                    vaomiera.libVaomiera AS vaomiera,
                    andraikitra.libAndraikitra AS andraikitra
                    FROM user 
                    LEFT  JOIN faritra ON faritra.idFaritra = user.idFaritra
                    LEFT  JOIN masina ON masina.idMasina = user.idMasina
                    LEFT  JOIN vaomiera ON vaomiera.idVaomiera = user.idVaomiera
                    LEFT  JOIN sakramenta ON sakramenta.idSakramenta = user.idSakramenta
                    LEFT  JOIN andraikitra ON andraikitra.idAndraikitra = user.idAndraikitra
                    WHERE user.idFaritra = '$fa'  OR user.idMasina = '$ma' OR user.idVaomiera = '$vao'
                    -- group by user.idMasina or user.idMasina or user.idFaritra
                    ";
    $resultat3 = mysqli_query($conn, $sql3);

    if (mysqli_num_rows($resultat3) > 0 || mysqli_num_rows($resultat3) > 0) {
        echo "<div style='max-height: 200px; overflow-y: auto;'><table class='table'>";

        // Affichage des résultats de la deuxième requête
        while ($ligne3 = mysqli_fetch_assoc($resultat3)) {
            echo "<tr class='user-row' data-toggle='modal' data-target='#exampleModal'
                    data-nom='" . $ligne3['nomUser'] . "'
                    data-prenom='" . $ligne3['prenomUser'] . "'
                    data-faritra='" . $ligne3['faritra'] . "'
                    data-lieu='" . $ligne3['lieu'] . "'
                    data-sexe='" . $ligne3['sexeUser'] . "'
                    data-libMasina='" . $ligne3['masina'] . "'
                    data-sary='" . $ligne3['sary'] . "'
                    data-vaomiera='" . $ligne3['vaomiera'] . "'
                    data-apv='" . $ligne3['apvUser'] . "'
                    data-adresy='" . $ligne3['adresyUser'] . "'
                    data-andraikitra='" . $ligne3['andraikitra'] . "'>

                        <td><img style='border-radius: 40px;' src='uploads/" . $ligne3['faritra'] . "/" . $ligne3['saryUser'] . "' class='img-fluid' width='40' height='40' ></td>
                        <td>" . $ligne3['nomUser'] . " " . $ligne3['prenomUser'] . "</td>
                  </tr>";
        }

        echo "</table></div>";
    } else {
        echo "<br><br><p style='text-align: center;'>Aucun équipe.</p>";
    }
}
?>
<!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  
                    <!-- <div class="text-center"> 
                        <img  id="user-photo" class="img-fluid" width="80" height="80">
                    </div> -->
                    <p id="user-details">
                        <ul>
                            <li><strong>Nom : </strong><span id="user-nom"></span></li>
                            <li><strong>Prénom : </strong><span id="user-prenom"></span></li>
                            <li><strong>Sexe : </strong><span id="user-sexe"></span></li>
                            <li><strong>Adresse : </strong><span id="user-adresse"></span></li>
                            <li><strong>Faritra : </strong><span id="user-faritra"></span></li>
                            <li><strong>Fikambanana Masina : </strong><span id="user-libMasina"></span></li>
                            <li><strong>Vaomiera ny asa: </strong><span id="user-vaomiera"></span></li>
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>

            <script>
    $(document).ready(function() {
        $('.user-row').click(function() {
            $('#user-nom').text($(this).data('nom'));
            
            var prenomValue = $(this).data('prenom');
            if (prenomValue !== null && prenomValue !== undefined) {
                $('#user-prenom').text(prenomValue);
            } else {
                $('#user-prenom').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== null && sexeValue !== undefined) {
                $('#user-sexe').text(sexeValue);
            } else {
                $('#user-sexe').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== null && adresseValue !== undefined) {
                $('#user-adresse').text(adresseValue);
            } else {
                $('#user-adresse').text("N/A");
            }

            var faritraValue = $(this).data('faritra');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user-faritra').text(faritraValue);
            } else {
                $('#user-faritra').text("N/A");
            }

            var lieuValue = $(this).data('lieu');
            if (faritraValue !== null && faritraValue !== undefined) {
                $('#user-lieuSakramenta').text(lieuValue);
            } else {
                $('#user-lieuSakramenta').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== null && masinaValue !== undefined) {
                $('#user-libMasina').text(masinaValue);
            } else {
                $('#user-libMasina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== null && vaomieraValue !== undefined) {
                $('#user-vaomiera').text(vaomieraValue);
            } else {
                $('#user-vaomiera').text("N/A");
            }

            var andraikitraValue = $(this).data('andraikitra');
            if (andraikitraValue !== null && andraikitraValue !== undefined) {
                $('#user-libAndraikitra').text(andraikitraValue);
            } else {
                $('#user-libAndraikitra').text("N/A");
            }

            // photoNom = $(this).data('sary');
            // $('#user-nom').text($(this).data('nom'));
            // $('#user-photo').attr('src', 'uploads/membres' + photoNom);

            
            var photoNom = $(this).data('sary');
            var cheminsImages = [
                'uploads/membres' + photoNom,
                'uploads/faritra/' + photoNom,
                'uploads/masina/' + photoNom,
                'uploads/vaomiera/' + photoNom,
                'uploads/gerant/' + photoNom
            ];

            // Parcourir tous les chemins d'image
            $.each(cheminsImages, function(index, cheminImage) {
                $.ajax({
                    url: cheminImage,
                    type: 'HEAD',
                    success: function() {
                        // Première image trouvée, définir l'attribut src
                        $('#user-nom').text($(this).data('nom'));
                        $('#user-photo').attr('src', cheminImage);
                        return false; // Arrêter la boucle
                    },
                    error: function() {
                        // L'image n'existe pas
                        if (index === cheminsImages.length - 1) {
                            // Aucune image trouvée, définir une image par défaut ou afficher un message d'erreur
                            $('#user-nom').text($(this).data('nom'));
                            $('#user-photo').attr('src', 'chemin/vers/image_par_defaut.jpg');
                        }
                    }
                });
            });

            $('#exampleModal').modal('show');
        });


    });
</script>
