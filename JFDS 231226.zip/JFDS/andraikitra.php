<?php

 include 'connect.php'; 
 include('db_function.php');  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $idKonty = $_SESSION['idKonty'];
if (isset($_POST['enregistrerAndraikitra'])) {
    $libAndraikitra = $_POST['libAndraikitra'];
    $libAndraikitra = escape_data($conn, $libAndraikitra);

            // Si la valeur n'existe pas, faire quelque chose d'autre ici
            $query  = "INSERT INTO andraikitra (libAndraikitra) VALUES ('$libAndraikitra')";
            $result = $conn->query($query);
            header("Location: andraikitra.php");
      
      }
 ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte1.php'; ?>   
    <div class="container">

    <?php if ($cat == "Admin" OR $cat == "superAdmin" ) {
     ?>
    <div class="row">
    <div class="col-md-4">
        <br>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Andraikitra</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Libellé</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libAndraikitra" class="form-control" required />
                        </div>
                    </div>
                    <div class="mb-3">

                        <input type="submit" class="btn btn-success" name="enregistrerAndraikitra" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <br>
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Lisitry ny Andraikitra</h6>
                
            </div>
            <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                <form>
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >

                              <th>Numéro</th>
                              <th>Libellé</th>
                              <th colspan="1" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                
                                        

                                        $query = "SELECT * FROM andraikitra ORDER BY idAndraikitra ASC ";
                                       
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  

                        <tr>

                              <td><?php echo $i; ?></td>
                              <td><?php echo $row['libAndraikitra']?></td>
                              <td style="text-align: right;">
                                <a href="deleteKonty.php?supprAndraikitra=<?php echo $row['idAndraikitra']; ?>">
                                  <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i> </button>
                                </a>
                              </td>
                          
                        </tr>
                        

                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>

                    </table>       
                </form>
            </div>
        </div>
    </div>

    </div><br><br>
    <?php } ?>

</div>


<br><br>
<?php include 'pannelAmbany.php'; ?> 