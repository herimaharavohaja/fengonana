<?php
include 'connect.php'; 

if(isset($_GET['libActivite'])) {
    $libActivite = $_GET['libActivite'];
    // error_log("LibActivite récupérée : " . $libActivite);
    require_once('kajyPresence.php');
    $sql9 = "SELECT 
                    p.libActivite AS activite,
                    CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur
                FROM proactivite p
                JOIN user u ON FIND_IN_SET(u.hashKonty, p.actif) > 0
                WHERE p.libActivite = '$libActivite'

                UNION

                SELECT 
                    p.libActivite AS activite,
                    k.libPseudo AS nom_konty
                FROM proactivite p
                JOIN konty k ON FIND_IN_SET(k.hashKonty, p.actif) > 0
                WHERE p.libActivite = '$libActivite'

                UNION

                SELECT 
                    'konty' AS activite,
                    k.libPseudo AS utilisateur
                FROM konty k
                WHERE 
                    FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                    NOT FIND_IN_SET(k.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))

                UNION

                SELECT 
                    'user' AS activite,
                    CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur
                FROM user u
                WHERE 
                    (
                        u.idFaritra IN (
                            SELECT k.idFaritra
                            FROM konty k
                            WHERE 
                                FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                                NOT FIND_IN_SET(u.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))
                        )
                        AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                    )
                    OR 
                    u.idMasina IN (
                        SELECT k.idMasina
                        FROM konty k
                        WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                        AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                    )
                    OR 
                    u.idSakramenta IN (
                        SELECT k.idSakramenta
                        FROM konty k
                        WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                        AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                    )
                    OR 
                    u.idVaomiera IN (
                        SELECT k.idVaomiera
                        FROM konty k
                        WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                        AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                    );
                ";
    $result9 = $conn->query($sql9);

    $nomUsers = array();

if ($result9->num_rows > 0) {
    while ($row9 = $result9->fetch_assoc()) {
        // $nomUsers[] = '<hr class="point-vert">' . $row9['utilisateur'] . '</hr>';
        $classe = ($row9['activite'] == $libActivite) ? 'point-vert' : 'point-rouge';
        $nomUsers[] = '<hr class="' . $classe . '">' . $row9['utilisateur'] . '</hr>';
    }
    $listeNoms = implode('<br>', $nomUsers);

    header('Content-Type: application/json');
    echo json_encode(array("nomUser" => $listeNoms,"present" => $present,"eff" => $total));

    } else {
        // Retournez une erreur si aucune correspondance n'est trouvée
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array("error" => "Aucune correspondance trouvée pour libActivite : $libActivite"));
    }
} else {
    // Retournez une erreur si libActivite n'est pas spécifié
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array("error" => "Paramètre libActivite manquant"));
}
?>


