 <?php  

 // session_start();

  if (!isset($_SESSION['libPseudo'])) {
    header("Location:index.php");
   
}

?>