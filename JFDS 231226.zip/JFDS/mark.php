<?php

 include 'connect.php';
 error_reporting(E_ALL);
ini_set('display_errors', 1);
//  include('db_function.php');
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];
 

if (isset($_POST['enregistrer'])) {
    $idOperation = $_POST['idOperation'];
    $idKonty = $_POST['idKonty'];
    $de = $_POST['de'];
    $a = $_POST['a'];

    // Récupérer le maximum de 'de' et le minimum de 'a' pour idOperation = 1
    $querySelect = "SELECT MAX(de) AS maxDe, MIN(a) AS minA FROM billet WHERE idOperation = '$idOperation'";
    $resultSelect = $conn->query($querySelect);

    if ($resultSelect->num_rows > 0) {
        $row = $resultSelect->fetch_assoc();
        $maxDeActuel = $row['maxDe'];
        $minAActuel = $row['minA'];

        // Vérifier si le nombre de 'de' ou de 'a' n'est pas compris dans la plage spécifiée
        if ($de < $maxDeActuel || $a > $minAActuel) {
            // Insertion si la condition est satisfaite
            $queryInsert = "INSERT INTO billet (de, a, idOperation, idKonty) VALUES ('$de', '$a', '$idOperation', '$idKonty')";
            $resultInsert = $conn->query($queryInsert);

            if ($resultInsert) {
                header("Location: billet.php");
            } else {
                echo "Erreur lors de l'insertion dans la table billet.";
            }
        } else {
            echo "<div id='notification' 
                    style='display:none;margin-top:-50px;margin-left:480px;width:border-radius: 20px;position:absolute;z-index:999999;padding:18px;background: red;color: white;'>
                    Le nombre de Debut ou de la fin est déjà occupé.</div>";
            echo "<script>
                    document.getElementById('notification').style.display = 'block';
                    setTimeout(function(){
                        document.getElementById('notification').style.display = 'none';
                    }, 10000);
                  </script>";
        }
    } else {
        echo "Aucune valeur.";
    }
}


      ?>
<?php include 'pannelAmbony.php'; ?>   
<?php include 'navCompte2.php'; ?>   
<br>

    <div class="container" style="border-radius: ">
    <div class="row">
    <div class="col-md-12">
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Marquage</h6>
            </div>
            <div class="card-body" style='max-height: 400px; overflow-y: auto;'>
                	<div style="display: flex; align-items: center;">
                        <?php 
                            $sqlOperation = "SELECT * FROM operation";
                            $resultOperation = $conn->query($sqlOperation);

                            $optionsOperation = [];
                            if ($resultOperation->num_rows > 0) {
                                while ($rowOperation = $resultOperation->fetch_assoc()) {
                                    $optionsOperation[] = $rowOperation;
                                }
                            }
                        ?>
                        <div class="form-outline mb-4">
                            <select name="idOperation" id="idOperation" required class="form-control" style="width: 140px;">
                                <option value="" disabled selected hidden>Opération</option>
                                <?php foreach ($optionsOperation as $optionOperationItem) : ?>
                                    <option value="<?php echo $optionOperationItem['idOperation']; ?>">
                                        <?php echo $optionOperationItem['libOperation']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Deuxième select pour les membres -->
                    <div >
                        <div class="form-outline mb-4">
                            <select name="idKonty" id="idKonty" required class="form-control" style="width: 140px;">
                                <option value="" disabled selected hidden>Membre</option>
                            </select>
                        </div>
                    </div>

                    <!-- Script JavaScript -->
                    <script>
                        document.getElementById('idOperation').addEventListener('change', function() {
                            var idOperation = this.value;

                            // Effectuer une requête AJAX pour récupérer les membres associés à l'opération
                            fetch('get_konty.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                },
                                body: 'idOperation=' + idOperation,
                            })
                            .then(response => response.json())
                            .then(data => {
                                // Mettre à jour la deuxième sélection avec les membres récupérés
                                var idKontySelect = document.getElementById('idKonty');
                                idKontySelect.innerHTML = '<option value="" disabled selected hidden>Membre</option>';
                                data.forEach(function(member) {
                                    var option = document.createElement('option');
                                    option.value = member.idKonty;
                                    option.text = member.nomKonty + ' ' + member.prenomKonty;
                                    idKontySelect.add(option);
                                });
                            })
                            .catch(error => console.error('Erreur lors de la récupération des membres:', error));
                        });
                    </script>

<div id="billetList" style="display: none;">
    <!-- La liste des numéros de billet avec des cases à cocher sera affichée ici -->
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#idKonty').change(function() {
        var selectedKonty = $(this).val();
        var selectedOperation = $('#idOperation').val(); // Récupérez l'ID de l'opération

        if (selectedKonty !== "" && selectedOperation !== "") {
            // Faire une requête AJAX pour récupérer les numéros de billet du membre sélectionné
            $.ajax({
                url: 'getBillet.php',
                type: 'POST',
                data: { idKonty: selectedKonty, idOperation: selectedOperation }, // Inclure l'ID de l'opération
                success: function(response) {
                    // Mettre à jour la div avec les numéros de billet et des cases à cocher
                    $('#billetList').html(response).show();
                }
            });
        } else {
            // Si aucun membre n'est sélectionné, masquer la liste des billets
            $('#billetList').hide();
        }
    });
    });
</script>

            </div>
        </div>
    </div>

    </div>
    </div>
</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 