<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $query = "UPDATE proActivite SET etatActivite='1' WHERE idPro=$ida";
    $result1 = $conn->query($query);
     header("Location:creaActivite.php");
  }
 ?>
