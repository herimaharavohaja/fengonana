<a class="sidebar-brand d-flex align-items-center justify-content-center" href="welcome.php" style="text-decoration: none;">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="./img/logoM1.jpeg" class="image-responsive" width="70px;">
                </div>
                <!-- <div class="sidebar-brand-text mx-3">SVM.VDKT <sup>mg</sup></div> -->
                <div class="sidebar-brand-text mx-3"><b>J . F . D . S</b></div>
            </a>