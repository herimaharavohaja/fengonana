<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
if (isset($_GET['id'])) {
    $ida = $_GET['id'];

    $sql = "SELECT *
      FROM user
      WHERE idUser = $ida";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  // $id = $row['id'];
  	$nomUser = $row['nomUser'];
    $prenomUser = $row['prenomUser'];
    $daty = date('Y-m-d');
    $sexeUser = $row['sexeUser'];

    $dteNaissUser = $row['dteNaissUser'];
    $apvUser = $row['apvUser'];
    $adresyUser = $row['adresyUser'];
    $idSakramenta = $row['idSakramenta'];
    $dteSakramentaUser = $row['dteSakramentaUser'];
    $lieuSakramenta = $row['lieuSakramenta'];
  }


  if (isset($_POST['submitModif'])) {
  	$nomUser = $_POST['nomUser'];
    $prenomUser = $_POST['prenomUser'];
    $daty = date('Y-m-d');
    $sexeUser = $_POST['sexeUser'];

    $dteNaissUser = $_POST['dteNaissUser'];
    $apvUser = $_POST['apvUser'];
    $adresyUser = $_POST['adresyUser'];
    $idSakramenta = $_POST['idSakramenta'];
    $dteSakramentaUser = $_POST['dteSakramentaUser'];
    $lieuSakramenta = $_POST['lieuSakramenta'];

    $nomImagesaryUser = $_FILES["saryUser"]["name"];
    $imageTmpsaryUser = $_FILES["saryUser"]["tmp_name"];
    $cheminImagesaryUser = "uploads/membres" . $nomImagesaryUser;
    move_uploaded_file($imageTmpsaryUser, $cheminImagesaryUser);

    $query = "UPDATE user 
    			SET nomUser='$nomUser', prenomUser='$prenomUser', sexeUser='$sexeUser', dteUser = '$daty'
    				dteNaissUser='$dteNaissUser', apvUser='$apvUser', adresyUser='$adresyUser', idSakramenta = '$idSakramenta', dteSakramentaUser='$dteSakramentaUser', lieuSakramenta='$lieuSakramenta', nomImagesaryUser='$nomImagesaryUser'
    			WHERE idKonty=$ida";
    $result1 = $conn->query($query);
     header("Location:creaFaritra.php");
  }else{
  }


 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">
					<h4 class='text-center' style='text-transform: uppercase'><b>Modifier un membre<br></b><br></h4>
                <form method='post' enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class='form-group'>
		                            <label>Sary:</label> 
		                            <input type="file" class="form-control" style="border:none; background: none;" name="saryUser" required/>
                        		</div>
							</div>
							<div class="col-md-8"></div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
		                            <label>Sexe :</label> 
		                            <br>
		                            <select name="sexeUser" required class="form-control">
		                            	<option value="" disabled selected hidden>Sexe</option>
		                            	<option value="Masculin">Masculin</option>
		                            	<option value="Féminin">Féminin</option>
		                            </select>
		                            
                        		</div>
							</div>
							<div class="col-md-6">
								<div class='form-group'>
									<label>Nom:</label> 
		                            <input class='form-control' value="<?php echo $nomUser; ?>" type='text' name='nomUser'>
		                            <br>
                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
									<label>Prénom(s):</label> 
		                            <input class='form-control' type='text' name='prenomUser' value="<?php echo $prenomUser; ?>">
		                            <br>
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
		                            <label>Date de naissance:</label> 
		                            <input type="date" name="dteNaissUser" class="form-control" value="<?php echo $dteNaissUser; ?>">
                        		</div>
							</div>
							<div class="col-md-6">
								<div class='form-group'>
									<label>APV:</label> 
		                            <input class='form-control' value="<?php echo $apvUser; ?>" type='text' name='apvUser'>

                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
		                            <label>Adresse actuelle:</label> 
		                            <input class='form-control' value="<?php echo $adresyUser; ?>" type='text' name='adresyUser'>
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-2">
								<div class='form-group'>
										<br>
		                            <label>Daty sakramenta:</label>
		                            <br> 
		                            <input type="date" name="dteSakramentaUser" class="form-control" value="<?php echo $dteSakramentaUser; ?>">
                        		</div>
							</div>

							<div class="col-md-6">
								<div class='form-group'>
		                            <?php 
		                            
									$sqlSakramenta = "SELECT * FROM sakramenta";
									$resultSakramenta = $conn->query($sqlSakramenta);

									$optionSakramenta = [];
									if ($resultSakramenta->num_rows > 0) {
										while ($rowSakramenta = $resultSakramenta->fetch_assoc()) {
											$optionSakramenta[] = $rowSakramenta;
										}
									}
								 ?>
								 	<br>
		                            <label>Sakramenta :</label> 
		                            <br>
		                            <select name="idSakramenta" required class="form-control">
		                            	<option value="" disabled selected hidden>Sakramenta</option>
		                            	<?php foreach ($optionSakramenta as $optionsSakramenta ) : ?>
		                            		<option value="<?php echo $optionsSakramenta['idSakramenta']; ?>">
		                            			
		                            			<?php echo $optionsSakramenta['libSakramenta']; ?>
		                            		</option>
		                            	<?php endforeach; ?>
		                            </select>
                        		</div>
							</div>
							<div class="col-md-4">
								<div class='form-group'>
										<br>
		                            <label>Lieu du sakramenta:</label>
		                            <br> 
		                            <input type="text" name="lieuSakramenta" class="form-control" value="<?php echo $lieuSakramenta; ?>">
                        		</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-5"></div>
							<div class="col-md-4">
								<br>
								<button type="submit" name= "submitModif" class="btn btn-success" >
	                    			<span class="bi bi-trash"></span> Modifier 
	                    		</button>
							</div>
							<div class="col-md-3"></div>
						</div>
					</form>
                    </div>
				<div class="col-md-1"></div>
			</div>
<br><br>
<?php include 'pannelAmbany.php'; ?> 