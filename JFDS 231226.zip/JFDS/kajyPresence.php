<?php 
    // present
$queryPr = "SELECT COUNT(*) AS present1 FROM (
                            SELECT 
                              p.libActivite AS activite,
                               CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur
                            FROM proactivite p
                            JOIN user u ON FIND_IN_SET(u.hashKonty, p.actif) > 0
                            WHERE p.libActivite = '$libActivite'

                            UNION

                            SELECT 
                              p.libActivite AS activite,
                              k.libPseudo AS nom_konty
                            FROM proactivite p
                            JOIN konty k ON FIND_IN_SET(k.hashKonty, p.actif) > 0
                            WHERE p.libActivite = '$libActivite' 
) AS present";
$resultPr = mysqli_query($conn, $queryPr);
$rowPr = mysqli_fetch_assoc($resultPr);
$present = $rowPr["present1"];




// absent
$queryAb = "SELECT COUNT(*) AS absent1 FROM (
                            SELECT k.libPseudo AS nom, k.idKonty AS id
    FROM konty k
    WHERE 
        FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
        NOT FIND_IN_SET(k.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))

UNION
(
    SELECT CONCAT(u.nomUser, ' ', u.prenomUser) AS nom, u.idUser AS id
    FROM user u
    WHERE 
        (
            u.idFaritra IN (
                SELECT k.idFaritra
                FROM konty k
                WHERE 
                    FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                    NOT FIND_IN_SET(u.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))
            )
            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
        )
        OR 
        u.idMasina IN (
            SELECT k.idMasina
            FROM konty k
            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
        )
        OR 
        u.idSakramenta IN (
            SELECT k.idSakramenta
            FROM konty k
            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
        )
        OR 
        u.idVaomiera IN (
            SELECT k.idVaomiera
            FROM konty k
            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
        )
)
) AS absent";
$resultAb = mysqli_query($conn, $queryAb);
$rowAb = mysqli_fetch_assoc($resultAb);
$absent = $rowAb["absent1"];

$total = $present + $absent;


 ?>
