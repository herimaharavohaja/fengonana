<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<br>
  <h4 class="text-center">
                            <b><?php echo ("Statistique des activités par mois"); ?></b>
                            <a href="fpdf/activite.php" style="text-decoration: none;">
                                <button class="btn btn-secondary">PDF</button>
                            </a>
                        </h4>

                        <?php
include('connect.php');

$dataArray = array();

$sql8 = "SELECT
    MONTHNAME(dtePresence) as mois,
    COUNT(libActivite) as nombreActivites,
    GROUP_CONCAT(DISTINCT libActivite SEPARATOR ', ') as activites
    FROM
    proactivite 
    WHERE
    dtePresence != '' 
    GROUP BY
    MONTHNAME(dtePresence)
    ORDER BY
    MONTH(dtePresence) ASC;";
$result8 = $conn->query($sql8);

if ($result8->num_rows > 0) {
    while ($row8 = $result8->fetch_assoc()) {
        $mois = $row8['mois'];
        $nombreActivites = $row8['nombreActivites'];
        $activites = $row8['activites'];

        $dataArray[] = array('mois' => $mois, 'nombreActivites' => $nombreActivites, 'activites' => $activites);
    }
} else {
    echo "Aucune activité trouvée.";
}

// À l'extérieur de la boucle while
echo "<script>
var dataArray = " . json_encode($dataArray) . ";
</script>";
?>

<canvas id="myChartCanvas" style="width: 500px; height: 180px;"></canvas>

<script>
    // Utilisez dataArray pour créer le graphique
    var ctx = document.getElementById('myChartCanvas').getContext('2d');
    
    // Créer le graphique en ligne
    var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dataArray.map(item => item.mois),
            datasets: [{
                label: 'Nombre d\'activités',
                data: dataArray.map(item => item.nombreActivites),
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                fill: false
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                        var label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        label += context.parsed.y;
                        return label;
                    },
                    title: function(context) {
                        var title = dataArray[context[0].dataIndex].mois + '\n';
                        title += 'Activités: ' + dataArray[context[0].dataIndex].activites + '\n';
                        return title;
                    }
                    }
                }
            }
        }
    });
</script>













