<?php
// get_masina.php
include 'connect.php'; // Assurez-vous d'inclure votre script de connexion à la base de données

$query = "SELECT * FROM masina";
$result = $conn->query($query);

$masinaList = array();
while ($row = $result->fetch_assoc()) {
    $masinaList[] = $row;
}

echo json_encode($masinaList);
?>
