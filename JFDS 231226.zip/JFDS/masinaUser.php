<?php

 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idMasina'];
 
// Vérification de la soumission du formulaire
if (isset($_POST['submitMembre'])) {

    // Récupération des données du formulaire
    
    $nomUser = $_POST['nomUser'];

    // Insertion des données dans la base de données si aucune erreur n'a été détectée
    if (empty($erreurs)) {
    		$sql3 = "SELECT * FROM user WHERE nomUser = '$nomUser'";
		 	$result3 = mysqli_query($conn, $sql3);
		    $row3 = mysqli_fetch_assoc($result3);
		    $idMasina1 = $row3['idMasina'];

		    if ($idMasina1 != '0' and $idMasina1 != '') {
			    ?>		

					<script>
				        alert('Ce compte est déjà dans un fikambanana masina!');
				        window.location.href='masinaUser.php';
			        </script>

				<?php
			} else{
				$sql = "UPDATE user SET idMasina = '$fari' WHERE nomUser = '$nomUser'";
				mysqli_query($conn, $sql);
	            header('Location: masinaUser.php');
				}
    } 

} 

?>			
<?php include 'pannelAmbony.php'; ?>  
		<div class="container">
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-5">
					<h4 class='text-center' style='text-transform: uppercase'><b>Ajouter un membre<br></b><br></h4>
					<form method='post' enctype="multipart/form-data">
						
								<label>Membres</label><br>
								<div class="search-box form-sgroup">
                                    <input class="form-control"  id="input_direction" name="nomUser" type="text" autocomplete='off' placeholder="Nom du membre" style="width: 430px" />
                                    <div class="result"></div>
                                </div>
				</div>
							<style type="text/css">
								/* Formatting search box */
							    .search-box{
							        width: 500px;
							        position: relative;
							        display: inline-block;
							        font-size: 14px;
							    }
							    .search-box input[type="text"]{
							        height: 38px;
							        padding: 5px 10px;
							        border: 1px solid #CCCCCC;
							        font-size: 14px;
							    }
							    .result{
							        position: absolute;        
							        z-index: 999;
							        top: 100%;
							        left: 0;
							    }
							    .search-box input[type="text"], .result{
							        width: 86%;
							        box-sizing: border-box;
							    }
							    /* Formatting result items */
							    .result p{
							        background-color: white;
							        margin: 0;
							        padding: 7px 10px;
							        border: 1px solid #CCCCCC;
							        border-top: none;
							        cursor: pointer;
							    }
							    .result p:hover{
							        background: #f2f2f2;
							    }
							</style>

							<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
							<script>
							$(document).ready(function(){
							    $('.search-box input[type="text"]').on("keyup input", function(){
							        /* Get input value on change */
							        var inputVal = $(this).val();
							        var resultDropdown = $(this).siblings(".result");
							        if(inputVal.length){
							            $.get("back-direction.php", {term: inputVal}).done(function(data){
							                // Display the returned data in browser
							                resultDropdown.html(data);
							            });
							        } else{
							            resultDropdown.empty();
							        }
							    });
							    
							    // Set search input value on click of result item
							    $(document).on("click", ".result p", function(){
							        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
							        $(this).parent(".result").empty();
							    });
							});
							</script>
							
							<div class="col-md-2">
								<br><br><br><br>
								<button type="submit" name= "submitMembre" class="btn btn-success" >
	                    			<i class="bi bi-person-check"></i>
	                    		</button>
							</div>

					</form>

				<div class="col-md-1"></div>
			</div>
		</div>
				
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-10">
                <div class="">
                	<div >
                		<br><br>
                        <h4 class="text-center"><b><?php echo ("Liste de membre"); ?></b></h4>
                        
                    </div>
                    <div class="text-center" style="max-height: 250px;overflow-y: auto;">
                        <table class="table table-bordered">
				        <thead class="alert-success " style="background: navy; color: white;">

						  <tr class="text-center">
				            <!-- <th>N°</th> -->
				            <th class="text-center">Code</th>
				            <th class="text-center">Nom</th>
				            <th class="text-center">Prénom(s)</th>
				            <th class="text-center">Adresse</th>
				            <!-- <th class="text-center">Date d'inscription</th> -->
				            <th class="text-center" colspan="1">Actions</th>
				          </tr>
				        </thead>
				        <tbody>
				          <?php 

						// Requête SQL pour sélectionner tous les utilisateurs
						$sqlkonty = "SELECT masina.*, user.* FROM user 
							INNER JOIN masina ON masina.idMasina = user.idMasina
							WHERE user.idMasina = '$fari'
							ORDER BY user.IdUser DESC LIMIT 4";
						$resultkonty = mysqli_query($conn, $sqlkonty);

						if (mysqli_num_rows($resultkonty) > 0 ) {
							$i = 0;
						    // Affichage des données de chaque utilisateur
						    while($row = mysqli_fetch_assoc($resultkonty)) {
						    	// $i = $i+1;
						    	$idUser = $row["idUser"];
						        $codeUser = $row["codeUser"];
						        $nomUser = $row["nomUser"];
						        $prenomUser = $row["prenomUser"];
						        $dteNaissUser = $row["dteNaissUser"];
						        $adresyUser = $row["adresyUser"];
						        $dteUser = $row["dteUser"];
						        $sexeUser = $row["sexeUser"];
						        ?>
						        <tr>

				                    <td><?php echo $codeUser; ?></td>
				                    <td><?php echo $nomUser; ?></td>
				                    <td><?php echo $prenomUser; ?></td>
				                    <td><?php echo $adresyUser; ?></td>
				                    <!-- <td><?php echo $dteUser; ?></td> -->
				                    <!-- <td class="text-center">
				                    	<a href="modifMembreMasina.php?id=<?php echo $row['idUser']; ?>">
		                                  <button type="button" class="btn btn-primary" >Modifier </button>
		                                </a>
		                            </td> -->
		                            <td>
		                                <a href="deleteKonty.php?supprMembreMasina=<?php echo $row['idUser']; ?>">
						                    <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ce compte dans la liste de vos membres?')"><i class="bi bi-trash"></i></button>
						                </a>
	                    			</td>
                    
                  	</tr>
 
               	<?php 
			    }
			} else {
			    echo "Néant";
			}

			// Fermeture de la connexion
			mysqli_close($conn);
          ?>
          </tbody>
      			</table>
                    </div>
                    <br><br>
                </div>
            </div>

            <div class="col-md-1"></div>
        </div>
    </div>
    <br><br>
<?php include 'pannelAmbany.php'; ?> 