<?php

 error_reporting(E_ALL);
ini_set('display_errors', 1);

 include './phpqrcode/qrlib.php';
 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

 $sql3 = "SELECT * FROM faritra WHERE idFaritra = '$fari'";
 $result3 = mysqli_query($conn, $sql3);

 // 
    $row3 = mysqli_fetch_assoc($result3);
    $libFaritra = $row3['libFaritra'];

    if ($libFaritra == '') {
    header('Location: index.php');
}

 
 // echo $libFaritra;
// Vérification de la soumission du formulaire
if (isset($_POST['submitMembre'])) {

    // Récupération des données du formulaire
    
    $nomUser = $_POST['nomUser'];
    $prenomUser = $_POST['prenomUser'];
    $daty = date('Y-m-d');
    $sexeUser = $_POST['sexeUser'];
    $codeUser = $_POST['codeUser'];
    $hashKonty = base64_encode($codeUser);
    $dteNaissUser = $_POST['dteNaissUser'];
    $apvUser = $_POST['apvUser'];
    $adresyUser = $_POST['adresyUser'];

    $nomImagesaryUser = $_FILES["saryUser"]["name"];
    $imageTmpsaryUser = $_FILES["saryUser"]["tmp_name"];

    $cheminDossierMembre = "uploads/" . $libFaritra;
    // Vérifier si le dossier du membre existe
	if (!file_exists($cheminDossierMembre)) {
	    // Si le dossier n'existe pas, le créer avec les permissions 0755
	    mkdir($cheminDossierMembre, 0755, true);
	}

	// Construire le chemin complet de l'image
	$cheminImagesaryUser = $cheminDossierMembre . "/" . $nomImagesaryUser;


    // $cheminImagesaryUser = "uploads/membres/" . $nomImagesaryUser;
    move_uploaded_file($imageTmpsaryUser, $cheminImagesaryUser);

    // Insertion des données dans la base de données si aucune erreur n'a été détectée
    if (empty($erreurs)) {
        $sql = "INSERT INTO user (idFaritra, nomUser, prenomUser, dteUser, sexeUser, dteNaissUser, apvUser, adresyUser , saryUser, codeUser, hashKonty) VALUES ('$fari', '$nomUser', '$prenomUser',  '$daty', '$sexeUser', '$dteNaissUser', '$apvUser', '$adresyUser' , '$nomImagesaryUser', '$codeUser', '$hashKonty')";   

        if ($conn->query($sql) === TRUE) {
            // Générez le QR code
            $cheminDossierQr = "./qrcodes/" . $libFaritra;
            if (!file_exists($cheminDossierQr)) {
			    // Si le dossier n'existe pas, le créer avec les permissions 0755
			    mkdir($cheminDossierQr, 0755, true);
			}
			QRcode::png($hashKonty, $cheminDossierQr . '/' . $nomUser . ' ' . $prenomUser . '.png');

			// echo "QR code généré avec succès : <img src='qrcodes/$codeUser.png' />";
            ?>
                <script>
			    	window.location.href='faritraUser.php';
			    </script>
			<?php

        } else {
            header('Location: faritraUser.php');
        }
    } 

} 

?>			
<?php include 'pannelAmbony.php'; ?>  
		<div class="container">
					
					<div class="row">
					<div class="col-md-4">
						<h4 class='text-center'><b>Ajouter un Membre</b></h4>
						<form method='post' enctype="multipart/form-data">
							<div class='form-group' style="max-height: 480px;overflow-y: auto;">
								<div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Sary:</label> 
			                        <input type="file" class="form-control" style="border:none; background: none;" name="saryUser" required/>
                        		</div>

                        		<div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Sexe:</label> 
			                        <select name="sexeUser" required class="form-control">
			                            <option value="" disabled selected hidden>Sexe</option>
			                            <option value="Masculin">Masculin</option>
			                            <option value="Féminin">Féminin</option>
			                        </select>
			                    </div>

		                        <div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Code:</label> 
			                        <input class='form-control' required type='text' name='codeUser'>
			                    </div>

			                    <div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Nom:</label> 
		                        	<input class='form-control' required type='text' name='nomUser'>
		                        </div>

		                        <div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Prénom(s):</label> 
		                        	<input class='form-control' type='text' name='prenomUser'>
		                        </div>

		                        <div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Date naissance:</label>
		                        	<input type="date" name="dteNaissUser" class="form-control" required>
		                        </div>

                        		<div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">APV:</label> 
		                        	<input class='form-control' required type='text' name='apvUser'>
		                        </div>
								<?php 
		                           	$sqlAndraikitra = "SELECT * FROM andraikitra";
									$resultAndraikitra = $conn->query($sqlAndraikitra);

									$optionAndraikitra = [];
									if ($resultAndraikitra->num_rows > 0) {
										while ($rowAndraikitra = $resultAndraikitra->fetch_assoc()) {
											$optionAndraikitra[] = $rowAndraikitra;
										}
									}
								?>
								<div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Andraikitra:</label> 
									<select name="libAndraikitra" class="form-control">
			                            <option value="" disabled selected hidden>Andraikitra</option>
			                            <?php foreach ($optionAndraikitra as $optionsAndraikitra ) : ?>
			                            	<option value="<?php echo $optionsAndraikitra['libAndraikitra']; ?>">
			                            		<?php echo $optionsAndraikitra['libAndraikitra']; ?>
			                            	</option>
			                            <?php endforeach; ?>
			                        </select>
			                    </div>
								<div style="display: flex; align-items: center;">
			                        <label style="margin-top: 10px;">Adresse actuelle:</label> 
		                        	<input class='form-control' required type='text' name='adresyUser'>
                        		</div>

								
								<button type="submit" name= "submitMembre" class="btn btn-success" >
	                    			<i class="bi bi-journal-plus"></i> Créer 
	                    		</button>

						</div>	
					</form>
					</div>

					<div class="col-md-8">
						<div >
                        <h4 class="text-center"><b><?php echo ("Liste de membre"); ?></b></h4>
                        </div>
                    <div class="text-center" style="max-height: 400px;overflow-y: auto;">
                        <table class="table table-bordered">
				        <thead class="alert-success " style="background: navy; color: white;">

						  <tr class="text-center">
				            <th class="text-center">Code</th>
				            <th class="text-center">Nom</th>
				            <th class="text-center">Prénom(s)</th>
				            <th class="text-center">Adresse</th>
				            <!-- <th class="text-center">Date d'inscription</th> -->
				            <th class="text-center" colspan="2">Actions</th>
				          </tr>
				        </thead>
				        <tbody>
				          <?php 

						// Requête SQL pour sélectionner tous les utilisateurs
						$sqlkonty = "SELECT faritra.*, user.* FROM user 
							LEFT JOIN faritra ON faritra.idFaritra = user.idFaritra
							ORDER BY user.idUser DESC LIMIT 4";
						$resultkonty = mysqli_query($conn, $sqlkonty);

						if (mysqli_num_rows($resultkonty) > 0 ) {
							$i = 0;
						    // Affichage des données de chaque utilisateur
						    while($row = mysqli_fetch_assoc($resultkonty)) {
						    	// $i = $i+1;
						    	$idUser = $row["idUser"];
						        $codeUser = $row["codeUser"];
						        $nomUser = $row["nomUser"];
						        $prenomUser = $row["prenomUser"];
						        $dteNaissUser = $row["dteNaissUser"];
						        $adresyUser = $row["adresyUser"];
						        $dteUser = $row["dteUser"];
						        $sexeUser = $row["sexeUser"];
						        ?>
						        <tr>
				                    <td>
				                    	<?php
				                    		// echo $codeUser; 
				                    	?>
				                    	<span id="code_<?php echo $row['idUser']; ?>">
						                    <?php echo $row['codeUser'] ?>
						                </span>
						                <form id="code_form_<?php echo $row['idUser']; ?>" style="display:none;">
						                    <input type="text" name="editedCode" class="form-control" value="<?php echo $row['codeUser']; ?>">
						                </form>
				                    </td>
				                    <td>
				                    		<?php 
				                    			// echo $nomUser;
				                    		?>
				                    		<span id="nom_<?php echo $row['idUser']; ?>">
						                    <?php echo $row['nomUser'] ?>
							                </span>
							                <form id="nom_form_<?php echo $row['idUser']; ?>" style="display:none;">
							                    <input type="text" name="editedNom" class="form-control" value="<?php echo $row['nomUser']; ?>">
							                </form>
				                	</td>
				                    <td>
				                    		<?php 
				                    			// echo $prenomUser;
				                    		?>
				                    		<span id="prenom_<?php echo $row['idUser']; ?>">
						                    <?php echo $row['prenomUser'] ?>
							                </span>
							                <form id="prenom_form_<?php echo $row['idUser']; ?>" style="display:none;">
							                    <input type="text" name="editedPrenom" class="form-control" value="<?php echo $row['prenomUser']; ?>">
							                </form>
				                	</td>
				                    <td>
				                    		<?php 
				                    			// echo $adresyUser;
				                    		?>
				                    		<span id="adresy_<?php echo $row['idUser']; ?>">
						                    <?php echo $row['adresyUser'] ?>
							                </span>
							                <form id="adresy_form_<?php echo $row['idUser']; ?>" style="display:none;">
							                    <input type="text" name="editedAdresy" class="form-control" value="<?php echo $row['adresyUser']; ?>">
							                </form>
				                	</td>
				                    <!-- <td><?php echo $dteUser; ?></td> -->
				                    <td class="text-center">
				                    	<button type="button" id="mod_<?php echo $row['idUser']; ?>" class="btn btn-primary" onclick="editRow(<?php echo $row['idUser']; ?>)">
				                    		<i class="bi bi-pen"></i>
				                    	</button>
						                <button type="button" id="enre1_<?php echo $row['idUser']; ?>" class="btn btn-success" onclick="saveEdit(<?php echo $row['idUser']; ?>)"style="display:none;" >
						                	Enregistrer
						                </button>
						                <a href="deleteKonty.php?supprMembre=<?php echo $row['idUser']; ?>">
						                    <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ce compte?')"><i class="bi bi-trash"></i></button>
						                </a>

	                    			</td>
                    
                  	</tr>
                  	<!-- Ajout du script JavaScript -->
					<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
					<script>
					    function editRow(id) {
					        // Masquer le texte et afficher le formulaire
					        $("#code_" + id).hide();
					        $("#nom_" + id).hide();
					        $("#prenom_" + id).hide();
					        $("#adresy_" + id).hide();

					        $("#mod_" + id).hide();

					        $("#code_form_" + id).show();
					        $("#nom_form_" + id).show();
					        $("#prenom_form_" + id).show();
					        $("#adresy_form_" + id).show();
					        $("#enre1_" + id).show();
					    }

					    function saveEdit(id) {
					        // Récupérer les valeurs éditées
					        var editedCode = $("form#code_form_" + id + " input[name='editedCode']").val();
					        var editedNom= $("form#nom_form_" + id + " input[name='editedNom']").val();
					        var editedPrenom = $("form#prenom_form_" + id + " input[name='editedPrenom]").val();
					        var editedAdresy = $("form#adresy_form_" + id + " input[name='editedAdresy']").val();

					        console.log('ID:', id);
					        console.log('Edited Code:', editedCode);

					        // Envoyer les données au serveur avec AJAX
					        fetch('saveEditUser.php', {
					            method: 'POST',
					            headers: {
					                'Content-Type': 'application/json',
					            },
					            body: JSON.stringify({ id: id, editedCode: editedCode, editedNom: editedNom, editedPrenom: editedPrenom, editedAdresy: editedAdresy }),
					        })
					        .then(response => response.json())
					        .then(data => {
					            console.log('Response from server:', data);

					            // Mettre à jour l'affichage après avoir reçu la réponse du serveur
					            if (data.success) {
					                console.log('Mise à jour réussie dans la base de données.');
					                $("#code_" + id).html(editedCode);
					                $("#nom_" + id).html(editedNom);
					                $("#prenom_" + id).html(editedPrenom);
					                $("#adresy_" + id).html(editedAdresy);

					                // Afficher à nouveau le texte
					                $("#code_" + id).show();
					                $("#nom_" + id).show();
					                $("#prenom_" + id).show();
					                $("#adresy_" + id).show();
					                $("#mod_" + id).show();
					                // Masquer les formulaires
					                $("#code_form_" + id).hide();
					                $("#nom_form_" + id).hide();
					                $("#prenom_form_" + id).hide();
					                $("#adresy_form_" + id).hide();
					                $("#enre1_" + id).hide();
					            } else {
					                console.error('Erreur lors de la mise à jour dans la base de données.');
					                alert('Erreur lors de la sauvegarde.');
					            }
					        })
					        .catch((error) => {
					            console.error('Erreur de fetch :', error);
					        });
					    }
					</script>
 
               	<?php 
			    }
			} else {
			    echo "Néant";
			}

			// Fermeture de la connexion
			mysqli_close($conn);
          ?>
          </tbody>
      			</table>
                    </div>
					</div>
				</div>
    </div>
    <br><br>
<?php include 'pannelAmbany.php'; ?> 