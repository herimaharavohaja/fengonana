<?php 
include 'connect.php';
session_start();
$cat = $_SESSION['libCategorie'];
if ($cat == "superAdmin" || $cat == "Admin" ) {
        $libCategorie = 'Admin';
    } 
if (isset($_POST['enregistrer'])) {
    $codeKonty = $_POST['codeKonty'];
    $hashKonty = base64_encode($codeKonty);
    $libPseudo = $_POST['libPseudo'];
    $libPseudo = mysqli_real_escape_string($conn, $libPseudo);
    $libPass = $_POST['libPass'];
    $libPass = mysqli_real_escape_string($conn, $libPass);
    $dateDuJour = date("Y-m-d");
    
    
            // Si la valeur n'existe pas, faire quelque chose d'autre ici
            $query  = "INSERT INTO konty (libPseudo, libPass, libCategorie, codeKonty, hashKonty, dteCrea) 
                        VALUES ('$libPseudo', '$libPass','$libCategorie', '$codeKonty', '$hashKonty', '$dateDuJour')";
            $result = $conn->query($query);
            header("Location: compteAdmin.php");
      
      }

    ?>


<?php include 'pannelAmbony.php'; ?>   
<?php 
include 'navCompte.php'; 
?>   
<br>
<div class="container">
    <div class="row">
    <div class="col-md-4">
        <br>
        <div class="card shadow ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Administrateur</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST">

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Code</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="codeKonty" class="form-control" required />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Pseudo</label>
                        <div class="form-outline mb-4">
                            <input type="text" id="form1Example1" name="libPseudo" class="form-control" required />
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="form1Example1">Mot de passe</label>
                        <div class="form-outline mb-4">
                            <input type="password" id="form1Example2" name="libPass"  class="form-control" required />
                        </div>
                     </div>


                    <div class="mb-3">

                        <input type="submit" class="btn btn-success" name="enregistrer" value="Créer"  />
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <br>
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Listes des administrateurs</h6>
                
            </div>
            <div class="card-body" style="max-height: 350px;overflow-y: auto;">
                <form>
                    <table id="Table_util" class="table table-bordered table-striped text-center" >
                        <thead>
                            <tr >
                              <!-- <th>Numéro</th> -->
                              <th>Code</th>
                              <th>Pseudo</th>
                              <th>Mot de Passe</th>
                              <!-- <th>Catégories</th> -->
                              <th class="text-center" colspan="2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $i = 0; 
                                if ($cat == "superAdmin") {
                                    if (isset($_POST['search'])) {
                                        $nom_rech = $_POST['saisir'];

                                        if ($nom_rech == "") {
                                          $query = "SELECT * FROM konty
                                                    WHERE libCategorie ='Admin'";
                                        }else{

                                        $query = "SELECT * FROM konty
                                                    WHERE libCategorie ='Admin' 
                                                    ORDER BY idKonty ASC";
                                       }
                                    }else{

                                    $query = "SELECT * FROM konty
                                                WHERE libCategorie ='Admin' 
                                                ORDER BY idKonty ASC ";
                                   
                                    }
                                    } else{
                                        if (isset($_POST['search'])) {
                                        $nom_rech = $_POST['saisir'];

                                            if ($nom_rech == "") {
                                              $query = "SELECT * FROM konty
                                                        WHERE libCategorie ='User'";
                                            }else{

                                            $query = "SELECT * FROM konty
                                                        WHERE libCategorie ='User' 
                                                        ORDER BY idKonty ASC";
                                           }
                                      }else{

                                        $query = "SELECT * FROM konty
                                                    WHERE libCategorie ='User' 
                                                    ORDER BY idKonty ASC ";
                                       
                                        }
                                    }
                          
                           $result = $conn->query($query);

                      if ($result->num_rows > 0) {
                             while ($row = $result->fetch_array()) {
                                $i = $i + 1;
                ?>  
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                        <tr>
                              <td>
                                <span id="codeK1_<?php echo $row['idKonty']; ?>">
                                    <?php echo $row['codeKonty'] ?>
                                </span>
                                <form id="code_formK1_<?php echo $row['idKonty']; ?>" style="display:none;">
                                    <input type="text" name="editedCodeK" class="form-control" value="<?php echo $row['codeKonty']; ?>">
                                </form>
                              </td>

                              <td>
                                <span id="libK_<?php echo $row['idKonty']; ?>">
                                    <?php echo $row['libPseudo']?>
                                </span>
                                <form id="lib_formK_<?php echo $row['idKonty']; ?>" style="display:none;">
                                    <input type="text" name="editedValueK" class="form-control" value="<?php echo $row['libPseudo']; ?>">
                                </form>
                              </td>

                              <td>
                                <span id="passK_<?php echo $row['idKonty']; ?>">
                                    <?php echo $row['libPass']?>
                                </span>
                                <form id="pass_formK_<?php echo $row['idKonty']; ?>" style="display:none;">
                                    <input type="text" name="passValueK" class="form-control" value="<?php echo $row['libPass']; ?>">
                                </form>
                              </td>
                              <td style="text-align: right;">
                                <button type="button" id="modK_<?php echo $row['idKonty']; ?>" class="btn btn-primary" onclick="editRowK(<?php echo $row['idKonty']; ?>)"><i class="bi bi-pen"></i></button>
                                <button type="button" id="enreK_<?php echo $row['idKonty']; ?>" class="btn btn-success" onclick="saveEditK(<?php echo $row['idKonty']; ?>)" style="display:none;" >Enregistrer</button>
                                <a href="deleteKonty.php?suppr=<?php echo $row['idKonty']; ?>">
                                <button type="button" class="btn btn-danger" onclick="return confirm('Voulez vous vraiment supprimer ?')"><i class="bi bi-trash"></i></button>
                                </a>
                                </td>
                          
                        </tr>
                        <script>
                            function editRowK(id) {
                                // Masquer le texte et afficher le formulaire
                                $("#codeK1_" + id).hide();
                                $("#libK_" + id).hide();
                                $("#passK_" + id).hide();

                                $("#modK_" + id).hide();

                                $("#code_formK1_" + id).show();
                                $("#lib_formK_" + id).show();
                                $("#pass_formK_" + id).show();

                                $("#enreK_" + id).show();
                            }

                            function saveEditK(id) {
                                // Récupérer les valeurs éditées
                                var editedCode = $("#code_formK1_" + id + " input[name='editedCodeK']").val();
                                var editedValue = $("#lib_formK_" + id + " input[name='editedValueK']").val();
                                var passValue = $("#pass_formK_" + id + " input[name='passValueK']").val();

                                console.log('ID:', id);
                                console.log('Edited Code:', editedCode);
                                console.log('Edited lib:', editedValue);
                                console.log('Edited pass:', passValue);

                                // Envoyer les données au serveur avec AJAX
                                fetch('saveEditKonty.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                    },
                                    body: JSON.stringify({ id: id, editedCode: editedCode, editedValue: editedValue, passValue: passValue }),
                                })
                                .then(response => response.json())
                                .then(data => {
                                    console.log('Response from server:', data);

                                    // Mettre à jour l'affichage après avoir reçu la réponse du serveur
                                    if (data.success) {
                                        console.log('Mise à jour réussie dans la base de données.');
                                        $("#codeK1_" + id).html(editedCode);
                                        $("#libK_" + id).html(editedValue);
                                        $("#passK_" + id).html(passValue);

                                        // Afficher à nouveau le texte
                                        $("#codeK1_" + id).show();
                                        $("#libK_" + id).show();
                                        $("#passK_" + id).show();
                                        $("#modK_" + id).show();
                                        // Masquer les formulaires
                                        $("#code_formK1_" + id).hide();
                                        $("#lib_formK_" + id).hide();
                                        $("#pass_formK_" + id).hide();
                                        $("#enreK_" + id).hide();
                                    } else {
                                        console.error('Erreur lors de la mise à jour dans la base de données.');
                                        alert('Erreur lors de la sauvegarde.');
                                    }
                                })
                                .catch((error) => {
                                    console.error('Erreur de fetch :', error);
                                });
                            }
                        </script>

                        <?php }

                      }else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                    </tbody>

                    </table> 
                          
                </form>
            </div>
        </div>
    </div>

    </div>
</div>


<br><br>
<?php include 'pannelAmbany.php'; ?> 