<style>
    .collapsible-container {
      display: flex;
      justify-content: space-between;
      margin-top: -24px;
    }

    .collapsible {
      background-color: #777;
      color: white;
      cursor: pointer;
      padding: 18px;
      flex-grow: 1;
      border: none;
      text-align: center;
      outline: none;
      font-size: 15px;
      transition: background-color 0.3s;
    }
    .collapsible:hover {
      background-color: skyblue; /* Changement de couleur au survol de la souris */
    }

    .collapsible.active {
      background-color: #555; 
    }

    .content {
      padding: 0 18px;
      display: none;
      overflow: hidden;
      background-color: #f1f1f1;
      width: 100%;
    }

    .noButton {
        border: none;
        background: none;
        padding: 0;
        margin: 0;
        font-size: inherit;
        color: white;
    }
  </style>

<div class="collapsible-container">
        <a href="creaSakramenta.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'creaSakramenta.php') ? 'active' : ''; ?>">
            <button class="noButton">Sakramenta</button>
        </a>
    <a href="creaFaritra.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'creaFaritra.php') ? 'active' : ''; ?>"><button class="noButton">Faritra</button></a>
    <a href="creaMasina.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'creaMasina.php') ? 'active' : ''; ?>"><button class="noButton">Fikambanana Masina</button></a>
    <a href="creaVaomiera.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'creaVaomiera.php') ? 'active' : ''; ?>"><button class="noButton">Vaomieran'asa</button></a>
    <a href="ev.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'ev.php') ? 'active' : ''; ?>"><button class="noButton">Evènment spécial</button></a>
    <a href="andraikitra.php" class="collapsible <?php echo (basename($_SERVER['PHP_SELF']) == 'andraikitra.php') ? 'active' : ''; ?>"><button class="noButton">Andraikitra</button></a>
</div>