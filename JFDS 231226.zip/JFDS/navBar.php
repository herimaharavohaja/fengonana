
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="/js/jquery-1.8.3.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<style>
        body {
            padding-top: 56px; 
        }
    </style>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow " style="position: fixed;top: 0;left: 0;width: 100%;z-index: 99;">
                    <?php include "logo.php"; ?>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow"> 
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                    <?php 
                                        // $_SESSION['libPseudo'] = $libPseudo;
                                        echo $libPseudo = $_SESSION['libPseudo'];
                                    ?>
                                </span>
                                <?php 
                                    $cat = $_SESSION['libCategorie'];
                                    // echo $cat;
                                    if ($cat != 'membre') {
                                        $sqlU = "SELECT * FROM konty WHERE libPseudo = '$libPseudo'";

                                        $resultU = mysqli_query($conn, $sqlU);

                                        if (mysqli_num_rows($resultU) > 0) {
                                            $rowU = mysqli_fetch_assoc($resultU);

                                            $saryKonty= $rowU["saryKonty"];

                                            // echo '<img class="img-profile rounded-circle" src="img/' . $saryKonty . '" />';
                                            $cheminImage = "uploads/faritra/" . $saryKonty;
                                            $cheminImage1 = "uploads/gerant/" . $saryKonty;
                                            $cheminImage2 = "uploads/masina/" . $saryKonty;
                                            $cheminImage3 = "uploads/vaomiera/" . $saryKonty;

                                            if (file_exists($cheminImage)) {
                                                echo "<img class='img-profile rounded-circle' src='" . $cheminImage . "' >";
                                            } elseif (file_exists($cheminImage1)) {
                                                echo "<img class='img-profile rounded-circle' src='" . $cheminImage1 . "' >";
                                            } elseif (file_exists($cheminImage2)) {
                                                echo "<img class='img-profile rounded-circle' src='" . $cheminImage2 . "' >";
                                            } elseif (file_exists($cheminImage3)) {
                                                echo "<img class='img-profile rounded-circle' src='" . $cheminImage3 . "' >";
                                            }
                                        }
                                            else {
                                              echo '<img class="img-profile rounded-circle" src="img/undraw_profile.svg/>';  
                                            } 
                                    } elseif ($cat == 'membre'){
                                       $sqlUR = "SELECT * FROM user WHERE idUser = '$libPseudo'";

                                        $resultUR = mysqli_query($conn, $sqlUR);

                                        if (mysqli_num_rows($resultUR) > 0) {
                                            $rowUR = mysqli_fetch_assoc($resultUR);

                                            $saryUser= $rowUR["saryUser"];
                                            echo '<img class="img-profile rounded-circle" src="uploads/membres' . $saryUser . '" />';
                                        }  
                                            else {
                                              echo '<img class="img-profile rounded-circle" src="img/undraw_profile.svg">';  
                                            }
                                    } else {
                                        echo '<img class="img-profile rounded-circle" src="img/undraw_profile.svg/>';
                                    }
                                 ?>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <?php if ($cat != "membre" ) { ?>
                                <a class="dropdown-item" href="editUser.php?id=<?php echo $libPseudo; ?>" style="text-decoration: none;">
                                    <i class="bi bi-person-circle mr-2"></i>
                                    Profile
                                </a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="modalLogout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="bi bi-box-arrow-right mr-2"></i>
                                    Déconnecter
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav><br>
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Prêt pour quitter?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Cliquer sur Se déconnecter pour la déconnection.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Retour</button>
                    <a class="btn btn-primary" href="logout.php">Se déconnecter</a>
                </div>
            </div>
        </div>
    </div>