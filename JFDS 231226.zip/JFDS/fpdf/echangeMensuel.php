<?php
require('fpdf.php'); // Assurez-vous d'inclure le fichier FPDF approprié
include '../connect.php';

$mois = $_GET['mois'];
$querySetLocale = "SET lc_time_names = 'fr_FR'";
$conn->query($querySetLocale);

$sql = "SELECT *, MONTHNAME(daty) AS nom_mois FROM caisse WHERE MONTH(daty) = '$mois'";
$result2 = mysqli_query($conn, $sql);
$row2 = mysqli_fetch_assoc($result2);
$nom_mois = $row2['nom_mois'];

// Créer une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage('L');

// Titre
$pdf->SetFont('Arial','B', 13);
$pdf->Cell(0, 10, iconv("UTF-8", 'windows-1252','Bilan du mois de ' ) . $nom_mois, 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 5, utf8_decode('N°'), 1,0);
$pdf->Cell(25, 5, utf8_decode('Date'), 1,0);
$pdf->Cell(30, 5, utf8_decode('Mouvement'), 1,0);
$pdf->Cell(30, 5, utf8_decode('Montant'), 1,0);
$pdf->Cell(100, 5, utf8_decode('Motif'), 1,0);
$pdf->Cell(80, 5, utf8_decode('Solde (Ar)'), 1,1);
// $pdf->Ln(10);

// present
$query = "SELECT * FROM caisse WHERE MONTH(daty) = '$mois'";
    
                $result = $conn->query($query);

                if ($result) {
                    $i = 0; // Initialisez le compteur
                    while ($row = $result->fetch_assoc()) {
                        $i = $i + 1;
                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(10, 5, $i, 1, 0);
                        $pdf->Cell(25, 5, $row['daty'], 1, 0);
                        $pdf->Cell(30, 5, $row['type'], 1, 0);
                        $pdf->Cell(30, 5, $row['montant'], 1, 0);
                        $pdf->Cell(100, 5, $row['motif'], 1, 0);
                        $pdf->Cell(80, 5, $row['solde'], 1, 1);
                    }
                }
// Générer le PDF

$pdf->Output('sexe.pdf', 'D');


?>
