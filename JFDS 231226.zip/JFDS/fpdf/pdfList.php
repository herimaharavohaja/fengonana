<?php
require('fpdf.php'); // Assurez-vous d'inclure le fichier FPDF approprié
include '../connect.php';

$id = $_GET['id'];

$sql = "SELECT proactivite.* 
			FROM `proactivite` WHERE idPro = '$id'";
$result2 = mysqli_query($conn, $sql);
$row2 = mysqli_fetch_assoc($result2);
$libActivite = $row2['libActivite'];

require_once('../kajyPresence.php');


// Créer une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage('L');

// Titre
$pdf->SetFont('Arial','B', 13);
$pdf->Cell(0, 10, iconv("UTF-8", 'windows-1252','Fiche de présence pour : ' ) . $row2['libActivite'], 0, 1, 'C');
$pdf->Ln(10);

// Date
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(50, 5, 'Date : ' . $row2['dtePresence'], 0, 1, 'L');
$pdf->Ln();



$pdf->Cell(50, 5, iconv("UTF-8", 'windows-1252','Liste de personnes présentes : ') . $present, 0, 1, 'L');


$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 5, utf8_decode('N°'), 1,0);
$pdf->Cell(270, 5, utf8_decode('Nom & Prénom'), 1, 1);
// $pdf->Ln(10);

// present
$query = "SELECT 
                p.dtePresence AS daty,
                p.libActivite AS activite,
                CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur
            FROM proactivite p
            JOIN user u ON FIND_IN_SET(u.hashKonty, p.actif) > 0
            WHERE p.idPro = '$id'

            UNION

            SELECT 
                p.dtePresence AS daty,
                p.libActivite AS activite,
                k.libPseudo AS nom_konty
            FROM proactivite p
            JOIN konty k ON FIND_IN_SET(k.hashKonty, p.actif) > 0
            WHERE p.idPro ='$id'";
    
                $result = $conn->query($query);

                if ($result) {
                    $i = 0; // Initialisez le compteur
                    while ($row = $result->fetch_assoc()) {
                        $i = $i + 1;
                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(10, 5, $i, 1);
                        $pdf->Cell(270, 5, $row['utilisateur'], 1);
                        $pdf->Ln();
                    }
                }
$pdf->Ln(5);
$pdf->Cell(50, 5, iconv("UTF-8", 'windows-1252','Liste de personnes absentes : ') . $absent, 0, 1, 'L');
// $pdf->Ln();


// absent
$queryA = "SELECT k.libPseudo AS nom, k.idKonty AS id
                    FROM konty k
                    WHERE 
                        FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                        NOT FIND_IN_SET(k.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))

                UNION
                (
                    SELECT CONCAT(u.nomUser, ' ', u.prenomUser) AS nom, u.idUser AS id
                    FROM user u
                    WHERE 
                        (
                            u.idFaritra IN (
                                SELECT k.idFaritra
                                FROM konty k
                                WHERE 
                                    FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                                    NOT FIND_IN_SET(u.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))
                            )
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idMasina IN (
                            SELECT k.idMasina
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idSakramenta IN (
                            SELECT k.idSakramenta
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idVaomiera IN (
                            SELECT k.idVaomiera
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                )";
    
                $resultA = $conn->query($queryA);

                if ($resultA) {
                    $i = 0; // Initialisez le compteur
                    while ($rowA = $resultA->fetch_assoc()) {
                        $i = $i + 1;
                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(10, 5, $i, 1);
                        $pdf->Cell(270, 5, $rowA['nom'], 1);
                        $pdf->Ln();
                    }
                }
$pdf->Ln(10);
$pdf->Cell(50, 5, 'Effectif : ' . $present . ' / ' . $total, 0, 1, 'L');
$pdf->Ln();




// Générer le PDF

$pdf->Output($row2['libActivite'] . '.pdf', 'D');


?>
