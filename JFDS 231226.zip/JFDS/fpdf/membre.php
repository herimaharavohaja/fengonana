<?php
require('fpdf.php'); // Assurez-vous d'inclure le fichier FPDF approprié
include '../connect.php';

// Créer une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage('L');

// Titre
$pdf->SetFont('Arial','B', 13);
$pdf->Cell(0, 10, iconv("UTF-8", 'windows-1252','Statistique total des membres par année' ), 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 5, utf8_decode('N°'), 1,0);
$pdf->Cell(15, 5, utf8_decode('Année'), 1,0);
$pdf->Cell(20, 5, utf8_decode('Effectif'), 1,0);
$pdf->Cell(230, 5, utf8_decode('Pourcentage (%)'), 1, 1);
// $pdf->Ln(10);

// present
$query = "SELECT YEAR(dteUser) AS annee, count(*) AS total FROM user 
                            GROUP BY YEAR(dteUser)";
    
                $result = $conn->query($query);

                if ($result) {
                    $i = 0; // Initialisez le compteur
                    while ($row = $result->fetch_assoc()) {
                        $i = $i + 1;
                        $stat[] = $row;
                        $totalMembre = 0;
                        foreach ($stat as $stats) {
                            $totalMembre += $stats['total'];
                            $pourcentage = ($stats['total'] / $totalMembre) * 100;
                            $stats['pourcentage'] = round($pourcentage, 2);
                        }
                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(10, 5, $i, 1,0);
                        $pdf->Cell(15, 5, $stats['annee'], 1,0);
                        $pdf->Cell(20, 5, $stats['total'], 1,0);
                        $pdf->Cell(230, 5, $stats['pourcentage'], 1,1);
                    }
                }
// Générer le PDF

$pdf->Output('statistique.pdf', 'D');


?>
