<?php
// Inclusion des bibliothèques nécessaires
require('../fpdf/fpdf.php');
// require('fpdf/fpdi.php');
include '../connect.php';
ini_set('display_errors','on');
error_reporting(E_ALL);

	$service = $_GET['sce'];
$direction = $_GET['dir'];
$id = $_GET['id'];
$i = 0;


// Requête SQL pour obtenir les données du paysage depuis la base de données
$query1 = "SELECT 
                organigramme.ID_SERVICE, organigramme.ID_SUP, organigramme.SCE_LONG, 
                p_sce.IM,
                p_etat_civil.N_P AS nomComplet, p_etat_civil.MLE AS MLE, 
        grade.GRADE_L AS grade,
        region.region,
        district.DISTRICT,
                p_affectation.D_PS AS D_PS,
                p_sce.D_AFFECT AS D_AFFECT,
                p_affectation.FONCTIONS AS FONCTIONS,
                pers_famille.SITUATION AS SITUATION, 
                (SELECT COUNT(IM) FROM pers_enfant WHERE pers_enfant.IM = p_etat_civil.IM ) AS nbEnfant,
                (SELECT p_affectation.FONCTIONS FROM p_affectation ORDER BY IM DESC LIMIT 1) AS actuelFonction,
                pers_famille.NOM_CONJOINT AS NOM_CONJOINT, 
                pers_famille.PROF_CONJOINT AS Profession,
                 p_coordonnees.ADRESSE AS ADRESSE, 
                p_coordonnees.TEL1 AS TEL1, 
                p_coordonnees.TEL2 AS TEL2, 
                p_coordonnees.EMAIL AS EMAIL,
                p_sce.SIT_SCE AS situationParticuliere
                FROM `organigramme` 
                INNER JOIN p_sce ON p_sce.ID_SERVICE = organigramme.ID_SERVICE
                INNER JOIN p_etat_civil ON p_etat_civil.IM = p_sce.IM
        INNER JOIN grade ON grade.GRADE_C = p_sce.GRADE_C
                INNER JOIN p_affectation ON p_affectation.IM = p_sce.IM
                INNER JOIN pers_famille ON pers_famille.IM = p_sce.IM
                INNER JOIN p_coordonnees ON p_coordonnees.IM = p_etat_civil.IM
                INNER JOIN district ON district.IDDISTRICT = organigramme.IDDISTRICT
                INNER JOIN region ON region.IDREGION = district.IDREGION

                WHERE ID_SUP = '$id' AND organigramme.SCE_COURT = '$service' 
                GROUP BY p_sce.IM DESC";
$result1 = mysqli_query($conn, $query1);


// Création d'un nouvel objet FPDI
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();
    
    $row1 = mysqli_fetch_assoc($result1);
    $SCE_LONG = $row1["SCE_LONG"];
    $region = $row1["region"];
    $DISTRICT = $row1["DISTRICT"];

// Title
    $pdf->SetFont('Arial','B',15);
    $pdf->SetFont('Arial','U',15);
    $pdf->Cell(0, 10, 'LISTE NOMINATIVE DU PERSONNEL', 0, 1, 'C');
    $pdf->Cell(0, 10, $SCE_LONG, 0, 1, 'C');
    $pdf->Ln(03);

    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '1- ANNEE:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, date('Y'), 0, 1);

    setlocale(LC_ALL, 'fr_FR.UTF8', 'fr_FR','fr','fr','fra','fr_FR@euro');
    $mois = date("M"); 
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '2- MOIS:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, strtoupper($mois), 0, 1);
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '3- DIRECTION:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, strtoupper($direction), 0, 1);
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '4- SERVICE:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, strtoupper($SCE_LONG), 0, 1);
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '5- REGION:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, strtoupper($region), 0, 1);
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFont('Arial','U',10);
    $pdf->Cell(25, 05, '6- DISTRICT:', 0, 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(129, 05, strtoupper($DISTRICT), 0, 1);
    $pdf->Ln(10);


    $pdf->SetFont('Arial', '', 10);

    $pdf->Cell(10, 32, iconv('UTF-8', 'ISO-8859-2', 'N°'), 1, 0);

    $pdf->Cell(40, 32, iconv('UTF-8', 'ISO-8859-2', 'a)-Nom et prénoms'), 1, 0);
    $pdf->Ln(4);
    $pdf->SetX(24); 
    $pdf->Cell(40, 32, 'Grade', 0, 0);
    $pdf->Ln(4);
    $pdf->SetX(24); 
    $pdf->Cell(40, 32, 'IM/MLE', 0, 0);

    $pdf->SetXY(60,73); 
    $pdf->Cell(45, 32, 'b)-fonction au poste actuel', 1, 0);

    $pdf->SetXY(105,73); 
    $pdf->Cell(55, 32, '', 1, 0);
    $pdf->SetXY(105,60); 
    $pdf->Cell(55, 32, 'c)-situation de famille', 0, 0);
    $pdf->SetXY(108,63);
    $pdf->Cell(40, 40, "-nombre d'enfants en charges", 0, 0);
    $pdf->SetXY(105,72);
    $pdf->Cell(40, 45, iconv('UTF-8', 'ISO-8859-2', 'd)-nom et prénoms du (de la)'), 0, 0);
    $pdf->SetXY(108,63);
    $pdf->Cell(40, 50, "conjointe(e)", 0, 0);
    $pdf->SetXY(108,72);
    $pdf->Cell(40, 55, "-profession", 0, 0);

    $pdf->SetXY(160,73); 
    $pdf->Cell(60, 32, 'e)-adresse', 1, 0);
    $pdf->SetXY(161,78);
    $pdf->Cell(40, 32, iconv('UTF-8', 'ISO-8859-2', 'f)-téléphone portable'), 0, 0);
    $pdf->SetXY(161,82);
    $pdf->Cell(40, 32, "g)-e-mail", 0, 0);


    $pdf->SetXY(220,73); 
    $pdf->Cell(30, 32, 'h)-date p.s au', 1, 0);
    $pdf->SetXY(224,78); 
    $pdf->Cell(40, 32, 'dernier poste', 0, 0);

    $pdf->SetXY(250,73); 
    $pdf->Cell(40, 32, 'i)-situation particulière', 1, 1);


// Requête SQL pour obtenir les données du paysage depuis la base de données
$query = "SELECT 
                organigramme.ID_SERVICE, organigramme.ID_SUP, organigramme.SCE_LONG, 
                p_sce.IM,
                p_etat_civil.N_P AS nomComplet, p_etat_civil.MLE AS MLE, 
        grade.GRADE_L AS grade,
                p_affectation.D_PS AS D_PS,
                p_sce.D_AFFECT AS D_AFFECT,
                p_affectation.FONCTIONS AS FONCTIONS,
                pers_famille.SITUATION AS SITUATION, 
                (SELECT COUNT(IM) FROM pers_enfant WHERE pers_enfant.IM = p_etat_civil.IM ) AS nbEnfant,
                (SELECT p_affectation.FONCTIONS FROM p_affectation ORDER BY IM DESC LIMIT 1) AS actuelFonction,
                pers_famille.NOM_CONJOINT AS NOM_CONJOINT, 
                pers_famille.PROF_CONJOINT AS Profession,
                 p_coordonnees.ADRESSE AS ADRESSE, 
                p_coordonnees.TEL1 AS TEL1, 
                p_coordonnees.TEL2 AS TEL2, 
                p_coordonnees.EMAIL AS EMAIL,
                p_sce.SIT_SCE AS situationParticuliere
                FROM `organigramme` 
                INNER JOIN p_sce ON p_sce.ID_SERVICE = organigramme.ID_SERVICE
                INNER JOIN p_etat_civil ON p_etat_civil.IM = p_sce.IM
        INNER JOIN grade ON grade.GRADE_C = p_sce.GRADE_C
                INNER JOIN p_affectation ON p_affectation.IM = p_sce.IM
                INNER JOIN pers_famille ON pers_famille.IM = p_sce.IM
                INNER JOIN p_coordonnees ON p_coordonnees.IM = p_etat_civil.IM
                WHERE ID_SUP = '$id' AND organigramme.SCE_COURT = '$service' 
                GROUP BY p_sce.IM DESC";
$result = mysqli_query($conn, $query);

// Boucle pour parcourir les résultats de la requête et ajouter les données dans le PDF
while ($row = mysqli_fetch_assoc($result)) {

  $i = $i+1;
                  $IM = $row["IM"];
                  $MLE = $row["MLE"];
                  $nomComplet = $row["nomComplet"];
                  $grade = $row["grade"];
                  $SITUATION = $row["SITUATION"];
                  $nbEnfant = $row["nbEnfant"];
                  $actuelFonction = $row["actuelFonction"];
                  $NOM_CONJOINT = $row["NOM_CONJOINT"];
                  $Profession = $row["Profession"];
                  $Adresse = $row["ADRESSE"];
                  $TEL1 = $row["TEL1"];
                  $TEL2 = $row["TEL2"];
                  $EMAIL = $row["EMAIL"];
                  $D_PS = $row["D_PS"];
                  $D_AFFECT = $row["D_AFFECT"];
                  $FONCTIONS = $row["FONCTIONS"];
                  $situationParticuliere = $row["situationParticuliere"];
                  $SCE_LONG = $row["SCE_LONG"];



        $pdf->SetFont('Arial', '', 10);
    // $pdf->Ln();
    $pdf->MultiCell(10, 8, iconv('UTF-8', 'ISO-8859-2', ($i)), 1, 0);
    
    $a = $nomComplet . "\n" . $grade . "\n" . $IM . $MLE;
    $pdf->MultiCell(40, 8, iconv('UTF-8', 'ISO-8859-2', ($a)), 1, 0);
    // $pdf->Ln(4);
    // $pdf->SetXY(24, 110); 
    // $pdf->Cell(40, 32, ($grade), 0, 0);
    // $pdf->Ln(4);
    // $pdf->SetX(24); 
    // $pdf->Cell(40, 32, ($IM)/($MLE), 0, 0);

    $b = $actuelFonction;
    $x = $pdf->GetX(60);
    // $y = $pdf->GetY(105);
    $pdf->SetXY(60,105); 
    $pdf->MultiCell(40, 40, ($b), 1, 0);

    $cd = $SITUATION . "\n" . $nbEnfant . "\n" . $NOM_CONJOINT . "\n" . $Profession;
    

    $pdf->SetXY(105,105); 
    $pdf->MultiCell(55, 13.3, ($cd), 1, 0);
    // $pdf->SetXY(105,60); 
    // $pdf->Cell(55, 32, ($SITUATION), 0, 0);
    // $pdf->SetXY(108,63);
    // $pdf->Cell(40, 40, ($nbEnfant), 0, 0);

    // $pdf->SetXY(105,72);
    // $pdf->Cell(40, 45, iconv('UTF-8', 'ISO-8859-2', ($NOM_CONJOINT)), 0, 0);
    // $pdf->SetXY(108,63);
    // $pdf->Cell(40, 50, "conjointe(e)", 0, 0);
    // $pdf->SetXY(108,72);
    // $pdf->Cell(40, 55, ($Profession), 0, 0);

    $efg = $Adresse . "\n" . $TEL1 . "\n" . $TEL2 . "\n" . $EMAIL;
    // $pdf->SetXY(160,105); 
    $pdf->MultiCell(60, 13.3, ($efg), 1, 0);
    // $pdf->SetXY(161,78);
    // $pdf->Cell(40, 32, ($TEL1) , ($TEL2), 0, 0);
    // $pdf->SetXY(161,82);
    // $pdf->Cell(40, 32, ($EMAIL), 0, 0);

    // $h = $D_AFFECT;
    // $pdf->SetXY(220,105); 
    $pdf->MultiCell(30, 40, ($D_AFFECT), 1, 0);
    // $pdf->SetXY(224,78); 
    // $pdf->Cell(40, 32, 'dernier poste', 0, 0);

    // $pdf->SetXY(250,105); 
    $pdf->MultiCell(40, 20, ($situationParticuliere), 1, 1);

    // $pdf->SetY($y + 13);

    }
// $pdf->Ln();
// Fermeture de la connexion MySQL
mysqli_close($conn);

// Enregistrement du fichier PDF
$pdf->Output('paysages.pdf', 'I');
?>