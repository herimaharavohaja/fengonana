<?php
require('fpdf.php'); // Assurez-vous d'inclure le fichier FPDF approprié
include '../connect.php';

// Créer une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage('L');

// Titre
$pdf->SetFont('Arial','B', 13);
$pdf->Cell(0, 10, iconv("UTF-8", 'windows-1252','Statistique de la sexualité des membres par année' ), 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(15, 5, utf8_decode('Année'), 1,0);
$pdf->Cell(25, 5, utf8_decode('Hommes'), 1,0);
$pdf->Cell(25, 5, utf8_decode('Femmes'), 1,0);
$pdf->Cell(100, 5, utf8_decode('Pourcentage hommes (%)'), 1,0);
$pdf->Cell(100, 5, utf8_decode('Pourcentage femmes (%)'), 1,1);
// $pdf->Ln(10);

// present
$query = "SELECT YEAR(dteUser) AS annee, sexeUser, count(*) AS total FROM user GROUP BY YEAR(dteUser), sexeUser";
    
                $result = $conn->query($query);

                if ($result) {
                    $i = 0; // Initialisez le compteur
                    while ($row1 = $result->fetch_assoc()) {
                        $annee = $row1["annee"];
                                $sexeUser = $row1["sexeUser"];
                                $total = $row1["total"];

                                if (!isset($stat[$annee])) {
                                    $stat[$annee] = array(
                                        'hommes' => 0,
                                        'femmes' => 0,
                                        'total1' => 0
                                    );
                                }
                                if ($sexeUser == 'Masculin') {
                                    $stat[$annee]['hommes'] = $total;
                                } elseif ($sexeUser == 'Féminin') {
                                    $stat[$annee]['femmes'] = $total;
                                }
                                $stat[$annee]['total1'] += $total;
                                }
                                foreach ($stat as $annee => $data) {
                                    $total1 = $data['total1'];
                                    $pourcentageH = ($data['hommes'] / $total1) * 100;
                                    $pourcentageF = ($data['femmes'] / $total1) * 100;

                                    $stat[$annee]['pourcentage_hommes'] = $pourcentageH;
                                    $stat[$annee]['pourcentage_femmes'] = $pourcentageF;

                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(15, 5, $annee, 1,0);
                        $pdf->Cell(25, 5, $data['hommes'], 1,0);
                        $pdf->Cell(25, 5, $data['femmes'], 1,0);
                        $pdf->Cell(100, 5, round($pourcentageH, 2), 1,0);
                        $pdf->Cell(100, 5, round($pourcentageF, 2), 1,1);
                    }
                }
// Générer le PDF

$pdf->Output('sexe.pdf', 'D');


?>
