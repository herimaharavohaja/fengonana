<?php
require('fpdf.php'); // Assurez-vous d'inclure le fichier FPDF approprié
include '../connect.php';

// Créer une instance de FPDF
$pdf = new FPDF();
$pdf->AddPage('L');

// Titre
$pdf->SetFont('Arial','B', 13);
$pdf->Cell(0, 10, iconv("UTF-8", 'windows-1252','Tetibola par année' ), 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(15, 5, utf8_decode('Année'), 1,0);
$pdf->Cell(25, 5, utf8_decode('Entrée'), 1,0);
$pdf->Cell(25, 5, utf8_decode('Sortie'), 1,0);
$pdf->Cell(200, 5, utf8_decode('Marge'), 1, 1);
// $pdf->Ln(10);

// present
$query = "SELECT year(daty) AS daty1,
            SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END) AS entree,
            SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END) AS sortie
            FROM caisse";
    
                $result = $conn->query($query);

                if ($result) {
                    $i = 0; // Initialisez le compteur
                    while ($rowC = $result->fetch_assoc()) {
                        $i = $i + 1;
                        $statC[] = $rowC;
                        $totalMembre = 0;
                        foreach ($statC as $statsC) {
                            // $totalMembre += $stats['total'];
                            $pourc = (($statsC['entree'] - $statsC['sortie']));
                        }
                        $pdf->SetFont('Arial', '', 10);
                        $pdf->Cell(15, 5, $statsC['daty1'], 1,0);
                        $pdf->Cell(25, 5, $statsC['entree'], 1,0);
                        $pdf->Cell(25, 5, $statsC['sortie'], 1,0);
                        $pdf->Cell(200, 5, $pourc, 1,1);
                    }
                }
// Générer le PDF

$pdf->Output('caisse.pdf', 'D');


?>
