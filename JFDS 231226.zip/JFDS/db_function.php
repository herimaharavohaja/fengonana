<?php 

	// Fonction pour échapper les valeurs pour les requêtes SQL
function escape_data($conn, $data) {
    return $conn->real_escape_string($data);
}
 ?>