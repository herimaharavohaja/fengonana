<?php

 include 'connect.php';
//  include('db_function.php');  
 session_start();
 $cat = $_SESSION['libCategorie'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $motif = $_POST["motif"]; 
  $motif = mysqli_real_escape_string($conn, $motif);
  $type = $_POST["type"];
  $montant = $_POST["montant"];
  $daty = $_POST["daty"];

  $sql1 = "SELECT * FROM caisse ORDER BY idCaisse DESC";
  $result1 = $conn->query($sql1);
  // $solde = 0;
  if ($result1->num_rows > 0) {
    $row1 = $result1->fetch_assoc();
    $solde = $row1['solde'] + ($type == 'entree' ? $montant : -$montant);
  } else {
    $solde = 0;
    $solde += ($type == 'entree' ? $montant : -$montant);
  }

  // $solde += ($type == 'entree' ? $montant : -$montant);

  $sql = "INSERT INTO caisse (motif, type, montant, daty, solde) VALUES ('$motif', '$type', '$montant', '$daty', '$solde')";
  if ($conn->query($sql) === true) {
    header("Location: caisse.php");
    exit();
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

 ?>
<?php include 'pannelAmbony.php'; ?>   
    <div class="container">
    <form action="" method="POST">
    <div class="row">
      <div class="col-md-3">
        <label class="form-label" for="form1Example1">Motif</label>
        <div class="form-outline mb-4">
          <input type="text" id="form1Example1" name="motif" class="form-control" required />
         </div>
      </div>
      <div class="col-md-3">
        <label class="form-label" for="form1Example1">Mouvement</label>
        <div class="form-outline mb-4">
          <select name="type" required class="form-control">
            <option value="entree">Entrée</option>
            <option value="sortie">Sortie</option>
          </select>
        </div>
      </div>
      <div class="col-md-3">
        <label class="form-label" for="form1Example1">Montant</label>
        <div class="form-outline mb-4">
          <input type="number" id="form1Example2" name="montant"  class="form-control" required />
        </div>
      </div>
      <div class="col-md-3">
        <label class="form-label" for="form1Example1">Date</label>
        <div class="form-outline mb-4">
          <input type="date" id="form1Example2" name="daty"  class="form-control" required />
        </div>
      </div>
      
      <div class="ml-4">
        <input type="submit" class="btn btn-success" name="enregistrer" value="Enregistrer"  />
      </div>
  </div>
  </form>
  <br>
    <div class="row">
    <div class="col-md-12">
        <div class="card shadow" style="max-height: 350px;overflow-y: auto;">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Kaontim-bola</h6>
                
            </div>
            <div class="card-body" >
              <?php 
                  $querySetLocale = "SET lc_time_names = 'fr_FR'";
                  $conn->query($querySetLocale);
                  $query = "SELECT *, MONTH(daty) AS volana , MONTHNAME(daty) AS nom_mois FROM caisse group by volana";
                  $result = $conn->query($query);
                 ?>
                  <h6 style="text-align: right;">
                      <select id="selectData" >
                        <?php
                        // Afficher les options de la liste déroulante
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['volana'] . "'>" . $row['nom_mois'] . "</option>";
                        }
                        ?>
                      </select>
                      <a href="#" id="exportPDF" style="text-decoration: none;">
                          <button class="btn btn-secondary">
                            <i class="bi bi-printer"></i>
                          </button>
                      </a>
                  </h6>

                  <script>
                      // Lorsque le bouton PDF est cliqué
                      document.getElementById('exportPDF').addEventListener('click', function () {
                          // Récupérer la valeur sélectionnée dans la liste déroulante
                          var selectedMonth = document.getElementById('selectData').value;
                          // Construire le lien avec le mois sélectionné
                          var pdfLink = 'fpdf/echangeMensuel.php?mois=' + selectedMonth;
                          // Rediriger vers le lien
                          window.location.href = pdfLink;
                      });
                  </script>
                <form>
                    <table id="Table_util" class="table table-bordered table-striped" >
                        <thead>
                            <tr >
                              <th>Date</th>
                              <th>Mouvement</th>
                              <th>Montant</th>
                              <th>Motif</th>
                              <th>Solde(Ar)</th>
                              <!-- <th colspan="2" class="text-center">Actions</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                $sql = "SELECT * FROM caisse ORDER BY daty DESC ";
                                $result = $conn->query($sql);

                                 
                                if ($result->num_rows > 0) {
                                  while ($row = $result->fetch_assoc()) {
                                    ?>  

                        <tr>
                              <td><?php echo $row['daty']?></td>
                              <td><?php echo $row['type']?></td>
                              <td><?php echo $row['montant']?></td>
                              <td><?php echo $row['motif']?></td>
                              <td><?php echo $row['solde'] ?></td>
                        </tr>
                        <?php
                                  }
                        ?>
                        </tbody>

                    </table>
                        <?php
                      }
                        else{
                          echo "<p>Il n'y a pas d'enregistrement!</p>";

                      } ?> 
                           
                </form>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
                

            </div>
        </div>
    </div>

    </div>
    <br><br>
</div>


<br><br>
<?php include 'pannelAmbany.php'; ?> 