<?php
include 'connect.php';

$idOperation = $_POST['idOperation'];

$i = 0;
$totalPourcentage = 0; // Initialisation de la variable pour stocker le total du pourcentage
$totalBillets = 0; // Initialisation de la variable pour stocker le total des billets

$query = "SELECT 
            o.libOperation AS operation,
            CONCAT(k.nomKonty, ' ', k.prenomKonty) AS staff,
            COALESCE((b.a - b.de + 1), 0) AS total_numbers,
            COALESCE(LENGTH(b.paye) - LENGTH(REPLACE(b.paye, ',', '')) + 1, 0) AS total_paye_numbers,
            COALESCE((b.a - b.de + 1) - (LENGTH(b.paye) - LENGTH(REPLACE(b.paye, ',', '')) + 1), 0) AS reste,
            ROUND(COALESCE(((LENGTH(b.paye) - LENGTH(REPLACE(b.paye, ',', '')) + 1) * 100) / (b.a - b.de + 1), 0), 2) AS pourcentage_paye
        FROM billet b
        LEFT JOIN operation o ON o.idOperation = b.idOperation
        LEFT JOIN konty k ON k.idKonty = b.idKonty
        WHERE o.idOperation = '$idOperation';";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<thead>
            <tr>
                <th>N°</th>
                <th>Nom & Prénom(s)</th>
                <th>Billet total</th>
                <th>Billet payé</th>
                <th>Billet non payé</th>
                <th>Pourcentage(%)</th>
            </tr>
          </thead>
          <tbody>";
    while ($rowK = $result->fetch_array()) {
        $i = $i + 1;
        $totalPourcentage += $rowK['pourcentage_paye']; // Accumuler le pourcentage dans la variable totalPourcentage
        $totalBillets += $rowK['total_numbers']; // Accumuler le total des billets dans la variable totalBillets
?>
        <tr>
            <td><?php echo $i ?></td>
            <td><?php echo $rowK['staff'] ?></td>
            <td><?php echo $rowK['total_numbers'] ?></td>
            <td><?php echo $rowK['total_paye_numbers'] ?></td>
            <td><?php echo $rowK['reste'] ?></td>
            <td><?php echo $rowK['pourcentage_paye'] ?></td>
        </tr>
<?php }
    echo "</tbody>
          <tfoot>
            <tr>
                <td colspan='2' style='text-align: right;'>Total Billets :</td>
                <td>{$totalBillets}</td>
                <td colspan='2' style='text-align: right;'>Total Pourcentage :</td>
                <td>{$totalPourcentage}</td>
            </tr>
          </tfoot>";
} else {
    echo "<p>Il n'y a pas d'enregistrement!</p>";
}
?>
