
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<div class="icon-container">
    <i class="fas fa-envelope custom-icon"></i>
    <span class="red-dot"></span>
</div>


<style type="text/css">
    /* Définition du conteneur de l'icône */
.icon-container {
    display: inline-block;
    position: relative;
}

/* Styles pour l'icône */
.custom-icon {
    color: black; /* Couleur de l'icône (noire ici) */
    font-size: 10px; /* Taille de l'icône */
}

/* Styles pour le point rouge */
.red-dot {
    position: absolute;
    top: -5px; /* Ajustez la position verticale du point */
    right: -5px; /* Ajustez la position horizontale du point */
    width: 10px;
    height: 10px;
    background-color: red; /* Couleur du point rouge */
    border-radius: 50%; /* Pour créer un cercle */
}

</style>