<?php
// Définir le fuseau horaire de New York
date_default_timezone_set('America/New_York');

// Obtenir l'heure actuelle de New York
$now = new DateTime();

// Définir l'heure de fin de journée à 23:59:59
$endOfDay = new DateTime('tomorrow');
$endOfDay->setTime(23, 59, 59);

// Calculer le temps restant jusqu'à la fin de la journée
$interval = $endOfDay->diff($now);

// Formatage du temps restant
$timeRemaining = sprintf(
    '%02d:%02d:%02d',
    $interval->h,
    $interval->i,
    $interval->s
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <!-- Mission reset :<p id="countdown"> <b><?php echo $timeRemaining; ?></b></p> -->
    <p>Mission reset : <b id="countdown"><?php echo $timeRemaining; ?></b></p>
    <script>
        let interval;

        // Fonction pour mettre à jour le compte à rebours chaque seconde
        function updateCountdown() {
            const countdownElement = document.getElementById('countdown');
            
            // Convertir le temps restant en un tableau [heures, minutes, secondes]
            const [hours, minutes, seconds] = countdownElement.innerText.split(':').map(Number);
            
            if (hours === 0 && minutes === 0 && seconds === 0) {
                clearInterval(interval);
                countdownElement.innerText = "Temps écoulé !";

                // Réinitialiser le compteur après 5 secondes (ou toute autre valeur souhaitée)
                setTimeout(() => {
                    countdownElement.innerText = "<?php echo $timeRemaining; ?>";
                    startCountdown();
                }, 2000); // Réinitialisation après 2 secondes
            } else {
                // Mettre à jour le compte à rebours en décrémentant d'une seconde
                const newSeconds = seconds === 0 ? 59 : seconds - 1;
                const newMinutes = seconds === 0 ? minutes - 1 : minutes;
                const newHours = minutes === 0 && seconds === 0 ? hours - 1 : hours;
                countdownElement.innerText = `${newHours.toString().padStart(2, '0')}:${newMinutes.toString().padStart(2, '0')}:${newSeconds.toString().padStart(2, '0')}`;
            }
        }

        // Fonction pour démarrer le compte à rebours
        function startCountdown() {
            clearInterval(interval); // Assurez-vous qu'il n'y a pas d'intervalle actif
            interval = setInterval(updateCountdown, 1000);
        }

        // Démarrer le compte à rebours lors du chargement de la page
        startCountdown();


        // Appeler la fonction de mise à jour chaque seconde
        // const interval = setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
