<?php
// Start session
  session_start();
  // include 'secur1.php';
  include 'connect.php';
  // Retrieve user input from login form
  $libPseudo = $_POST['libPseudo'];
  $libPass = $_POST['libPass'];
  // $lib_categorie = "AdMin";

  // Check if username and lib_pass exist in database
  if (!empty($_POST['libPseudo'])) {

  
  $sql = "SELECT * FROM konty WHERE libPseudo = '$libPseudo' AND libPass = '$libPass'";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    // Authentication successful
    $row1 = mysqli_fetch_assoc($result);
    $cat1= $row1["libCategorie"];
    $fari= $row1["idFaritra"];
    $masi= $row1["idMasina"];
    $vao= $row1["idVaomiera"];
    $idKonty= $row1["idKonty"];
        // session_start();
        $_SESSION['libPseudo'] = $libPseudo;
        $sessionP = $_SESSION['libPseudo'];
        $_SESSION['libCategorie'] = $cat1;
        $_SESSION['idFaritra'] = $fari;
        $_SESSION['idMasina'] = $masi;
        $_SESSION['idVaomiera'] = $vao;
        $_SESSION['idKonty'] = $idKonty;
        // echo $cat;
    header('Location: welcome.php');
    mysqli_close($conn);
  // }
    }
    else {
      $sqlU = "SELECT * FROM user WHERE idUser = '$libPseudo' AND codeUser = '$libPass'";

      $resultU = mysqli_query($conn, $sqlU);

      if (mysqli_num_rows($resultU) > 0) {
        // Authentication successful
        

        $rowU = mysqli_fetch_assoc($resultU);

        $fari= $rowU["idFaritra"];
            // session_start();
            $_SESSION['libCategorie'] = "membre";
            $_SESSION['idFaritra'] = $fari;
            $_SESSION['libPseudo'] = $libPseudo;
            $sessionP = $_SESSION['libPseudo'];
            // echo $cat;
        header('Location: welcome.php');

  // }
    }

    }

  }
  else {
    // Authentication failed
    ?>
                <script>
    alert('Authentication echouée!');
    window.location.href='index.php';
    </script>
                <?php
    // header('Location: index.php');
  }

  // Close database connection
  mysqli_close($conn);
?>
