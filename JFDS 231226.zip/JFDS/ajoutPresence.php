<?php
 include './phpqrcode/qrlib.php';
 include 'connect.php';  
 session_start();
 $cat = $_SESSION['libCategorie'];
 $fari = $_SESSION['idFaritra'];

 if (!isset($cat)) {
    header("Location:index.php");
   
}

 if ($cat == 'membre') {
    header("Location:index.php");
   
}

 $id = $_GET['id'];
 $queryP = "SELECT * FROM proactivite WHERE idPro = '$id'";
 $resultP = mysqli_query($conn, $queryP);
 $rowP = mysqli_fetch_assoc($resultP);
 $libActivite = $rowP["libActivite"];
 $dtePresence = $rowP["dtePresence"];


require_once('kajyPresence.php');

?>   

<?php include 'pannelAmbony.php'; ?>  
        <style type="text/css">
            /* Styles de base */
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
            }

            /* Styles pour le bloc d'instruction QR */
            .qr-instruction {
                max-width: 400px;
                margin: 0 auto;
                background-color: #fff;
                padding: 20px;
                text-align: center;
                border-radius: 10px;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            }
            .user-details{
                max-width: 400px;
                margin: 0 auto;
                background-color: #fff;
                padding: 20px;
                text-align: left;
                border-radius: 10px;
                box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            }
            .qr-instruction p {
                font-size: 14px;
                margin-bottom: 20px;
            }
            .user-details p {
                font-size: 14px;
                margin-bottom: 0px;
            }

            .saryI {
                max-width: 100px;
                float: right;
                height: 100px;
                border-radius: 50%;
            }

        </style>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <center>
                        <h4 class='text-center'><b><?php echo $libActivite; ?><br></b><br></h4>
                    </center>
                    <div class="qr-instruction">
                        <p>Scannez le code QR pour obtenir plus d'informations. <br> Mettez le curseur sur la zone de saisie ci-dessous.</p>
                        <input type="text" id="qrInput" class="form-control">
                        <input type="hidden" id="libActivite" value="<?php echo $libActivite; ?>">
                        <br>
                        <button id="validateButton" class="btn btn-primary" style="display:none;">Valider</button>
                        

                    </div>
                    <div class="user-details" style="display:none;">
                        <div style="display: flex;">
                            <p id="userDetailsContent"></p>
                        </div>
                        <div>
                            <center>
                                <input type="hidden" id="id" value="<?php echo $id; ?>">
                                <input type="hidden" id="libActivite" value="<?php echo $libActivite; ?>">
                                <input type="hidden" id="dtePresence" value="<?php echo $dtePresence; ?>">
                                <input type="submit" id="addToJsonButton" class="btn btn-success" value="OK">
                            </center>
                        </div>
                    </div>
                    <div id="notification" class="alert alert-warning" style="display: none;text-align: center;margin: 0 120px;">
                        Aucun utilisateur trouvé.
                    </div>
                </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script> 
    $(document).ready(function() {
    var qrInput = $('#qrInput');
    var userDetailsDiv = $('.user-details');
    var userDetailsContent = $('#userDetailsContent');
    
    var userData = '';

    function debounce(func, delay) {
        let timeout;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                func.apply(context, args);
            }, delay);
        };
    }

    const delayedSearch = debounce(function() {
        var inputValue = qrInput.val().trim();
        var libActivite = document.getElementById('libActivite').value;
        userDetailsDiv.css('display', inputValue ? 'block' : 'none');

        if (inputValue) {
            $('.qr-instruction').css('display', 'none');

            $.ajax({
                type: 'POST',
                url: 'verifUser.php',
                data: { qrCodeValue: inputValue, libActivite: libActivite },
                dataType: 'json',
                success: function(data) {
                    if (data.success) {
                        userData = data;
                        userDetailsContent.html(`
                            <div>
                                    <center>
                                        <img class="saryI" src="./img/${data.saryUser}" style="width: 100px; height: 100px;">
                                        <br>
                                        <label>${data.nomUser}</label>
                                    </center>
                            </div>
                        `);
                        $('#addToJsonButton').on('click', function() {
                            var libActivite = $('#libActivite').val();
                            var dtePresence = $('#dtePresence').val();
                            var id = $('#id').val();
                            window.location.href = 'ajoutPresence.php?id=' + id;

                            $('.qr-instruction').css('display', 'block');
                            $('.user-details').css('display', 'none');
                            qrInput.val(''); // Vide l'input
                            qrInput.focus(); // Met le curseur dans l'input
                        });
                        
                    } else {

                        $('#addToJsonButton, .user-details').hide();
                        $('#notification').show();

                        // Cacher la notification et recharger la page après 2 secondes
                        setTimeout(function() {
                            $('#notification').hide();
                            location.reload();
                        }, 2000);
                    }
                },
                error: function(xhr, textStatus, errorThrown) {
                    console.error('Erreur :', errorThrown);
                }
            });
        } else {
            userDetailsContent.text('');
        }
    }, 2000);

    qrInput.on('input', delayedSearch);

    $('#addToJsonButton').on('click', function() {
        var libActivite = $('#libActivite').val();
        var dtePresence = $('#dtePresence').val();

    });
});

</script>

            <div class="col-md-9">
                <h6>Liste de comptes présents ( <?php echo $present; ?> /  <?php echo $total; ?>)</h6>
                <div style="max-height: 200px;overflow-y: auto;">
                <?php
                $query = "SELECT 
                                p.libActivite AS activite,
                                u.codeUser AS code,
                                u.sexeUser AS sexe,
                                u.apvUser AS apv,
                                u.adresyUser AS adresy,
                                u.saryUser AS sary,
                                f.libFaritra AS faritra,
                                m.libMasina AS masina,
                                v.libVaomiera AS vaomiera,
                                CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur
                            FROM proactivite p
                            JOIN user u ON FIND_IN_SET(u.hashKonty, p.actif) > 0
                            LEFT JOIN faritra f ON f.idFaritra = u.idFaritra
                            LEFT JOIN masina m ON m.idMasina = u.idMasina
                            LEFT JOIN vaomiera v ON v.idVaomiera = u.idVaomiera
                            WHERE p.libActivite = '$libActivite'

                            UNION

                            SELECT 
                                
                                p.libActivite AS activite,
                                k.codeKonty AS code,
                                k.sexeKonty AS sexe,
                                k.apvKonty AS apv,
                                k.adresyKonty AS adresy,
                                k.saryKonty AS sary,
                                f.libFaritra AS faritra,
                                m.libMasina AS masina,
                                v.libVaomiera AS vaomiera,
                                CONCAT(k.nomKonty, ' ', k.prenomKonty) AS utilisateur
                            FROM proactivite p
                            JOIN konty k ON FIND_IN_SET(k.hashKonty, p.actif) > 0
                            LEFT JOIN faritra f ON f.idFaritra = k.idFaritra
                            LEFT JOIN masina m ON m.idMasina = k.idMasina
                            LEFT JOIN vaomiera v ON v.idVaomiera = k.idVaomiera
                            WHERE p.libActivite = '$libActivite'
                            ";
    
                $result = $conn->query($query);

                if ($result) {
                    echo '<table class="table table-bordered">';
                    echo '<tr class="alert-success text-center" style="background: navy;color: white;">

                          <th>N°</th><th>Nom</th></tr>';

                    $i = 0; // Initialisez le compteur
                    while ($row = $result->fetch_assoc()) {
                        $i = $i + 1;
                        echo '<tr class="text-center user-row" data-toggle="modal" data-target="#exampleModal"
                            data-code="' . $row['code'] . '"
                            data-sexe="' . $row['sexe'] . '"
                            data-apv="' . $row['apv'] . '"
                            data-adresy="' . $row['adresy'] . '"
                            data-sary="' . $row['sary'] . '"
                            data-faritra="' . $row['faritra'] . '"
                            data-masina="' . $row['masina'] . '"
                            data-vaomiera="' . $row['vaomiera'] . '"
                            data-utilisateur="' . $row['utilisateur'] . '"
                            >';
                        echo '<td>' . $i . '</td>';
                        echo '<td>' . $row['utilisateur'] . '</td>';
                        echo '</tr>';
                    }

                    echo '</table>';
                } else {
                    echo 'Aucun compte présent!';
                }

                    ?>
                </div>
            <style>
                /* Styles pour le badge */
                .modal-content {
                    border: 2px solid #007BFF;
                    border-radius: 10px;
                }
                
                .modal-title {
                    font-size: 1.2rem;
                    text-align: center;
                }

                #user-photo {
                    border: 2px solid #007BFF;
                    border-radius: 50%;
                    display: block;
                    margin: 0 auto;
                }

                #user-details {
                    text-align: center;
                    /*padding: 20px;*/
                }

                #user-details strong {
                    color: #007BFF;
                    font-weight: bold;
                }
            </style>

<!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  

                    <p id="user-details">
                        <!-- <img style='border-radius: 50%;' class='img-responsive'
                          width='100' height='100' id="user-photo"> -->
                        <ul>
                            <!-- <li><strong>Pseudo : </strong><span id="user-pseudo"></span></li> -->
                            <li><strong>Code : </strong><span id="user-code"></span></li>
                            <li><strong>Sexe : </strong><span id="user-sexe"></span></li>
                            <li><strong>Nom & Prénom(s) : </strong><span id="user-utilisateur"></span></li>
                            <li><strong>APV : </strong><span id="user-apv"></span></li>
                            <li><strong>Adresse : </strong><span id="user-adresse"></span></li>
                            <li><strong>Faritra : </strong><span id="user-faritra"></span></li>
                            <li><strong>Fikambanana Masina : </strong><span id="user-masina"></span></li>
                            <li><strong>Vaomiera ny asa: </strong><span id="user-vaomiera"></span></li>
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>



<script>
    $(document).ready(function() {
        $('.user-row').click(function() {

            var utilisateurValue = $(this).data('utilisateur');
            if (utilisateurValue !== '' && utilisateurValue !== undefined) {
                $('#user-utilisateur').text(utilisateurValue);
            } else {
                $('#user-utilisateur').text("N/A");
            }

            var codeValue = $(this).data('code');
            if (codeValue !== '' && codeValue !== undefined) {
                $('#user-code').text(codeValue);
            } else {
                $('#user-code').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== '' && sexeValue !== undefined) {
                $('#user-sexe').text(sexeValue);
            } else {
                $('#user-sexe').text("N/A");
            }
            
            var faritraValue = $(this).data('faritra');
            if (faritraValue !== '' && faritraValue !== undefined) {
                $('#user-faritra').text(faritraValue);
            } else {
                $('#user-faritra').text("N/A");
            }

            var apvValue = $(this).data('apv');
            if (apvValue !== '' && apvValue !== undefined) {
                $('#user-apv').text(apvValue);
            } else {
                $('#user-apv').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== '' && adresseValue !== undefined) {
                $('#user-adresse').text(adresseValue);
            } else {
                $('#user-adresse').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== '' && faritraValue !== undefined) {
                $('#user-masina').text(faritraValue);
            } else {
                $('#user-masina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== '' && vaomieraValue !== undefined) {
                $('#user-vaomiera').text(vaomieraValue);
            } else {
                $('#user-vaomiera').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== '' && masinaValue !== undefined) {
                $('#user-libMasina').text(masinaValue);
            } else {
                $('#user-libMasina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== '' && vaomieraValue !== undefined) {
                $('#user-libVaomiera').text(vaomieraValue);
            } else {
                $('#user-libVaomiera').text("N/A");
            }


            // var photoNom = $(this).data('sary');
            // $('#user-photo').attr('src', './uploads/gerant/' + photoNom);

            $('#exampleModal').modal('show');
        });
    });
</script>



            <!-- absent -->

            <br>
            <h6>Liste de comptes absents ( <?php echo $absent; ?> / <?php echo $total; ?>)</h6>
            <div style="max-height: 200px;overflow-y: auto;">
                <?php
                $query ="
                    SELECT 
                    k.codeKonty AS code,
                    k.sexeKonty AS sexe,
                    k.apvKonty AS apv,
                    k.adresyKonty AS adresy,
                    k.saryKonty AS sary,
                    f.libFaritra AS faritra,
                    m.libMasina AS masina,
                    v.libVaomiera AS vaomiera,
                    CONCAT(k.nomKonty, ' ', k.prenomKonty) AS utilisateur,
                    k.idKonty AS id
                    FROM konty k
                    LEFT JOIN faritra f ON f.idFaritra = k.idFaritra
                    LEFT JOIN masina m ON m.idMasina = k.idMasina
                    LEFT JOIN vaomiera v ON v.idVaomiera = k.idVaomiera
                    WHERE 
                        FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                        NOT FIND_IN_SET(k.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))

                UNION
                (
                    SELECT 
                    u.codeUser AS code,
                    u.sexeUser AS sexe,
                    u.apvUser AS apv,
                    u.adresyUser AS adresy,
                    u.saryUser AS sary,
                    f.libFaritra AS faritra,
                    m.libMasina AS masina,
                    v.libVaomiera AS vaomiera,
                    CONCAT(u.nomUser, ' ', u.prenomUser) AS utilisateur,
                    u.idUser AS id
                    FROM user u
                    LEFT JOIN faritra f ON f.idFaritra = u.idFaritra
                    LEFT JOIN masina m ON m.idMasina = u.idMasina
                    LEFT JOIN vaomiera v ON v.idVaomiera = u.idVaomiera
                    WHERE 
                        (
                            u.idFaritra IN (
                                SELECT k.idFaritra
                                FROM konty k
                                WHERE 
                                    FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite')) AND
                                    NOT FIND_IN_SET(u.hashKonty, (SELECT actif FROM proactivite WHERE libActivite = '$libActivite'))
                            )
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idMasina IN (
                            SELECT k.idMasina
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idSakramenta IN (
                            SELECT k.idSakramenta
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                        OR 
                        u.idVaomiera IN (
                            SELECT k.idVaomiera
                            FROM konty k
                            WHERE FIND_IN_SET(k.idKonty, (SELECT role FROM proactivite WHERE libActivite = '$libActivite'))
                            AND NOT EXISTS (SELECT 1 FROM proactivite p WHERE FIND_IN_SET(u.hashKonty, p.actif) AND p.libActivite = '$libActivite')
                        )
                )
                ";
    
                $result = $conn->query($query);

                if ($result) {
    echo '<table class="table table-bordered">';
    echo '<tr class="alert-success text-center" style="background: navy;color: white;"><th>N°</th><th>Nom</th></tr>';

    $i = 0; // Initialisez le compteur
    while ($row = $result->fetch_assoc()) {
        $i = $i + 1;
        echo '<tr class="text-center user1-row" data-toggle="modal" 
            data-target="#exampleModal1"
            data-code="' . $row['code'] . '"
            data-sexe="' . $row['sexe'] . '"
            data-apv="' . $row['apv'] . '"
            data-adresy="' . $row['adresy'] . '"
            data-sary="' . $row['sary'] . '"
            data-faritra="' . $row['faritra'] . '"
            data-masina="' . $row['masina'] . '"
            data-vaomiera="' . $row['vaomiera'] . '"
            data-utilisateur="' . $row['utilisateur'] . '"
                            >';
        echo '<td>' . $i . '</td>';
        // echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['utilisateur'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
                } else {
                    echo 'Aucun compte présent!';
                }

                    ?>
            </div>
        </div>
        </div>
    </div>

    <!-- Modal -->
            <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel" style="text-align: center;">Informations plus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">  

                    <p id="user-details">
                        <!-- <img style='border-radius: 50%;' class='img-responsive'
                          width='100' height='100' id="user-photo"> -->
                        <ul>
                            <!-- <li><strong>Pseudo : </strong><span id="user-pseudo"></span></li> -->
                            <li><strong>Code : </strong><span id="user1-code"></span></li>
                            <li><strong>Sexe : </strong><span id="user1-sexe"></span></li>
                            <li><strong>Nom & Prénom(s) : </strong><span id="user1-utilisateur"></span></li>
                            <li><strong>APV : </strong><span id="user1-apv"></span></li>
                            <li><strong>Adresse : </strong><span id="user1-adresse"></span></li>
                            <li><strong>Faritra : </strong><span id="user1-faritra"></span></li>
                            <li><strong>Fikambanana Masina : </strong><span id="user1-masina"></span></li>
                            <li><strong>Vaomiera ny asa: </strong><span id="user1-vaomiera"></span></li>
                        </ul>
                    </p>
                  </div>

                </div>
              </div>
            </div>



<script>
    $(document).ready(function() {
        $('.user1-row').click(function() {

            var utilisateurValue = $(this).data('utilisateur');
            if (utilisateurValue !== '' && utilisateurValue !== undefined) {
                $('#user1-utilisateur').text(utilisateurValue);
            } else {
                $('#user1-utilisateur').text("N/A");
            }

            var codeValue = $(this).data('code');
            if (codeValue !== '' && codeValue !== undefined) {
                $('#user1-code').text(codeValue);
            } else {
                $('#user1-code').text("N/A");
            }

            var sexeValue = $(this).data('sexe');
            if (sexeValue !== '' && sexeValue !== undefined) {
                $('#user1-sexe').text(sexeValue);
            } else {
                $('#user1-sexe').text("N/A");
            }
            
            var faritraValue = $(this).data('faritra');
            if (faritraValue !== '' && faritraValue !== undefined) {
                $('#user1-faritra').text(faritraValue);
            } else {
                $('#user1-faritra').text("N/A");
            }

            var apvValue = $(this).data('apv');
            if (apvValue !== '' && apvValue !== undefined) {
                $('#user1-apv').text(apvValue);
            } else {
                $('#user1-apv').text("N/A");
            }

            var adresseValue = $(this).data('adresy');
            if (adresseValue !== '' && adresseValue !== undefined) {
                $('#user1-adresse').text(adresseValue);
            } else {
                $('#user1-adresse').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== '' && faritraValue !== undefined) {
                $('#user1-masina').text(faritraValue);
            } else {
                $('#user1-masina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== '' && vaomieraValue !== undefined) {
                $('#user1-vaomiera').text(vaomieraValue);
            } else {
                $('#user1-vaomiera').text("N/A");
            }

            var masinaValue = $(this).data('masina');
            if (masinaValue !== '' && masinaValue !== undefined) {
                $('#user1-libMasina').text(masinaValue);
            } else {
                $('#user1-libMasina').text("N/A");
            }

            var vaomieraValue = $(this).data('vaomiera');
            if (vaomieraValue !== '' && vaomieraValue !== undefined) {
                $('#user1-libVaomiera').text(vaomieraValue);
            } else {
                $('#user1-libVaomiera').text("N/A");
            }


            // var photoNom = $(this).data('sary');
            // $('#user-photo').attr('src', './uploads/gerant/' + photoNom);

            $('#exampleModal1').modal('show');
        });
    });
</script>


    <br><br>
<?php include 'pannelAmbany.php'; ?> 